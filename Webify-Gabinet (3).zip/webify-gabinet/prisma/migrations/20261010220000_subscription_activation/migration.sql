ALTER TABLE "Tenant" ADD COLUMN "subscriptionActivatedAt" TIMESTAMP(3);
ALTER TABLE "Tenant" ADD COLUMN "stripeCheckoutId" TEXT;
ALTER TABLE "Plan" ALTER COLUMN "trialDays" SET DEFAULT 14;
UPDATE "Plan" SET "name" = 'Webify Gabinet', "monthlyGrosze" = 4900,
  "trialDays" = 14, "active" = true WHERE "code" = 'START';
UPDATE "Plan" SET "active" = false WHERE "code" IN ('PRO', 'TEAM');
-- Preserve access and trial terms for subscriptions already confirmed by Stripe.
UPDATE "Tenant" t SET "subscriptionActivatedAt" = s."updatedAt"
FROM "Subscription" s WHERE s."tenantId" = t."id"
  AND s."status" IN ('active', 'trialing', 'past_due', 'unpaid', 'canceled', 'paused');
-- Registration alone no longer starts a free trial.
UPDATE "Tenant" SET "trialEndsAt" = NULL
WHERE "kind" = 'PRACTICE' AND "subscriptionActivatedAt" IS NULL;

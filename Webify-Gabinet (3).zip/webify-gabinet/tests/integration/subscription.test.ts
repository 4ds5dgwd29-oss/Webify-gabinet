import { beforeEach, afterAll, describe, expect, it, vi } from "vitest";
import { fixtures } from "../fixtures";
import { db } from "@/server/db";
import { registerPractice } from "@/server/auth/register";
import { authenticate } from "@/server/auth/credentials";
import { resolveSession } from "@/server/auth/session-store";
import { practiceRepository } from "@/server/dal/practice";
import { calendarOptions } from "@/server/dal/calendar";
import { listPractices } from "@/server/dal/platform";
import {
  checkout,
  subscriptionSummary,
  applySubscription,
} from "@/server/dal/commerce";
const api = vi.hoisted(() => ({
  customer: vi.fn(async () => ({ id: "cus_new" })),
  create: vi.fn(async (_params: unknown, _options: unknown) => ({
    id: "cs_new",
    url: "https://checkout.stripe.com/mock",
  })),
  retrieve: vi.fn(async () => ({
    id: "cs_new",
    status: "open",
    url: "https://checkout.stripe.com/mock",
  })),
}));
vi.mock("@/server/stripe", () => ({
  stripe: () => ({
    customers: { create: api.customer },
    checkout: { sessions: { create: api.create, retrieve: api.retrieve } },
  }),
}));
let sid: string, tenantId: string;
beforeEach(async () => {
  vi.clearAllMocks();
  await fixtures();
  await db.plan.create({
    data: {
      tenantId: "webify-platform",
      code: "START",
      name: "Webify Gabinet",
      monthlyGrosze: 4900,
      yearlyGrosze: 58800,
      trialDays: 14,
      patientLimit: 100,
      userLimit: 1,
      stripeMonthlyId: "price_49",
    },
  });
  const data = {
    name: "Nowy Klient",
    practiceName: "Nowy Gabinet",
    email: "new@example.test",
    password: "Testowe-haslo-12345",
  };
  await registerPractice(data);
  const login = await authenticate({
    email: data.email,
    password: data.password,
    otp: "",
  });
  sid = login!.sessionId;
  tenantId = (await resolveSession(sid)).principal.tenantId;
});
afterAll(() => db.$disconnect());
function sub(status = "trialing") {
  return {
    id: "sub_new",
    customer: "cus_new",
    metadata: { tenantId },
    status,
    trial_end: Math.floor(Date.now() / 1000) + 14 * 86400,
    cancel_at_period_end: false,
    items: {
      data: [
        {
          price: { id: "price_49" },
          current_period_end: Math.floor(Date.now() / 1000) + 14 * 86400,
        },
      ],
    },
  } as never;
}
describe("Rejestracja → aktywacja SaaS", () => {
  it("nowe konto ma wyłącznie ekran abonamentu; API danych i administracji są zamknięte", async () => {
    const c = await resolveSession(sid);
    expect(c.user.role).toBe("OWNER");
    expect(c.user.tenant.trialEndsAt).toBeNull();
    expect(c.principal.access).toBe("PENDING");
    const summary = await subscriptionSummary(sid);
    expect(summary.plan).toMatchObject({ monthlyGrosze: 4900, trialDays: 14 });
    expect(summary).not.toHaveProperty("stripeCustomerId");
    expect(summary).not.toHaveProperty("encryptedDataKey");
    await expect(practiceRepository(sid).listPatients()).rejects.toMatchObject({
      status: 402,
    });
    await expect(calendarOptions(sid)).rejects.toMatchObject({ status: 402 });
    await expect(listPractices(sid)).rejects.toMatchObject({ status: 403 });
    await expect(subscriptionSummary("sadmin")).rejects.toMatchObject({
      status: 403,
    });
  });
  it("Checkout ma 14 dni próby, płatność miesięczną i nie daje dostępu przed webhookiem", async () => {
    const input = { code: "START", yearly: false };
    await checkout(sid, input);
    await checkout(sid, input);
    expect(api.create).toHaveBeenCalledTimes(1);
    expect(api.create).toHaveBeenCalledWith(
      expect.objectContaining({
        mode: "subscription",
        payment_method_collection: "always",
        locale: "pl",
        line_items: [{ price: "price_49", quantity: 1 }],
        subscription_data: expect.objectContaining({ trial_period_days: 14 }),
      }),
      expect.anything(),
    );
    expect((await resolveSession(sid)).principal.access).toBe("PENDING");
    await expect(
      checkout(sid, { code: "START", yearly: true }),
    ).rejects.toThrow();
    await expect(
      checkout(sid, { code: "PRO", yearly: false }),
    ).rejects.toThrow();
  });
  it("potwierdzony trial odblokowuje tylko własną bazę, a powtórzony webhook jest idempotentny", async () => {
    await checkout(sid, { code: "START", yearly: false });
    const event = {
      id: "evt_trial",
      type: "customer.subscription.created",
      created: 100,
    };
    await applySubscription(event, sub());
    await applySubscription(event, sub());
    expect((await resolveSession(sid)).principal.access).toBe("FULL");
    expect(await practiceRepository(sid).listPatients()).toEqual([]);
    await expect(
      practiceRepository(sid).getPatient("pa"),
    ).rejects.toMatchObject({ status: 404 });
    await expect(listPractices(sid)).rejects.toMatchObject({ status: 403 });
    expect(await db.webhookEvent.count({ where: { id: event.id } })).toBe(1);
    const t = await db.tenant.findUniqueOrThrow({ where: { id: tenantId } });
    expect(t.subscriptionActivatedAt).not.toBeNull();
    expect(t.stripeCheckoutId).toBeNull();
  });
  it("niekompletna płatność oraz obca identyfikacja tenantu nie odblokowują konta", async () => {
    await checkout(sid, { code: "START", yearly: false });
    await expect(
      applySubscription(
        { id: "evt_bad", type: "checkout.session.completed", created: 100 },
        { ...(sub() as object), metadata: { tenantId: "a" } } as never,
      ),
    ).rejects.toThrow("przypisanie");
    await applySubscription(
      {
        id: "evt_incomplete",
        type: "customer.subscription.updated",
        created: 101,
      },
      sub("incomplete"),
    );
    expect((await resolveSession(sid)).principal.access).toBe("PENDING");
  });
  it("anulowanie zachowuje dane i ponowna subskrypcja nie przyznaje kolejnej próby", async () => {
    await checkout(sid, { code: "START", yearly: false });
    await applySubscription(
      { id: "evt_start", type: "customer.subscription.updated", created: 100 },
      sub(),
    );
    await practiceRepository(sid).createPatient({
      firstName: "Testowa",
      lastName: "Osoba",
    });
    await applySubscription(
      { id: "evt_cancel", type: "customer.subscription.deleted", created: 101 },
      sub("canceled"),
    );
    expect((await resolveSession(sid)).principal.access).toBe("READ_ONLY");
    expect(await practiceRepository(sid).listPatients()).toHaveLength(1);
    await expect(
      practiceRepository(sid).createPatient({
        firstName: "Nowa",
        lastName: "Osoba",
      }),
    ).rejects.toMatchObject({ status: 403 });
    await checkout(sid, { code: "START", yearly: false });
    const params = api.create.mock.calls.at(-1)?.[0] as
      { subscription_data?: object } | undefined;
    expect(params?.subscription_data).not.toHaveProperty("trial_period_days");
  });
});

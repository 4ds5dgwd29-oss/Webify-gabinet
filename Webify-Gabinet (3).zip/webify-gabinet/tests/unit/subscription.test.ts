import { describe, expect, it } from "vitest";
import { practiceAccess } from "@/lib/subscription";
import {
  requirePractice,
  requirePracticeIdentity,
  requireWrite,
} from "@/server/security/policy";
const now = new Date("2026-10-10T12:00:00Z");
const past = new Date(+now - 1000),
  future = new Date(+now + 1000);
const tenant = {
  status: "ACTIVE",
  subscriptionActivatedAt: past,
  trialEndsAt: future,
  subscription: {
    status: "active",
    currentPeriodEnd: future,
    graceUntil: null as Date | null,
  },
};
describe("Dostęp po aktywacji subskrypcji", () => {
  it("rejestracja, stary lokalny trial i sama sesja Checkout nie odblokowują gabinetu", () => {
    for (const status of ["ACTIVE", "TRIAL", "READ_ONLY"])
      expect(
        practiceAccess(
          {
            ...tenant,
            status,
            subscriptionActivatedAt: null,
            subscription: null,
          },
          now,
        ),
      ).toBe("PENDING");
    const pending = {
      userId: "u",
      tenantId: "a",
      role: "OWNER",
      kind: "PRACTICE",
      status: "TRIAL",
      access: "PENDING",
    } as const;
    expect(() => requirePracticeIdentity(pending)).not.toThrow();
    expect(() => requirePractice(pending)).toThrow("Aktywuj");
    expect(() => requireWrite(pending)).toThrow("Aktywuj");
  });
  it("potwierdzona subskrypcja i trwający trial dają dostęp", () => {
    expect(practiceAccess(tenant, now)).toBe("FULL");
    expect(
      practiceAccess(
        {
          ...tenant,
          subscription: { ...tenant.subscription, status: "trialing" },
        },
        now,
      ),
    ).toBe("FULL");
  });
  it("koniec próby lub okresu płatności ogranicza zapis nawet bez webhooka", () => {
    expect(
      practiceAccess(
        {
          ...tenant,
          trialEndsAt: past,
          subscription: { ...tenant.subscription, status: "trialing" },
        },
        now,
      ),
    ).toBe("READ_ONLY");
    expect(
      practiceAccess(
        {
          ...tenant,
          subscription: { ...tenant.subscription, currentPeriodEnd: past },
        },
        now,
      ),
    ).toBe("READ_ONLY");
  });
  it("nieudana płatność ma ograniczony okres karencji", () => {
    expect(
      practiceAccess(
        {
          ...tenant,
          subscription: {
            ...tenant.subscription,
            status: "past_due",
            graceUntil: future,
          },
        },
        now,
      ),
    ).toBe("FULL");
    expect(
      practiceAccess(
        {
          ...tenant,
          subscription: {
            ...tenant.subscription,
            status: "past_due",
            graceUntil: past,
          },
        },
        now,
      ),
    ).toBe("READ_ONLY");
  });
  it("anulowanie, pauza i blokada administratora nie odblokowują zapisu", () => {
    for (const status of ["canceled", "paused", "unpaid", "incomplete"])
      expect(
        practiceAccess(
          { ...tenant, subscription: { ...tenant.subscription, status } },
          now,
        ),
      ).toBe("READ_ONLY");
    expect(practiceAccess({ ...tenant, status: "READ_ONLY" }, now)).toBe(
      "READ_ONLY",
    );
  });
});

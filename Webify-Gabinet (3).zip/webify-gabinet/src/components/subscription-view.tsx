"use client";
import { useEffect, useState } from "react";
import Link from "next/link";
import {
  ArrowRight,
  Check,
  CreditCard,
  ShieldCheck,
  LoaderCircle,
} from "lucide-react";
import { Button } from "./ui/button";
import { ErrorMessage, Loading, mutate, useResource } from "./workspace-kit";
import { money } from "@/lib/domain";
type Summary = {
  practiceName: string;
  access: "PENDING" | "FULL" | "READ_ONLY";
  trialAvailable: boolean;
  trialEndsAt: string | null;
  hasBillingAccount: boolean;
  checkoutAvailable: boolean;
  plan: {
    name: string;
    monthlyGrosze: number;
    trialDays: number;
    patientLimit: number;
    userLimit: number;
  };
  subscription: {
    status: string;
    currentPeriodEnd: string | null;
    cancelAtPeriodEnd: boolean;
  } | null;
};
const features = [
  "Własna baza pacjentów i historia współpracy",
  "Kalendarz, wizyty i godziny pracy",
  "Szyfrowane notatki i dokumenty",
  "Rozliczenia wizyt i raporty gabinetu",
];
const date = (value: string) => new Date(value).toLocaleDateString("pl-PL");
export function SubscriptionView({
  activation = false,
}: {
  activation?: boolean;
}) {
  const { data, error, reload } = useResource<Summary>("subscription");
  const [busy, setBusy] = useState(false),
    [message, setMessage] = useState("");
  const [returned, setReturned] = useState(false),
    [cancelled, setCancelled] = useState(false);
  useEffect(() => {
    const result = new URLSearchParams(window.location.search).get("wynik");
    setReturned(result === "powrot");
    setCancelled(result === "anulowano");
  }, []);
  useEffect(() => {
    if (!returned || data?.access === "FULL") return;
    let attempts = 0;
    const timer = setInterval(() => {
      reload();
      if (++attempts >= 15) clearInterval(timer);
    }, 2000);
    return () => clearInterval(timer);
  }, [returned, data?.access, reload]);
  async function start(portal = false) {
    setBusy(true);
    setMessage("");
    try {
      const result = await mutate<{ url: string }>(
        portal ? "stripe.portal" : "stripe.checkout",
        portal ? undefined : { code: "START", yearly: false },
      );
      window.location.assign(result.url);
    } catch (e) {
      setMessage((e as Error).message);
      setBusy(false);
    }
  }
  if (!data)
    return (
      <>
        <Loading />
        <ErrorMessage message={error} />
      </>
    );
  const existing =
    data.subscription &&
    !["canceled", "incomplete_expired"].includes(data.subscription.status);
  return (
    <div className="mx-auto max-w-4xl">
      <p className="text-xs font-semibold uppercase tracking-widest text-primary">
        {activation ? "Twój gabinet, Twoi pacjenci" : "Twój abonament"}
      </p>
      <h1 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
        {data.access === "PENDING"
          ? "Aktywuj swój gabinet"
          : "Subskrypcja Webify Gabinet"}
      </h1>
      <p className="mt-4 max-w-2xl leading-relaxed text-muted-foreground">
        {data.access === "PENDING"
          ? "Konto jest gotowe. Wybierz abonament i potwierdź subskrypcję w Stripe, aby otworzyć swoją bazę pacjentów, kalendarz i pozostałe narzędzia."
          : `Zarządzaj abonamentem gabinetu ${data.practiceName}. Dane i rozliczenia innych gabinetów są dla Ciebie niedostępne.`}
      </p>
      <ErrorMessage message={message || error} />
      {cancelled && (
        <p role="status" className="mt-5 rounded-xl border p-4 text-sm">
          Aktywacja nie została zakończona. Możesz wrócić do niej w dowolnym
          momencie.
        </p>
      )}
      {returned && data.access === "PENDING" && (
        <div
          role="status"
          className="mt-5 rounded-xl border bg-muted p-4 text-sm"
        >
          Czekamy na potwierdzenie ze Stripe. Dostęp odblokuje się po
          potwierdzeniu subskrypcji.
          <Button variant="outline" className="ml-3 mt-2" onClick={reload}>
            Sprawdź status
          </Button>
        </div>
      )}
      {data.access === "FULL" && (
        <div
          role="status"
          className="mt-6 rounded-xl border border-primary/30 bg-primary/5 p-5"
        >
          <p className="font-medium">Twój gabinet jest aktywny.</p>
          {data.subscription?.status === "trialing" && data.trialEndsAt && (
            <p className="mt-1 text-sm">
              Okres próbny do {date(data.trialEndsAt)}. Potem 49 zł miesięcznie.
            </p>
          )}
          {data.subscription?.cancelAtPeriodEnd && (
            <p className="mt-1 text-sm">
              Subskrypcja jest anulowana na koniec bieżącego okresu.
            </p>
          )}
          {activation && (
            <Button asChild className="mt-4">
              <a href="/gabinet">
                Przejdź do swojego gabinetu <ArrowRight size={17} />
              </a>
            </Button>
          )}
        </div>
      )}
      {data.access === "READ_ONLY" && (
        <p
          role="status"
          className="mt-6 rounded-xl border border-amber-300 bg-amber-50 p-5 text-amber-900"
        >
          Abonament wymaga odnowienia. Twoje dotychczasowe dane pozostają
          dostępne do odczytu.
        </p>
      )}
      <div className="mt-8 grid overflow-hidden rounded-2xl border bg-card shadow-sm md:grid-cols-[1.2fr_1fr]">
        <div className="p-7 sm:p-9">
          <h2 className="text-xl font-semibold">
            Wszystko do codziennej pracy
          </h2>
          <ul className="mt-6 space-y-5">
            {features.map((text) => (
              <li key={text} className="flex gap-3 text-sm">
                <Check className="shrink-0 text-primary" size={19} />
                {text}
              </li>
            ))}
          </ul>
          <p className="mt-7 border-t pt-5 text-sm text-muted-foreground">
            Do {data.plan.patientLimit} pacjentów ·{" "}
            {data.plan.userLimit === 1
              ? "1 użytkownik"
              : `${data.plan.userLimit} użytkowników`}
          </p>
          <p className="mt-4 flex gap-2 text-xs leading-relaxed text-muted-foreground">
            <ShieldCheck size={18} className="shrink-0" />
            Odrębny panel Twojego gabinetu. Dostęp tylko dla Ciebie i
            uprawnionych osób z Twojego zespołu.
          </p>
        </div>
        <div className="flex flex-col justify-center border-t bg-muted/40 p-7 md:border-l md:border-t-0 sm:p-9">
          {data.trialAvailable && (
            <span className="mb-5 w-fit rounded-full bg-primary/10 px-3 py-1 text-sm font-medium text-primary">
              14 dni bezpłatnie
            </span>
          )}
          <p className="text-sm font-medium">Webify Gabinet</p>
          <p className="mt-3">
            <strong className="text-5xl font-semibold tracking-tight">
              49 zł
            </strong>
            <span className="ml-2 text-muted-foreground">/ miesiąc</span>
          </p>
          <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
            {data.trialAvailable
              ? "Dziś 0 zł. Okres próbny zaczyna się po aktywacji w Stripe. Następnie 49 zł co miesiąc. Anuluj przed końcem próby, aby uniknąć opłaty."
              : "Miesięczne rozliczenie. Subskrypcją i metodą płatności zarządzasz w bezpiecznym panelu Stripe."}
          </p>
          <Button
            className="mt-7 w-full"
            disabled={busy || (!existing && !data.checkoutAvailable)}
            onClick={() => start(!!existing)}
          >
            {busy ? (
              <LoaderCircle size={17} className="animate-spin" />
            ) : (
              <CreditCard size={17} />
            )}
            {busy
              ? "Przekierowujemy…"
              : existing
                ? "Zarządzaj subskrypcją"
                : data.trialAvailable
                  ? "Aktywuj 14 dni bezpłatnie"
                  : "Odnów za 49 zł / miesiąc"}
          </Button>
          {!data.checkoutAvailable && !existing && (
            <p role="status" className="mt-3 text-sm">
              Płatności są chwilowo niedostępne. Spróbuj ponownie później.
            </p>
          )}
          <p className="mt-3 text-center text-xs text-muted-foreground">
            Bezpieczna płatność przez Stripe
          </p>
          {data.hasBillingAccount && !existing && (
            <Button
              variant="ghost"
              className="mt-3"
              onClick={() => start(true)}
              disabled={busy}
            >
              Moje rozliczenia w Stripe
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}

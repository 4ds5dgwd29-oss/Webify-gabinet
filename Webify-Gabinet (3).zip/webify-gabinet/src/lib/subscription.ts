export const WEBIFY_PLAN = {
  code: "START",
  monthlyGrosze: 4900,
  trialDays: 14,
} as const;

export type PracticeAccess = "PENDING" | "FULL" | "READ_ONLY";
type BillingTenant = {
  status: string;
  subscriptionActivatedAt: Date | null;
  trialEndsAt: Date | null;
  subscription: {
    status: string;
    currentPeriodEnd: Date | null;
    graceUntil: Date | null;
  } | null;
};

// Only provider-confirmed activation grants access. A URL or a created Checkout
// session is never evidence of a subscription. Expiry retains historical data.
export function practiceAccess(
  t: BillingTenant,
  now = new Date(),
): PracticeAccess {
  if (!t.subscriptionActivatedAt) return "PENDING";
  if (t.status === "SUSPENDED" || t.status === "READ_ONLY") return "READ_ONLY";
  const s = t.subscription;
  if (s?.status === "trialing" && t.trialEndsAt && t.trialEndsAt > now)
    return "FULL";
  if (s?.status === "active" && s.currentPeriodEnd && s.currentPeriodEnd > now)
    return "FULL";
  if (s?.status === "past_due" && s.graceUntil && s.graceUntil > now)
    return "FULL";
  return "READ_ONLY";
}

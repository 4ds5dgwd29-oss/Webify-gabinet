import { redirect } from "next/navigation";
import { currentContext } from "@/server/auth/context";
export default async function PracticeLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { principal } = await currentContext();
  if (principal.role === "SUPER_ADMIN") redirect("/platforma");
  if (principal.access === "PENDING") redirect("/aktywacja");
  return children;
}

import { redirect } from "next/navigation";
import { currentContext } from "@/server/auth/context";
import { SubscriptionView } from "@/components/subscription-view";
export const metadata = { title: "Aktywuj swój gabinet" };
export default async function ActivationPage() {
  const { principal } = await currentContext();
  if (principal.role === "SUPER_ADMIN") redirect("/platforma");
  if (principal.role === "STAFF")
    return (
      <section className="rounded-2xl border bg-card p-8">
        <h1 className="text-2xl font-semibold">Gabinet czeka na aktywację</h1>
        <p className="mt-3 text-muted-foreground">
          Poproś właściciela gabinetu o aktywowanie subskrypcji. Gdy to zrobi,
          uzyskasz dostęp do pracy z pacjentami.
        </p>
      </section>
    );
  return <SubscriptionView activation />;
}

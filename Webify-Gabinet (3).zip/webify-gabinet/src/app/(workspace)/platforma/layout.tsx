import { redirect } from "next/navigation";
import { currentContext } from "@/server/auth/context";
import { requirePlatform } from "@/server/security/policy";
export default async function PlatformLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const { principal } = await currentContext();
  if (principal.role !== "SUPER_ADMIN")
    redirect(principal.access === "PENDING" ? "/aktywacja" : "/gabinet");
  requirePlatform(principal);
  return children;
}

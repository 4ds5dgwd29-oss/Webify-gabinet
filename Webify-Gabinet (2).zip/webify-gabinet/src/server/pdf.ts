import "server-only";
import { PDFDocument, rgb } from "pdf-lib";
import fontkit from "@pdf-lib/fontkit";
import { readFile } from "node:fs/promises";
import path from "node:path";
export async function generatePdf(title: string, paragraphs: string[]) {
  const doc = await PDFDocument.create();
  doc.registerFontkit(fontkit);
  const font = await doc.embedFont(
    await readFile(path.join(process.cwd(), "assets/fonts/DejaVuSans.ttf")),
    { subset: true },
  );
  let page = doc.addPage([595.28, 841.89]),
    y = 780;
  const left = 48,
    width = 499;
  function line(text: string, size = 11) {
    if (y < 60) {
      page = doc.addPage([595.28, 841.89]);
      y = 780;
    }
    page.drawText(text, {
      x: left,
      y,
      size,
      font,
      color: rgb(0.1, 0.17, 0.15),
    });
    y -= size * 1.6;
  }
  line("WEBIFY GABINET", 10);
  y -= 12;
  line(title, 18);
  y -= 16;
  for (const text of paragraphs) {
    for (const paragraph of text
      .replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, "")
      .split("\n")) {
      let current = "";
      for (const word of paragraph.split(/\s+/)) {
        if (
          font.widthOfTextAtSize(current + " " + word, 11) > width &&
          current
        ) {
          line(current);
          current = "";
        }
        if (font.widthOfTextAtSize(word, 11) > width) {
          for (const char of word) {
            if (font.widthOfTextAtSize(current + char, 11) > width) {
              line(current);
              current = "";
            }
            current += char;
          }
        } else current += (current ? " " : "") + word;
      }
      line(current);
    }
    y -= 10;
  }
  doc
    .getPages()
    .forEach((p, i) =>
      p.drawText(`${i + 1} / ${doc.getPageCount()}`, {
        x: 500,
        y: 30,
        size: 9,
        font,
      }),
    );
  return Buffer.from(await doc.save());
}

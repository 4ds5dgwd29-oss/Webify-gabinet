import "server-only";
import Stripe from "stripe";
export function stripe() {
  if (!process.env.STRIPE_SECRET_KEY)
    throw new Error("Płatności Stripe nie są skonfigurowane.");
  return new Stripe(process.env.STRIPE_SECRET_KEY, {
    maxNetworkRetries: 1,
    timeout: 10000,
  });
}

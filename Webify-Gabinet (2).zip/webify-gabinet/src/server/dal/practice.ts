import { capacity } from "./commerce";
import { tenantLock } from "./shared";
import "server-only";
import { db } from "../db";
import { resolveSession } from "../auth/session-store";
import {
  requirePractice,
  requireWrite,
  requireClinical,
} from "../security/policy";
import { patientSchema } from "@/lib/validation";
import { AccessError } from "../security/errors";
// Każda operacja ponownie rozwiązuje niejawny identyfikator sesji po stronie serwera.
// Żadna metoda nie przyjmuje tenantId ani Prisma WhereInput z żądania.
export function practiceRepository(sessionId: string) {
  async function context(write = false) {
    const { principal } = await resolveSession(sessionId);
    if (write) requireWrite(principal);
    else requirePractice(principal);
    return principal;
  }
  return {
    async summary() {
      const p = await context();
      const [tenant, members] = await db.$transaction([
        db.tenant.findUniqueOrThrow({
          where: { id: p.tenantId },
          select: {
            name: true,
            status: true,
            trialEndsAt: true,
            timezone: true,
            createdAt: true,
          },
        }),
        db.user.findMany({
          where: { tenantId: p.tenantId, active: true },
          select: { id: true, name: true, role: true },
          orderBy: { createdAt: "asc" },
        }),
      ]);
      return { ...tenant, status: p.status, members };
    },
    async listPatients() {
      const p = await context();
      return db.$transaction(async (tx) => {
        const records = await tx.patient.findMany({
          where: { tenantId: p.tenantId, archivedAt: null },
          select: { id: true, firstName: true, lastName: true, status: true },
          take: 100,
          orderBy: { lastName: "asc" },
        });
        await tx.auditLog.create({
          data: {
            tenantId: p.tenantId,
            actorId: p.userId,
            action: "PATIENT_LIST_READ",
          },
        });
        return records;
      });
    },
    async getPatient(id: string) {
      const p = await context();
      return db.$transaction(async (tx) => {
        const record = await tx.patient.findUnique({
          where: { tenantId_id: { tenantId: p.tenantId, id } },
        });
        if (!record) throw new AccessError(404, "Nie znaleziono pacjenta.");
        await tx.auditLog.create({
          data: {
            tenantId: p.tenantId,
            actorId: p.userId,
            action: "PATIENT_READ",
            resourceId: id,
          },
        });
        return record;
      });
    },
    async createPatient(input: unknown) {
      const p = await context(true);
      const data = patientSchema.parse(input);
      return db.$transaction(async (tx) => {
        await tenantLock(tx, p.tenantId);
        await capacity(tx, p.tenantId, "patient");
        const record = await tx.patient.create({
          data: { ...data, tenantId: p.tenantId },
        });
        await tx.auditLog.create({
          data: {
            tenantId: p.tenantId,
            actorId: p.userId,
            action: "PATIENT_CREATE",
            resourceId: record.id,
          },
        });
        return record;
      });
    },
    async archivePatient(id: string) {
      const p = await context(true);
      return db.$transaction(async (tx) => {
        const result = await tx.patient.updateMany({
          where: { tenantId: p.tenantId, id, archivedAt: null },
          data: { archivedAt: new Date() },
        });
        if (!result.count)
          throw new AccessError(404, "Nie znaleziono pacjenta.");
        await tx.auditLog.create({
          data: {
            tenantId: p.tenantId,
            actorId: p.userId,
            action: "PATIENT_ARCHIVE",
            resourceId: id,
          },
        });
      });
    },
    async clinicalAccess() {
      const p = await context();
      requireClinical(p);
      return true; // Guard do przyszłego repozytorium notatek; bez treści klinicznych w etapie 1.
    },
  };
}

import "server-only";
import { randomBytes, randomUUID, createHash } from "node:crypto";
import { z } from "zod";
import { db } from "../db";
import { locked, notFound, practiceContext, ownerOnly, audit } from "./shared";
import { wrapSecret, unwrapSecret } from "../security/crypto";
import { sendMessage, type MessagePayload } from "../messaging";
import { AccessError } from "../security/errors";
export async function enqueueReminders(now = new Date()) {
  const rows = await db.appointment.findMany({
    where: {
      status: "SCHEDULED",
      startsAt: { gt: now, lte: new Date(+now + 24 * 3600000) },
      patient: { consentContact: true, archivedAt: null },
      tenant: { status: { in: ["ACTIVE", "TRIAL"] } },
    },
    include: { patient: true, tenant: true },
    take: 1000,
    orderBy: { startsAt: "asc" },
  });
  let queued = 0;
  for (const appointment of rows)
    await locked(appointment.tenantId, async (tx) => {
      const live = await tx.appointment.findFirst({
        where: {
          id: appointment.id,
          tenantId: appointment.tenantId,
          status: "SCHEDULED",
          version: appointment.version,
        },
        include: { patient: true, tenant: true },
      });
      if (!live || !live.patient.consentContact) return;
      if (
        live.tenant.status === "TRIAL" &&
        live.tenant.trialEndsAt &&
        live.tenant.trialEndsAt <= now
      )
        return;
      for (const [channel, to, enabled] of [
        ["EMAIL", live.patient.email, live.tenant.emailReminders],
        ["SMS", live.patient.phone, live.tenant.smsReminders],
      ] as const) {
        if (!to || !enabled) continue;
        const dedupeKey = `reminder:${live.id}:${live.version}:${channel}`;
        if (
          await tx.outboxMessage.findUnique({
            where: {
              tenantId_dedupeKey: { tenantId: live.tenantId, dedupeKey },
            },
          })
        )
          continue;
        const token = randomBytes(32).toString("base64url"),
          id = randomUUID();
        await tx.appointmentToken.create({
          data: {
            tenantId: live.tenantId,
            appointmentId: live.id,
            appointmentVersion: live.version,
            tokenHash: createHash("sha256").update(token).digest("hex"),
            expiresAt: live.startsAt,
          },
        });
        const time = live.startsAt.toLocaleString("pl-PL", {
          timeZone: live.tenant.timezone,
        });
        const url = `${process.env.NEXTAUTH_URL}/wizyta/${token}`;
        const payload = {
          to,
          subject: "Przypomnienie o wizycie",
          text: `Przypomnienie: wizyta ${time}. Potwierdź lub odwołaj: ${url}`,
        };
        await tx.outboxMessage.create({
          data: {
            id,
            tenantId: live.tenantId,
            appointmentId: live.id,
            appointmentVersion: live.version,
            channel,
            dedupeKey,
            payloadEncrypted: wrapSecret(
              JSON.stringify(payload),
              `message:${id}`,
            ),
          },
        });
        queued++;
      }
    });
  return { queued };
}
export async function deliverOutbox(limit = 50) {
  let sent = 0,
    failed = 0;
  for (let i = 0; i < limit; i++) {
    const now = new Date();
    const candidate = await db.outboxMessage.findFirst({
      where: {
        attempts: { lt: 5 },
        availableAt: { lte: now },
        OR: [
          { status: "PENDING" },
          { status: "PROCESSING", lockedUntil: { lt: now } },
        ],
      },
      orderBy: { createdAt: "asc" },
    });
    if (!candidate) break;
    const leaseId = randomUUID();
    const claim = await db.outboxMessage.updateMany({
      where: {
        id: candidate.id,
        tenantId: candidate.tenantId,
        attempts: candidate.attempts,
        OR: [
          { status: "PENDING" },
          { status: "PROCESSING", lockedUntil: { lt: now } },
        ],
      },
      data: {
        status: "PROCESSING",
        leaseId,
        lockedUntil: new Date(+now + 120000),
        attempts: { increment: 1 },
      },
    });
    if (!claim.count) continue;
    try {
      if (
        candidate.attempts > 0 &&
        Date.now() - candidate.createdAt.getTime() > 23 * 3600000
      ) {
        await db.outboxMessage.updateMany({
          where: { id: candidate.id, leaseId },
          data: {
            status: "FAILED",
            lockedUntil: null,
            lastError: "IDEMPOTENCY_WINDOW_EXPIRED",
          },
        });
        continue;
      }
      if (
        candidate.dedupeKey.startsWith("account:") &&
        Date.now() - candidate.createdAt.getTime() > 3600000
      ) {
        await db.outboxMessage.updateMany({
          where: { id: candidate.id, leaseId },
          data: { status: "CANCELLED", lockedUntil: null },
        });
        continue;
      }
      if (candidate.appointmentId) {
        const a = await db.appointment.findFirst({
          where: {
            id: candidate.appointmentId,
            tenantId: candidate.tenantId,
            status: "SCHEDULED",
            version: candidate.appointmentVersion ?? undefined,
            startsAt: { gt: now },
            patient: { consentContact: true, archivedAt: null },
            tenant: { status: { in: ["ACTIVE", "TRIAL"] } },
          },
        });
        if (!a) {
          await db.outboxMessage.updateMany({
            where: { id: candidate.id, leaseId },
            data: { status: "CANCELLED", lockedUntil: null },
          });
          continue;
        }
      }
      const payload = JSON.parse(
        unwrapSecret(candidate.payloadEncrypted, `message:${candidate.id}`),
      ) as MessagePayload;
      const providerId = await sendMessage(
        candidate.channel,
        payload,
        candidate.id,
      );
      await db.outboxMessage.updateMany({
        where: { id: candidate.id, leaseId },
        data: {
          status: "SENT",
          providerId,
          sentAt: new Date(),
          lockedUntil: null,
          lastError: null,
        },
      });
      sent++;
    } catch (e) {
      const reason =
        e instanceof Error && /^[A-Z_0-9]+$/.test(e.message)
          ? e.message
          : "DELIVERY_FAILED";
      await db.outboxMessage.updateMany({
        where: { id: candidate.id, leaseId },
        data: {
          status: candidate.attempts + 1 >= 5 ? "FAILED" : "PENDING",
          lockedUntil: null,
          lastError: reason,
          availableAt: new Date(
            Date.now() + Math.min(60, 2 ** candidate.attempts) * 60000,
          ),
        },
      });
      failed++;
    }
  }
  return { sent, failed };
}
export async function appointmentTokenInfo(token: string) {
  if (token.length < 40 || token.length > 100) notFound();
  const record = await db.appointmentToken.findUnique({
    where: { tokenHash: createHash("sha256").update(token).digest("hex") },
    include: { appointment: { include: { tenant: true } } },
  });
  if (
    !record ||
    record.expiresAt <= new Date() ||
    record.consumedAt ||
    record.appointment.status !== "SCHEDULED" ||
    record.appointment.version !== record.appointmentVersion ||
    record.appointment.tenant.status === "SUSPENDED"
  )
    notFound("Link jest nieprawidłowy, wygasł lub został już wykorzystany.");
  return {
    startsAt: record.appointment.startsAt,
    timezone: record.appointment.tenant.timezone,
  };
}
export async function useAppointmentToken(token: string, action: unknown) {
  const next = z.enum(["confirm", "cancel"]).parse(action);
  await appointmentTokenInfo(token);
  const record = await db.appointmentToken.findUniqueOrThrow({
    where: { tokenHash: createHash("sha256").update(token).digest("hex") },
  });
  return locked(record.tenantId, async (tx) => {
    const used = await tx.appointmentToken.updateMany({
      where: {
        id: record.id,
        tenantId: record.tenantId,
        consumedAt: null,
        expiresAt: { gt: new Date() },
      },
      data: { consumedAt: new Date(), action: next },
    });
    if (!used.count) throw new AccessError(409, "Link został już użyty.");
    const changed = await tx.appointment.updateMany({
      where: {
        id: record.appointmentId,
        tenantId: record.tenantId,
        status: "SCHEDULED",
        version: record.appointmentVersion,
      },
      data:
        next === "cancel"
          ? { status: "CANCELLED", version: { increment: 1 } }
          : { confirmedAt: new Date() },
    });
    if (!changed.count)
      throw new AccessError(
        409,
        "Termin został zmieniony. Skontaktuj się z gabinetem.",
      );
    await tx.auditLog.create({
      data: {
        tenantId: record.tenantId,
        action: next === "cancel" ? "PATIENT_CANCEL" : "PATIENT_CONFIRM",
        resourceId: record.appointmentId,
      },
    });
    return {
      message:
        next === "cancel"
          ? "Wizyta została odwołana."
          : "Dziękujemy za potwierdzenie wizyty.",
    };
  });
}
export async function reminderSettings(sid: string, input?: unknown) {
  const { principal: p, user } = await practiceContext(sid, !!input);
  ownerOnly(p.role);
  if (input) {
    const data = z
      .object({ emailReminders: z.boolean(), smsReminders: z.boolean() })
      .strict()
      .parse(input);
    await db.$transaction(async (tx) => {
      await tx.tenant.update({ where: { id: p.tenantId }, data });
      await audit(tx, p, "REMINDER_SETTINGS_UPDATE");
    });
  }
  return {
    emailReminders: user.tenant.emailReminders,
    smsReminders: user.tenant.smsReminders,
    emailConfigured: !!process.env.RESEND_API_KEY,
    smsConfigured: !!process.env.SMSAPI_TOKEN,
    messages: await db.outboxMessage.findMany({
      where: { tenantId: p.tenantId },
      select: {
        id: true,
        channel: true,
        status: true,
        attempts: true,
        lastError: true,
        sentAt: true,
        createdAt: true,
      },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
  };
}

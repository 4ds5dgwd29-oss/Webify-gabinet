import { capacity } from "./commerce";
import "server-only";
import { z } from "zod";
import Papa from "papaparse";
import { DateTime } from "luxon";
import { db } from "../db";
import { patientInput } from "@/lib/domain";
import { practiceContext, audit, locked, notFound, ownerOnly } from "./shared";
import { AccessError } from "../security/errors";
export async function patients(sid: string, input: unknown) {
  const { principal: p } = await practiceContext(sid);
  const q = z
    .object({
      search: z.string().max(100).default(""),
      status: z.enum(["ACTIVE", "COMPLETED", "WAITLIST", ""]).default(""),
      archived: z.boolean().default(false),
      tag: z.string().max(40).default(""),
      page: z.number().int().min(1).max(10000).default(1),
    })
    .parse(input);
  const where = {
    tenantId: p.tenantId,
    archivedAt: q.archived ? { not: null } : null,
    ...(q.status ? { status: q.status } : {}),
    ...(q.tag ? { tags: { has: q.tag } } : {}),
    ...(q.search
      ? {
          OR: [
            { firstName: { contains: q.search, mode: "insensitive" as const } },
            { lastName: { contains: q.search, mode: "insensitive" as const } },
            { phone: { contains: q.search } },
            { email: { contains: q.search, mode: "insensitive" as const } },
          ],
        }
      : {}),
  };
  return db.$transaction(async (tx) => {
    const items = await tx.patient.findMany({
      where,
      take: 25,
      skip: (q.page - 1) * 25,
      orderBy: [{ lastName: "asc" }, { id: "asc" }],
    });
    const total = await tx.patient.count({ where });
    await audit(tx, p, "PATIENT_LIST_READ");
    return { items, total, page: q.page };
  });
}
function normalized(input: unknown) {
  const data = patientInput.parse(input);
  if (data.birthDate && !DateTime.fromISO(data.birthDate).isValid)
    throw new AccessError(409, "Nieprawidłowa data urodzenia.");
  if (data.birthDate > new Date().toISOString().slice(0, 10))
    throw new AccessError(409, "Data urodzenia nie może być w przyszłości.");
  return {
    ...data,
    tags: [...new Set(data.tags)],
    birthDate: data.birthDate ? new Date(data.birthDate + "T00:00:00Z") : null,
    email: data.email || null,
    phone: data.phone || null,
    emergencyName: data.emergencyName || null,
    emergencyPhone: data.emergencyPhone || null,
    consentUpdatedAt: new Date(),
  };
}
export async function savePatient(
  sid: string,
  input: unknown,
  id?: string,
  version?: number,
) {
  const { principal: p } = await practiceContext(sid, true);
  const data = normalized(input);
  return locked(p.tenantId, async (tx) => {
    if (id) {
      if (!Number.isInteger(version))
        throw new AccessError(409, "Brak wersji karty.");
      const result = await tx.patient.updateMany({
        where: { tenantId: p.tenantId, id, version, archivedAt: null },
        data: { ...data, version: { increment: 1 } },
      });
      if (!result.count)
        throw new AccessError(
          409,
          "Karta została zmieniona lub jest niedostępna. Odśwież stronę.",
        );
      await audit(tx, p, "PATIENT_UPDATE", id);
      return { id };
    }
    await capacity(tx, p.tenantId, "patient");
    const record = await tx.patient.create({
      data: { ...data, tenantId: p.tenantId },
    });
    await audit(tx, p, "PATIENT_CREATE", record.id);
    return { id: record.id };
  });
}
export async function restorePatient(sid: string, id: string) {
  const { principal: p } = await practiceContext(sid, true);
  return locked(p.tenantId, async (tx) => {
    await capacity(tx, p.tenantId, "patient");
    const result = await tx.patient.updateMany({
      where: { tenantId: p.tenantId, id, archivedAt: { not: null } },
      data: { archivedAt: null, version: { increment: 1 } },
    });
    if (!result.count) notFound();
    await audit(tx, p, "PATIENT_RESTORE", id);
  });
}
export function parsePatientsCsv(csv: string) {
  const parsed = Papa.parse<Record<string, string>>(csv, {
    header: true,
    skipEmptyLines: true,
    transformHeader: (h) => h.trim().toLowerCase(),
  });
  if (parsed.errors.length || parsed.data.length > 500)
    throw new AccessError(409, "Niepoprawny CSV lub więcej niż 500 wierszy.");
  return parsed.data.map((row, index) => {
    try {
      return normalized({
        firstName: row.imie,
        lastName: row.nazwisko,
        email: row.email || "",
        phone: row.telefon || "",
        birthDate: row.data_urodzenia || "",
        consentData: false,
        consentContact: false,
        consentRecording: false,
        tags: ["Import CSV"],
      });
    } catch {
      throw new AccessError(
        409,
        `Niepoprawne dane w wierszu ${index + 2}. Wymagane kolumny: imie,nazwisko,email,telefon,data_urodzenia.`,
      );
    }
  });
}
export async function importPatients(sid: string, csv: string) {
  const { principal: p } = await practiceContext(sid, true);
  ownerOnly(p.role);
  const rows = parsePatientsCsv(csv);
  return locked(p.tenantId, async (tx) => {
    let imported = 0,
      skipped = 0;
    for (const row of rows) {
      const exists = row.email
        ? await tx.patient.findFirst({
            where: { tenantId: p.tenantId, email: row.email },
            select: { id: true },
          })
        : null;
      if (exists) {
        skipped++;
        continue;
      }
      await capacity(tx, p.tenantId, "patient");
      await tx.patient.create({ data: { ...row, tenantId: p.tenantId } });
      imported++;
    }
    await audit(tx, p, "PATIENT_CSV_IMPORT");
    await tx.tenant.update({
      where: { id: p.tenantId },
      data: { onboardingStep: 3 },
    });
    return { imported, skipped };
  });
}

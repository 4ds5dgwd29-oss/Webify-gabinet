import "server-only";
import { randomBytes, randomUUID, createHash } from "node:crypto";
import { z } from "zod";
import { db } from "../db";
import { emailSchema, passwordSchema } from "@/lib/validation";
import { hashPassword } from "../auth/password";
import { wrapSecret } from "../security/crypto";
import { locked, practiceContext, ownerOnly, audit, notFound } from "./shared";
import { capacity } from "./commerce";
import { AccessError } from "../security/errors";
export async function issueReset(userId: string, tenantId: string) {
  return locked(tenantId, async (tx) => {
    const user = await tx.user.findFirst({
      where: { id: userId, tenantId, active: true },
    });
    if (!user) return;
    const token = randomBytes(32).toString("base64url"),
      id = randomUUID();
    await tx.accountToken.updateMany({
      where: { tenantId, userId, consumedAt: null },
      data: { consumedAt: new Date() },
    });
    await tx.accountToken.create({
      data: {
        tenantId,
        userId,
        tokenHash: createHash("sha256").update(token).digest("hex"),
        expiresAt: new Date(Date.now() + 3600000),
      },
    });
    await tx.outboxMessage.create({
      data: {
        id,
        tenantId,
        channel: "EMAIL",
        dedupeKey: `account:${id}`,
        payloadEncrypted: wrapSecret(
          JSON.stringify({
            to: user.email,
            subject: "Ustaw hasło do Webify Gabinet",
            text: `Link jest ważny przez godzinę. Ustaw hasło: ${process.env.NEXTAUTH_URL}/nowe-haslo?token=${token}\nJeżeli nie proszono o tę zmianę, pomiń wiadomość.`,
          }),
          `message:${id}`,
        ),
      },
    });
    await tx.auditLog.create({
      data: { tenantId, action: "PASSWORD_RESET_ISSUED", resourceId: user.id },
    });
  });
}
export async function requestReset(email: unknown) {
  const parsed = emailSchema.parse(email);
  const user = await db.user.findUnique({
    where: { email: parsed },
    select: { id: true, tenantId: true },
  });
  if (user) await issueReset(user.id, user.tenantId);
  return {
    message: "Jeżeli konto istnieje, otrzymasz wiadomość z instrukcją.",
  };
}
export async function resetPassword(input: unknown) {
  const d = z
    .object({ token: z.string().min(40).max(100), password: passwordSchema })
    .strict()
    .parse(input);
  const tokenHash = createHash("sha256").update(d.token).digest("hex"),
    record = await db.accountToken.findUnique({ where: { tokenHash } });
  if (!record || record.consumedAt || record.expiresAt < new Date())
    throw new AccessError(409, "Link wygasł lub jest niepoprawny.");
  const passwordHash = await hashPassword(d.password);
  await locked(record.tenantId, async (tx) => {
    const used = await tx.accountToken.updateMany({
      where: {
        id: record.id,
        tenantId: record.tenantId,
        consumedAt: null,
        expiresAt: { gt: new Date() },
      },
      data: { consumedAt: new Date() },
    });
    if (!used.count) throw new AccessError(409, "Link został już użyty.");
    await tx.user.update({
      where: { tenantId_id: { tenantId: record.tenantId, id: record.userId } },
      data: { passwordHash, sessionVersion: { increment: 1 } },
    });
    await tx.authSession.updateMany({
      where: {
        tenantId: record.tenantId,
        userId: record.userId,
        revokedAt: null,
      },
      data: { revokedAt: new Date() },
    });
    await tx.auditLog.create({
      data: {
        tenantId: record.tenantId,
        actorId: record.userId,
        action: "PASSWORD_RESET_COMPLETED",
      },
    });
  });
  return {
    message:
      "Hasło zmienione. Zaloguj się ponownie. Włączone 2FA nadal obowiązuje.",
  };
}
export async function team(sid: string) {
  const { principal: p } = await practiceContext(sid);
  ownerOnly(p.role);
  return db.user
    .findMany({
      where: { tenantId: p.tenantId },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
        active: true,
        totpSecretEncrypted: true,
      },
    })
    .then((rows) =>
      rows.map(({ totpSecretEncrypted, ...r }) => ({
        ...r,
        twoFactor: !!totpSecretEncrypted,
      })),
    );
}
export async function invite(sid: string, input: unknown) {
  const { principal: p } = await practiceContext(sid, true);
  ownerOnly(p.role);
  const d = z
    .object({
      name: z.string().trim().min(2).max(100),
      email: emailSchema,
      role: z.enum(["OWNER", "STAFF"]),
    })
    .strict()
    .parse(input);
  const hash = await hashPassword(randomBytes(40).toString("base64url"));
  const user = await locked(p.tenantId, async (tx) => {
    await capacity(tx, p.tenantId, "user");
    if (await tx.user.findUnique({ where: { email: d.email } }))
      throw new AccessError(409, "Nie można zaprosić tego adresu.");
    const user = await tx.user.create({
      data: { ...d, tenantId: p.tenantId, passwordHash: hash },
    });
    await audit(tx, p, "USER_INVITE", user.id);
    return user;
  });
  await issueReset(user.id, p.tenantId);
  return { ok: true };
}
export async function setMember(sid: string, input: unknown) {
  const { principal: p } = await practiceContext(sid, true);
  ownerOnly(p.role);
  const d = z
    .object({
      id: z.string(),
      role: z.enum(["OWNER", "STAFF"]),
      active: z.boolean(),
    })
    .strict()
    .parse(input);
  if (d.id === p.userId)
    throw new AccessError(
      409,
      "Nie możesz zmienić własnej roli ani wyłączyć własnego konta.",
    );
  await locked(p.tenantId, async (tx) => {
    const u = await tx.user.findFirst({
      where: { id: d.id, tenantId: p.tenantId },
    });
    if (!u) notFound();
    if (!u.active && d.active) await capacity(tx, p.tenantId, "user");
    if (
      (!d.active || d.role !== "OWNER") &&
      (await tx.appointment.count({
        where: {
          tenantId: p.tenantId,
          providerId: u.id,
          status: "SCHEDULED",
          startsAt: { gt: new Date() },
        },
      }))
    )
      throw new AccessError(
        409,
        "Najpierw przekaż zaplanowane wizyty innemu prowadzącemu.",
      );
    await tx.user.update({
      where: { id: u.id },
      data: {
        role: d.role,
        active: d.active,
        sessionVersion: { increment: 1 },
      },
    });
    await audit(tx, p, "USER_ACCESS_UPDATE", u.id);
  });
}

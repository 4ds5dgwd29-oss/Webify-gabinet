import "server-only";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { db } from "../db";
import { practiceContext, audit, locked, notFound } from "./shared";
import {
  tenantKey,
  cleanNote,
  encryptClinical,
  decryptClinical,
} from "../security/clinical";
import { AccessError } from "../security/errors";
import { noteTemplates } from "@/lib/note-templates";
export async function saveNote(sid: string, input: unknown) {
  const { principal: p, user } = await practiceContext(sid, true, true);
  const data = z
    .object({
      id: z.string().optional(),
      patientId: z.string(),
      appointmentId: z.string().nullable().optional(),
      html: z.string().max(200000),
      private: z.boolean(),
      version: z.number().int().min(0),
    })
    .strict()
    .parse(input);
  const key = tenantKey(user.tenant);
  return locked(p.tenantId, async (tx) => {
    if (
      !(await tx.patient.findFirst({
        where: { id: data.patientId, tenantId: p.tenantId },
      }))
    )
      notFound();
    if (
      data.appointmentId &&
      !(await tx.appointment.findFirst({
        where: {
          id: data.appointmentId,
          tenantId: p.tenantId,
          patientId: data.patientId,
        },
      }))
    )
      notFound("Wizyta nie należy do tego pacjenta.");
    const old = data.id
      ? await tx.clinicalNote.findFirst({
          where: {
            id: data.id,
            tenantId: p.tenantId,
            patientId: data.patientId,
            authorId: p.userId,
          },
        })
      : null;
    if (data.id && !old) notFound();
    if ((old?.version ?? 0) !== data.version)
      throw new AccessError(
        409,
        "Notatka została zmieniona w innym oknie. Zachowaj swoją treść i odśwież historię.",
      );
    const id = old?.id ?? randomUUID(),
      version = (old?.version ?? 0) + 1;
    const contentEncrypted = encryptClinical(
      cleanNote(data.html),
      key,
      p.tenantId,
      `note:${id}:${version}`,
    );
    const record = old
      ? await tx.clinicalNote.update({
          where: { id },
          data: { contentEncrypted, private: data.private, version },
        })
      : await tx.clinicalNote.create({
          data: {
            id,
            tenantId: p.tenantId,
            patientId: data.patientId,
            appointmentId: data.appointmentId || null,
            authorId: p.userId,
            private: data.private,
            contentEncrypted,
            version,
          },
        });
    await tx.noteVersion.create({
      data: { tenantId: p.tenantId, noteId: id, version, contentEncrypted },
    });
    await audit(tx, p, "NOTE_SAVE", id);
    return { id: record.id, version, updatedAt: record.updatedAt };
  });
}
export async function readNote(sid: string, id: string, version?: number) {
  const { principal: p, user } = await practiceContext(sid, false, true);
  return db.$transaction(async (tx) => {
    const note = await tx.clinicalNote.findFirst({
      where: {
        id,
        tenantId: p.tenantId,
        OR: [{ private: false }, { authorId: p.userId }],
      },
    });
    if (!note) notFound();
    const selected = version
      ? await tx.noteVersion.findUnique({
          where: {
            tenantId_noteId_version: {
              tenantId: p.tenantId,
              noteId: id,
              version,
            },
          },
        })
      : note;
    if (!selected) notFound();
    const html = decryptClinical(
      selected.contentEncrypted,
      tenantKey(user.tenant),
      p.tenantId,
      `note:${id}:${selected.version}`,
    );
    const versions = await tx.noteVersion.findMany({
      where: { tenantId: p.tenantId, noteId: id },
      select: { version: true, createdAt: true },
      orderBy: { version: "desc" },
    });
    await audit(tx, p, "NOTE_READ", id);
    return {
      id,
      patientId: note.patientId,
      appointmentId: note.appointmentId,
      private: note.private,
      html,
      version: selected.version,
      currentVersion: note.version,
      canEdit: note.authorId === p.userId,
      versions,
    };
  });
}
export async function patientHistory(sid: string, patientId: string) {
  const { principal: p, user } = await practiceContext(sid);
  return db.$transaction(async (tx) => {
    if (
      !(await tx.patient.findFirst({
        where: { tenantId: p.tenantId, id: patientId },
      }))
    )
      notFound();
    const appointments = await tx.appointment.findMany({
      where: { tenantId: p.tenantId, patientId },
      include: { provider: { select: { name: true } } },
      orderBy: { startsAt: "desc" },
      take: 300,
    });
    const clinical = p.role === "OWNER";
    const key = clinical ? tenantKey(user.tenant) : null;
    const notes = clinical
      ? await tx.clinicalNote.findMany({
          where: {
            tenantId: p.tenantId,
            patientId,
            OR: [{ private: false }, { authorId: p.userId }],
          },
          select: {
            id: true,
            appointmentId: true,
            private: true,
            version: true,
            createdAt: true,
            updatedAt: true,
            author: { select: { name: true } },
          },
          orderBy: { updatedAt: "desc" },
        })
      : [];
    const rawGoals = clinical
      ? await tx.therapyGoal.findMany({
          where: { tenantId: p.tenantId, patientId },
          orderBy: { createdAt: "asc" },
        })
      : [];
    const goals = rawGoals.map((g) => ({
      id: g.id,
      status: g.status,
      version: g.version,
      text: decryptClinical(
        g.contentEncrypted,
        key!,
        p.tenantId,
        `goal:${g.id}`,
      ),
    }));
    const rawPlan = clinical
      ? await tx.treatmentPlan.findUnique({
          where: { tenantId_patientId: { tenantId: p.tenantId, patientId } },
        })
      : null;
    const plan = rawPlan
      ? {
          version: rawPlan.version,
          text: decryptClinical(
            rawPlan.contentEncrypted,
            key!,
            p.tenantId,
            `plan:${patientId}`,
          ),
          summary: decryptClinical(
            rawPlan.summaryEncrypted,
            key!,
            p.tenantId,
            `summary:${patientId}`,
          ),
        }
      : null;
    const rawDocs = clinical
      ? await tx.document.findMany({
          where: { tenantId: p.tenantId, patientId, archivedAt: null },
          orderBy: { createdAt: "desc" },
        })
      : [];
    const documents = rawDocs.map((d) => ({
      id: d.id,
      name: decryptClinical(
        d.filenameEncrypted,
        key!,
        p.tenantId,
        `filename:${d.id}`,
      ),
      mimeType: d.mimeType,
      sizeBytes: d.sizeBytes,
      createdAt: d.createdAt,
    }));
    await audit(tx, p, "PATIENT_TIMELINE_READ", patientId);
    const payments = await tx.payment.findMany({
      where: { tenantId: p.tenantId, patientId },
      select: { id: true, paidAt: true, amountGrosze: true, voidedAt: true },
    });
    const timeline = [
      ...appointments.map((a) => ({
        id: a.id,
        date: a.startsAt,
        kind: "Wizyta",
        label: a.status,
      })),
      ...notes.map((n) => ({
        id: n.id,
        date: n.updatedAt,
        kind: "Notatka",
        label: `Wersja ${n.version}`,
      })),
      ...documents.map((d) => ({
        id: d.id,
        date: d.createdAt,
        kind: "Dokument",
        label: d.name,
      })),
      ...payments.map((v) => ({
        id: v.id,
        date: v.paidAt,
        kind: "Wpłata",
        label: `${(v.amountGrosze / 100).toFixed(2)} zł${v.voidedAt ? " · anulowano" : ""}`,
      })),
    ].sort((a, b) => +b.date - +a.date);
    return {
      appointments,
      notes,
      goals,
      plan,
      documents,
      clinical,
      timeline,
      timezone: user.tenant.timezone,
    };
  });
}
export async function saveGoal(sid: string, input: unknown) {
  const { principal: p, user } = await practiceContext(sid, true, true);
  const data = z
    .object({
      id: z.string().optional(),
      patientId: z.string(),
      text: z.string().trim().min(1).max(5000),
      status: z.enum(["ACTIVE", "ACHIEVED", "PAUSED"]),
      version: z.number().int().default(0),
    })
    .strict()
    .parse(input);
  return locked(p.tenantId, async (tx) => {
    if (
      !(await tx.patient.findFirst({
        where: { id: data.patientId, tenantId: p.tenantId },
      }))
    )
      notFound();
    const id = data.id ?? randomUUID(),
      contentEncrypted = encryptClinical(
        data.text,
        tenantKey(user.tenant),
        p.tenantId,
        `goal:${id}`,
      );
    if (data.id) {
      const updated = await tx.therapyGoal.updateMany({
        where: {
          id,
          tenantId: p.tenantId,
          patientId: data.patientId,
          version: data.version,
        },
        data: {
          contentEncrypted,
          status: data.status,
          version: { increment: 1 },
        },
      });
      if (!updated.count)
        throw new AccessError(409, "Cel zmienił się. Odśwież kartę.");
    } else
      await tx.therapyGoal.create({
        data: {
          id,
          tenantId: p.tenantId,
          patientId: data.patientId,
          contentEncrypted,
          status: data.status,
        },
      });
    await audit(tx, p, "THERAPY_GOAL_SAVE", id);
  });
}
export async function savePlan(sid: string, input: unknown) {
  const { principal: p, user } = await practiceContext(sid, true, true);
  const data = z
    .object({
      patientId: z.string(),
      text: z.string().max(100000),
      summary: z.string().max(30000),
      version: z.number().int().min(0),
    })
    .strict()
    .parse(input);
  return locked(p.tenantId, async (tx) => {
    if (
      !(await tx.patient.findFirst({
        where: { id: data.patientId, tenantId: p.tenantId },
      }))
    )
      notFound();
    const old = await tx.treatmentPlan.findUnique({
      where: {
        tenantId_patientId: { tenantId: p.tenantId, patientId: data.patientId },
      },
    });
    if ((old?.version ?? 0) !== data.version)
      throw new AccessError(409, "Plan zmienił się. Odśwież kartę.");
    const key = tenantKey(user.tenant),
      values = {
        contentEncrypted: encryptClinical(
          data.text,
          key,
          p.tenantId,
          `plan:${data.patientId}`,
        ),
        summaryEncrypted: encryptClinical(
          data.summary,
          key,
          p.tenantId,
          `summary:${data.patientId}`,
        ),
      };
    await tx.treatmentPlan.upsert({
      where: {
        tenantId_patientId: { tenantId: p.tenantId, patientId: data.patientId },
      },
      create: { tenantId: p.tenantId, patientId: data.patientId, ...values },
      update: { ...values, version: { increment: 1 } },
    });
    await audit(tx, p, "TREATMENT_PLAN_SAVE", data.patientId);
  });
}
export async function templates(sid: string) {
  const { principal: p, user } = await practiceContext(sid, false, true);
  const rows = await db.noteTemplate.findMany({
    where: { tenantId: p.tenantId },
    orderBy: { name: "asc" },
  });
  return [
    ...noteTemplates,
    ...rows.map((t) => ({
      id: t.id,
      name: t.name,
      html: decryptClinical(
        t.contentEncrypted,
        tenantKey(user.tenant),
        p.tenantId,
        `template:${t.id}`,
      ),
    })),
  ];
}
export async function saveTemplate(sid: string, input: unknown) {
  const { principal: p, user } = await practiceContext(sid, true, true);
  const data = z
    .object({
      name: z.string().trim().min(1).max(100),
      html: z.string().max(200000),
    })
    .strict()
    .parse(input);
  const id = randomUUID();
  return db.$transaction(async (tx) => {
    await tx.noteTemplate.create({
      data: {
        id,
        tenantId: p.tenantId,
        name: data.name,
        contentEncrypted: encryptClinical(
          cleanNote(data.html),
          tenantKey(user.tenant),
          p.tenantId,
          `template:${id}`,
        ),
      },
    });
    await audit(tx, p, "NOTE_TEMPLATE_CREATE", id);
    return { id };
  });
}

import "server-only";
import { Prisma } from "@prisma/client";
import { db } from "../db";
import { resolveSession } from "../auth/session-store";
import {
  requirePractice,
  requireWrite,
  requireClinical,
} from "../security/policy";
import { AccessError } from "../security/errors";
export async function practiceContext(
  sid: string,
  write = false,
  clinical = false,
) {
  const context = await resolveSession(sid);
  if (write) requireWrite(context.principal);
  else requirePractice(context.principal);
  if (clinical) requireClinical(context.principal);
  return context;
}
export function ownerOnly(role: string) {
  if (role !== "OWNER")
    throw new AccessError(
      403,
      "Ta operacja jest dostępna tylko dla właściciela.",
    );
}
export function audit(
  tx: Prisma.TransactionClient,
  p: { tenantId: string; userId: string },
  action: string,
  resourceId?: string,
) {
  return tx.auditLog.create({
    data: { tenantId: p.tenantId, actorId: p.userId, action, resourceId },
  });
}
export async function tenantLock(
  tx: Prisma.TransactionClient,
  tenantId: string,
) {
  await tx.$queryRaw`SELECT "id" FROM "Tenant" WHERE "id"=${tenantId} FOR UPDATE`;
}
export function notFound(message = "Nie znaleziono rekordu."): never {
  throw new AccessError(404, message);
}
export async function locked<T>(
  tenantId: string,
  fn: (tx: Prisma.TransactionClient) => Promise<T>,
) {
  return db.$transaction(
    async (tx) => {
      await tenantLock(tx, tenantId);
      return fn(tx);
    },
    { timeout: 20000 },
  );
}

import "server-only";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { DateTime } from "luxon";
import type { Prisma } from "@prisma/client";
import { db } from "../db";
import { practiceContext, ownerOnly, locked, audit, notFound } from "./shared";
import { serviceInput, money } from "@/lib/domain";
import {
  encryptClinical,
  decryptClinical,
  tenantKey,
} from "../security/clinical";
import { generatePdf } from "../pdf";
import { AccessError } from "../security/errors";
export async function services(sid: string) {
  const { principal: p } = await practiceContext(sid);
  return db.service.findMany({
    where: { tenantId: p.tenantId },
    orderBy: { name: "asc" },
  });
}
export async function saveService(sid: string, input: unknown, id?: string) {
  const { principal: p } = await practiceContext(sid, true);
  ownerOnly(p.role);
  const data = serviceInput.parse(input);
  return locked(p.tenantId, async (tx) => {
    if (id) {
      if (
        !(
          await tx.service.updateMany({
            where: { tenantId: p.tenantId, id },
            data,
          })
        ).count
      )
        notFound();
    } else {
      id = (
        await tx.service.create({ data: { ...data, tenantId: p.tenantId } })
      ).id;
    }
    await audit(tx, p, "SERVICE_SAVE", id);
    return { id };
  });
}
// Wywoływać wyłącznie w transakcji trzymającej blokadę tenantu.
export async function recordPayment(
  tx: Prisma.TransactionClient,
  tenantId: string,
  data: {
    appointmentId: string;
    amountGrosze: number;
    method: string;
    requestId: string;
    providerOrderId?: string;
  },
) {
  const previous = await tx.payment.findUnique({
    where: { tenantId_requestId: { tenantId, requestId: data.requestId } },
  });
  if (previous) {
    if (
      previous.appointmentId !== data.appointmentId ||
      previous.amountGrosze !== data.amountGrosze ||
      previous.method !== data.method
    )
      throw new AccessError(
        409,
        "Identyfikator płatności był już użyty dla innych danych.",
      );
    return previous;
  }
  const appointment = await tx.appointment.findFirst({
    where: { tenantId, id: data.appointmentId },
    include: { patient: true, service: true },
  });
  if (!appointment) notFound();
  const paid = await tx.payment.aggregate({
    where: { tenantId, appointmentId: appointment.id, voidedAt: null },
    _sum: { amountGrosze: true },
  });
  if (
    data.amountGrosze <= 0 ||
    !Number.isSafeInteger(data.amountGrosze) ||
    data.amountGrosze + (paid._sum.amountGrosze ?? 0) > appointment.priceGrosze
  )
    throw new AccessError(
      409,
      "Wpłata przekracza pozostałą kwotę wizyty lub jest niepoprawna.",
    );
  const tenant = await tx.tenant.update({
    where: { id: tenantId },
    data: { receiptSequence: { increment: 1 } },
  });
  const id = randomUUID(),
    paidAt = new Date(),
    receiptNumber = `${paidAt.getUTCFullYear()}/${String(tenant.receiptSequence).padStart(6, "0")}`;
  const snapshot = {
    clinic: tenant.name,
    address: tenant.address,
    nip: tenant.taxId,
    patient: `${appointment.patient.firstName} ${appointment.patient.lastName}`,
    service: appointment.service?.name || "Wizyta",
    amountGrosze: data.amountGrosze,
    method: data.method,
    date: paidAt.toISOString(),
    receiptNumber,
  };
  return tx.payment.create({
    data: {
      id,
      tenantId,
      patientId: appointment.patientId,
      ...data,
      receiptNumber,
      paidAt,
      receiptSnapshotEncrypted: encryptClinical(
        JSON.stringify(snapshot),
        tenantKey(tenant),
        tenantId,
        `receipt:${id}`,
      ),
    },
  });
}
export async function addPayment(sid: string, input: unknown) {
  const { principal: p } = await practiceContext(sid, true);
  const data = z
    .object({
      appointmentId: z.string(),
      amountGrosze: z.number().int().positive().max(10000000),
      method: z.enum(["CASH", "TRANSFER", "BLIK"]),
      requestId: z.string().uuid(),
    })
    .strict()
    .parse(input);
  return locked(p.tenantId, async (tx) => {
    const row = await recordPayment(tx, p.tenantId, data);
    await audit(tx, p, "PAYMENT_REGISTER", row.id);
    return { id: row.id };
  });
}
export async function voidPayment(sid: string, id: string) {
  const { principal: p } = await practiceContext(sid, true);
  ownerOnly(p.role);
  return locked(p.tenantId, async (tx) => {
    const row = await tx.payment.findFirst({
      where: { id, tenantId: p.tenantId, voidedAt: null },
    });
    if (!row) notFound();
    if (row.providerOrderId)
      throw new AccessError(
        409,
        "Płatność operatora wymaga zwrotu w panelu operatora i uzgodnienia rozliczenia.",
      );
    await tx.payment.update({ where: { id }, data: { voidedAt: new Date() } });
    await audit(tx, p, "PAYMENT_VOID", id);
  });
}
export async function billingData(sid: string, month: string) {
  const { principal: p, user } = await practiceContext(sid);
  if (!/^\d{4}-\d{2}$/.test(month))
    throw new AccessError(409, "Wybierz miesiąc.");
  const start = DateTime.fromISO(month + "-01", { zone: user.tenant.timezone });
  if (!start.isValid) throw new AccessError(409, "Niepoprawny miesiąc.");
  const from = start.toJSDate(),
    to = start.plus({ months: 1 }).toJSDate();
  return db.$transaction(async (tx) => {
    const rows = await tx.payment.findMany({
      where: { tenantId: p.tenantId, paidAt: { gte: from, lt: to } },
      select: {
        id: true,
        appointmentId: true,
        amountGrosze: true,
        method: true,
        receiptNumber: true,
        paidAt: true,
        voidedAt: true,
        patient: { select: { firstName: true, lastName: true } },
      },
      orderBy: { paidAt: "desc" },
      take: 1000,
    });
    const total = await tx.payment.aggregate({
      where: {
        tenantId: p.tenantId,
        voidedAt: null,
        paidAt: { gte: from, lt: to },
      },
      _sum: { amountGrosze: true },
      _count: true,
    });
    const byMethod = await tx.payment.groupBy({
      by: ["method"],
      where: {
        tenantId: p.tenantId,
        voidedAt: null,
        paidAt: { gte: from, lt: to },
      },
      _sum: { amountGrosze: true },
    });
    const due = await tx.appointment.findMany({
      where: {
        tenantId: p.tenantId,
        status: { not: "CANCELLED" },
        startsAt: {
          gte: start.minus({ months: 3 }).toJSDate(),
          lt: start.plus({ months: 2 }).toJSDate(),
        },
      },
      include: {
        patient: { select: { firstName: true, lastName: true } },
        payments: { where: { voidedAt: null }, select: { amountGrosze: true } },
      },
      orderBy: { startsAt: "desc" },
      take: 500,
    });
    await audit(tx, p, "BILLING_READ");
    return {
      payments: rows,
      totalGrosze: total._sum.amountGrosze ?? 0,
      count: total._count,
      byMethod,
      due: due
        .map((a) => ({
          id: a.id,
          name: `${a.patient.firstName} ${a.patient.lastName}`,
          startsAt: a.startsAt,
          remainingGrosze:
            a.priceGrosze -
            a.payments.reduce((sum, p) => sum + p.amountGrosze, 0),
        }))
        .filter((a) => a.remainingGrosze > 0),
    };
  });
}
export async function receiptPdf(sid: string, id: string) {
  const { principal: p, user } = await practiceContext(sid);
  const row = await db.payment.findFirst({
    where: { tenantId: p.tenantId, id },
  });
  if (!row) notFound();
  const data = JSON.parse(
    decryptClinical(
      row.receiptSnapshotEncrypted,
      tenantKey(user.tenant),
      p.tenantId,
      `receipt:${id}`,
    ),
  ) as {
    clinic: string;
    address: string;
    nip: string;
    patient: string;
    service: string;
    date: string;
    amountGrosze: number;
    method: string;
    receiptNumber: string;
  };
  await db.auditLog.create({
    data: {
      tenantId: p.tenantId,
      actorId: p.userId,
      action: "RECEIPT_READ",
      resourceId: id,
    },
  });
  return generatePdf(`Potwierdzenie płatności ${data.receiptNumber}`, [
    data.clinic,
    data.address || "",
    data.nip ? `NIP: ${data.nip}` : "",
    `Nabywca: ${data.patient}`,
    `Usługa: ${data.service}`,
    `Data wpłaty: ${new Date(data.date).toLocaleDateString("pl-PL")}`,
    `Kwota: ${money(data.amountGrosze)}`,
    `Sposób płatności: ${{ CASH: "gotówka", TRANSFER: "przelew", BLIK: "BLIK", ONLINE: "online" }[data.method] || data.method}`,
    row.voidedAt
      ? "ANULOWANO WPIS W REJESTRZE"
      : "Potwierdzono przyjęcie wpłaty.",
    "Dokument potwierdza wpłatę. Nie zastępuje faktury VAT.",
  ]);
}
export async function revenuePdf(sid: string, month: string) {
  const { user } = await practiceContext(sid);
  const data = await billingData(sid, month);
  return generatePdf(`Raport przychodów — ${month}`, [
    user.tenant.name,
    `Łączna suma wpłat: ${money(data.totalGrosze)}`,
    `Liczba wpłat: ${data.count}`,
    ...data.byMethod.map(
      (m) => `${m.method}: ${money(m._sum.amountGrosze ?? 0)}`,
    ),
    "Raport kasowy według dat wpłat. Anulowane wpisy są wyłączone z sumy.",
  ]);
}
export async function dashboard(sid: string) {
  const { principal: p, user } = await practiceContext(sid);
  const now = DateTime.now().setZone(user.tenant.timezone),
    day = now.startOf("day"),
    month = now.startOf("month"),
    cutoff = now.minus({ days: 30 }).toJSDate();
  return db.$transaction(async (tx) => {
    const today = await tx.appointment.findMany({
      where: {
        tenantId: p.tenantId,
        startsAt: { gte: day.toJSDate(), lt: day.plus({ days: 1 }).toJSDate() },
      },
      include: {
        patient: { select: { firstName: true, lastName: true } },
        provider: { select: { name: true } },
      },
      orderBy: { startsAt: "asc" },
    });
    const revenue = await tx.payment.aggregate({
      where: {
        tenantId: p.tenantId,
        voidedAt: null,
        paidAt: {
          gte: month.toJSDate(),
          lt: month.plus({ months: 1 }).toJSDate(),
        },
      },
      _sum: { amountGrosze: true },
    });
    const noShows = await tx.appointment.count({
      where: {
        tenantId: p.tenantId,
        status: "NO_SHOW",
        startsAt: {
          gte: month.toJSDate(),
          lt: month.plus({ months: 1 }).toJSDate(),
        },
      },
    });
    const inactive = await tx.patient.findMany({
      where: {
        tenantId: p.tenantId,
        status: "ACTIVE",
        archivedAt: null,
        createdAt: { lte: cutoff },
        appointments: {
          none: {
            status: { in: ["SCHEDULED", "COMPLETED"] },
            startsAt: { gte: cutoff },
          },
        },
      },
      select: { id: true, firstName: true, lastName: true },
      take: 50,
    });
    await audit(tx, p, "DASHBOARD_READ");
    return {
      name: user.name,
      practiceName: user.tenant.name,
      timezone: user.tenant.timezone,
      status: p.status,
      today,
      revenueGrosze: revenue._sum.amountGrosze ?? 0,
      noShows,
      inactive,
    };
  });
}

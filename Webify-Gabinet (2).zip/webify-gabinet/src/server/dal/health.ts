import "server-only";
import { db } from "../db";
export async function databaseReady() {
  await db.$queryRaw`SELECT 1`;
  return true;
}

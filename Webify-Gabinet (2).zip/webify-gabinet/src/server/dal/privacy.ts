import "server-only";
import { z } from "zod";
import { db } from "../db";
import { practiceContext, ownerOnly, locked, audit, notFound } from "./shared";
import { verifyPassword } from "../auth/password";
import { rateLimit } from "../auth/rate-limit";
import { AccessError } from "../security/errors";
import { patientHistory, readNote } from "./clinical";
import { downloadDocument } from "./documents";
import { deleteObject } from "../storage";
import { generatePdf } from "../pdf";
export async function privacyData(sid: string) {
  const { principal: p } = await practiceContext(sid);
  ownerOnly(p.role);
  return {
    patients: await db.patient.findMany({
      where: { tenantId: p.tenantId },
      select: {
        id: true,
        firstName: true,
        lastName: true,
        archivedAt: true,
        retentionUntil: true,
        legalHold: true,
      },
      take: 1000,
      orderBy: { lastName: "asc" },
    }),
    logs: await db.auditLog.findMany({
      where: { tenantId: p.tenantId },
      take: 200,
      orderBy: { createdAt: "desc" },
    }),
    deletions: await db.objectDeletion.count({
      where: { tenantId: p.tenantId, completedAt: null },
    }),
  };
}
export async function setRetention(sid: string, input: unknown) {
  const { principal: p } = await practiceContext(sid, true, true);
  const d = z
    .object({
      patientId: z.string(),
      retentionUntil: z.string().datetime(),
      legalHold: z.boolean(),
      reviewed: z.literal(true),
    })
    .strict()
    .parse(input);
  await locked(p.tenantId, async (tx) => {
    if (
      !(
        await tx.patient.updateMany({
          where: { id: d.patientId, tenantId: p.tenantId },
          data: {
            retentionUntil: new Date(d.retentionUntil),
            legalHold: d.legalHold,
          },
        })
      ).count
    )
      notFound();
    await audit(tx, p, "PATIENT_RETENTION_REVIEW", d.patientId);
  });
}
export async function exportPatient(sid: string, patientId: string) {
  const { principal: p } = await practiceContext(sid, false, true);
  const patient = await db.patient.findFirst({
    where: { id: patientId, tenantId: p.tenantId },
  });
  if (!patient) notFound();
  const h = await patientHistory(sid, patientId),
    notes = [];
  for (const n of h.notes) {
    const current = await readNote(sid, n.id);
    const versions = [];
    for (const v of current.versions)
      versions.push(await readNote(sid, n.id, v.version));
    notes.push({ ...current, versions });
  }
  const omittedPrivate = await db.clinicalNote.count({
    where: {
      tenantId: p.tenantId,
      patientId,
      private: true,
      authorId: { not: p.userId },
    },
  });
  const documents = [];
  for (const d of h.documents) {
    const f = await downloadDocument(sid, d.id);
    documents.push({
      name: f.name,
      mime: f.mime,
      base64: f.bytes.toString("base64"),
    });
  }
  const allAppointments = await db.appointment.findMany({
    where: { tenantId: p.tenantId, patientId },
    include: { provider: { select: { name: true } } },
    orderBy: { startsAt: "desc" },
  });
  const payments = await db.payment.findMany({
    where: { tenantId: p.tenantId, patientId },
    select: {
      amountGrosze: true,
      method: true,
      receiptNumber: true,
      paidAt: true,
      voidedAt: true,
    },
  });
  await db.auditLog.create({
    data: {
      tenantId: p.tenantId,
      actorId: p.userId,
      action: "PATIENT_EXPORT",
      resourceId: patientId,
    },
  });
  return {
    format: "Webify Gabinet 1",
    generatedAt: new Date(),
    scope: omittedPrivate
      ? "Eksport częściowy: prywatne notatki innych autorów wymagają osobnego eksportu przez tych autorów."
      : "Wszystkie notatki dostępne dla eksportującego.",
    omittedPrivate,
    patient,
    appointments: allAppointments,
    notes,
    goals: h.goals,
    plan: h.plan,
    payments,
    documents,
  };
}
export async function erasePatient(sid: string, input: unknown) {
  const { principal: p, user } = await practiceContext(sid, true, true);
  const d = z
    .object({
      patientId: z.string(),
      confirmation: z.literal("USUŃ TRWALE"),
      password: z.string().max(128),
      reviewed: z.literal(true),
    })
    .strict()
    .parse(input);
  await rateLimit("erase", p.userId, 5);
  if (!(await verifyPassword(user.passwordHash, d.password)))
    throw new AccessError(403, "Niepoprawne hasło.");
  await locked(p.tenantId, async (tx) => {
    const patient = await tx.patient.findFirst({
      where: { id: d.patientId, tenantId: p.tenantId },
    });
    if (!patient) notFound();
    if (
      !patient.archivedAt ||
      patient.legalHold ||
      !patient.retentionUntil ||
      patient.retentionUntil > new Date()
    )
      throw new AccessError(
        409,
        "Wymagana archiwizacja, upływ retencji i zdjęcie blokady prawnej.",
      );
    if (
      await tx.paymentOrder.count({
        where: {
          tenantId: p.tenantId,
          appointment: { patientId: d.patientId },
          status: { in: ["PENDING", "REVIEW"] },
        },
      })
    )
      throw new AccessError(409, "Najpierw uzgodnij otwarte płatności online.");
    const where = { tenantId: p.tenantId, patientId: d.patientId };
    const documents = await tx.document.findMany({ where });
    for (const doc of documents)
      await tx.objectDeletion.create({
        data: { tenantId: p.tenantId, objectKey: doc.objectKey },
      });
    await tx.noteVersion.deleteMany({
      where: { tenantId: p.tenantId, note: { patientId: d.patientId } },
    });
    await tx.clinicalNote.deleteMany({ where });
    await tx.therapyGoal.deleteMany({ where });
    await tx.treatmentPlan.deleteMany({ where });
    await tx.document.deleteMany({ where });
    await tx.payment.deleteMany({ where });
    const linked = {
      tenantId: p.tenantId,
      appointment: { patientId: d.patientId },
    };
    await tx.paymentOrder.deleteMany({ where: linked });
    await tx.outboxMessage.deleteMany({ where: linked });
    await tx.appointmentToken.deleteMany({ where: linked });
    await tx.appointment.deleteMany({ where });
    await tx.patient.delete({
      where: { tenantId_id: { tenantId: p.tenantId, id: d.patientId } },
    });
    await audit(tx, p, "PATIENT_ERASED", d.patientId);
  });
  return {
    message:
      "Dane usunięto z aktywnej bazy. Pliki usuwa kolejka. Kopie zapasowe wygasają według polityki retencji.",
  };
}
export async function cleanObjects() {
  const rows = await db.objectDeletion.findMany({
    where: { completedAt: null, attempts: { lt: 20 } },
    take: 50,
  });
  for (const r of rows) {
    try {
      await deleteObject(r.objectKey);
      await db.objectDeletion.update({
        where: { id: r.id },
        data: { completedAt: new Date(), attempts: { increment: 1 } },
      });
    } catch {
      await db.objectDeletion.update({
        where: { id: r.id },
        data: { attempts: { increment: 1 } },
      });
    }
  }
  await db.authSession.deleteMany({
    where: { expiresAt: { lt: new Date(Date.now() - 30 * 86400000) } },
  });
  await db.loginBucket.deleteMany({
    where: { resetAt: { lt: new Date(Date.now() - 86400000) } },
  });
  await db.accountToken.deleteMany({
    where: { expiresAt: { lt: new Date(Date.now() - 86400000) } },
  });
  await db.outboxMessage.updateMany({
    where: {
      status: { in: ["SENT", "CANCELLED", "FAILED"] },
      createdAt: { lt: new Date(Date.now() - 30 * 86400000) },
    },
    data: { payloadEncrypted: "usunięto po okresie retencji" },
  });
  return { processed: rows.length };
}
export async function legalPdf(sid: string, kind: string) {
  const { principal: p, user } = await practiceContext(sid);
  ownerOnly(p.role);
  const names: Record<string, string> = {
    privacy: "Polityka prywatności",
    terms: "Regulamin świadczenia usług",
    dpa: "Umowa powierzenia przetwarzania danych",
  };
  if (!names[kind]) notFound();
  const common = [
    `Gabinet: ${user.tenant.name}`,
    `Adres: ${user.tenant.address || "[UZUPEŁNIJ ADRES]"}`,
    `NIP: ${user.tenant.taxId || "[UZUPEŁNIJ NIP]"}`,
    "SZABLON ROBOCZY — wymaga uzupełnienia i weryfikacji przez prawnika. Nie publikować bez zatwierdzenia.",
    `Data przygotowania: ${new Date().toLocaleDateString("pl-PL")}`,
  ];
  const sections: Record<string, string[]> = {
    privacy: [
      "1. Administrator danych i kontakt",
      "Administratorem danych pacjentów jest wskazany powyżej gabinet. Kontakt w sprawach danych: [UZUPEŁNIJ]. Inspektor ochrony danych, jeśli wyznaczony: [UZUPEŁNIJ].",
      "2. Cele i podstawy przetwarzania",
      "Dane kontaktowe: organizacja wizyt. Dane o zdrowiu: udzielanie uzgodnionych świadczeń. Dane rozliczeniowe: rozliczenie usług. Dla każdego celu należy ustalić właściwą podstawę z art. 6 oraz, gdy dotyczy, art. 9 RODO: [UZUPEŁNIJ PO ANALIZIE CHARAKTERU PRAKTYKI].",
      "3. Odbiorcy i transfery",
      "Dostawcy hostingu, oprogramowania, poczty, SMS i płatności: [LISTA PODMIOTÓW, LOKALIZACJE, PODSTAWY TRANSFERÓW]. Hosting bazy i dokumentów w UE. Odrębnie zweryfikuj lokalizacje usług komunikacyjnych i płatniczych.",
      "4. Okresy przechowywania",
      "Dane kontaktowe: [OKRES]. Dokumentacja: [OKRES I PODSTAWA]. Rozliczenia: [OKRES I PODSTAWA]. Kopie zapasowe: [OKRES]. Usunięcie może podlegać ograniczeniom związanym z obowiązkiem przechowywania lub roszczeniami.",
      "5. Prawa i kontakt",
      "Zasady dostępu, sprostowania, usunięcia, ograniczenia, sprzeciwu, przenoszenia i wycofania zgody należy opisać stosownie do podstaw przetwarzania. Osoba może złożyć skargę do Prezesa UODO. Sposób weryfikacji tożsamości wnioskodawcy: [UZUPEŁNIJ].",
      "6. Dobrowolność, automatyzacja i pliki cookie",
      "Konsekwencje niepodania danych: [UZUPEŁNIJ]. System nie podejmuje decyzji klinicznych. Używane są pliki sesji niezbędne do logowania; motyw jest zapamiętywany lokalnie.",
    ],
    terms: [
      "1. Usługodawca i zakres",
      "Dane usługodawcy i kontakt: [UZUPEŁNIJ]. Zakres konsultacji i kwalifikacje prowadzących: [UZUPEŁNIJ].",
      "2. Rezerwacja",
      "Wybór terminu i usługi, podanie danych kontaktowych oraz akceptacja warunków. Termin wymagający przedpłaty oczekuje na wpłatę przez 15 minut. Potwierdzenie po weryfikacji operatora.",
      "3. Ceny i płatności",
      "Cennik publikowany przez gabinet. Formy płatności i zasady dokumentowania: [UZUPEŁNIJ]. Sposób rozliczania zadatku oraz konsekwencje niewykonania umowy wymagają indywidualnego ustalenia.",
      "4. Odwołanie, zwroty, reklamacje",
      "Termin odwołania: [UZUPEŁNIJ]. Opłaty za nieobecność, zwroty i odstąpienie: [UZUPEŁNIJ PO WERYFIKACJI PRAW KONSUMENTA]. Adres reklamacji i terminy odpowiedzi: [UZUPEŁNIJ].",
      "5. Wizyty online i dostępność",
      "Wymagania techniczne, poufne miejsce spotkania i sposób postępowania przy przerwaniu połączenia: [UZUPEŁNIJ]. Gabinet nie jest serwisem interwencji kryzysowej.",
      "6. Zmiany regulaminu",
      "Sposób informowania, data wejścia w życie, zasady dla istniejących rezerwacji: [UZUPEŁNIJ].",
    ],
    dpa: [
      "1. Strony i role",
      "Administrator: wskazany gabinet. Podmiot przetwarzający: [PEŁNE DANE OPERATORA WEBIFY].",
      "2. Przedmiot i czas",
      "Przetwarzanie danych na udokumentowane polecenie administratora w celu świadczenia usługi Webify Gabinet przez okres umowy i uzgodnionego zwrotu/usunięcia danych.",
      "3. Zakres danych i osób",
      "Pacjenci, osoby kontaktowe i użytkownicy. Dane identyfikacyjne, kontaktowe, dane wizyt, rozliczeń i dokumentacji zawierającej dane o zdrowiu. Szczegółowy załącznik: [UZUPEŁNIJ].",
      "4. Zabezpieczenia i poufność",
      "Szyfrowanie transmisji oraz dokumentacji, kontrola ról, rejestr dostępu, kopie zapasowe i odtwarzanie. Osoby upoważnione zobowiązane do poufności. Załącznik środków technicznych i organizacyjnych: [UZUPEŁNIJ].",
      "5. Dalsze powierzenie i transfery",
      "Lista podprocesorów, lokalizacje, procedura zmian i sprzeciwu: [UZUPEŁNIJ]. Transfery poza EOG wyłącznie na ustalonej podstawie i zgodnie z poleceniami administratora.",
      "6. Wsparcie i incydenty",
      "Wsparcie realizacji praw osób, oceny skutków i konsultacji. Zgłoszenie naruszenia administratorowi bez zbędnej zwłoki; kanał, zakres informacji i procedura: [UZUPEŁNIJ].",
      "7. Audyty i zakończenie",
      "Udostępnianie informacji umożliwiających wykazanie zgodności i uzgodnione audyty. Po zakończeniu zwrot lub usunięcie danych według decyzji administratora, z wyjątkiem obowiązków prawnych. Cykl wygaśnięcia kopii i procedura odtworzenia usunięć: [UZUPEŁNIJ].",
      "8. Podpisy",
      "Administrator: __________________  Podmiot przetwarzający: __________________",
    ],
  };
  await db.auditLog.create({
    data: {
      tenantId: p.tenantId,
      actorId: p.userId,
      action: "LEGAL_TEMPLATE_GENERATE",
      resourceId: kind,
    },
  });
  return generatePdf(`${names[kind]} — projekt`, [
    ...common,
    ...sections[kind],
  ]);
}

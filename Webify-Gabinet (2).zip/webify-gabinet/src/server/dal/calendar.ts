import "server-only";
import { randomUUID, randomBytes, createHash } from "node:crypto";
import { z } from "zod";
import { DateTime } from "luxon";
import type { Prisma } from "@prisma/client";
import { db } from "../db";
import { practiceContext, audit, locked, notFound, ownerOnly } from "./shared";
import { appointmentInput, hoursInput } from "@/lib/domain";
import { recurrence, ical } from "@/lib/calendar";
import { AccessError } from "../security/errors";
export async function assertSlot(
  tx: Prisma.TransactionClient,
  tenantId: string,
  providerId: string,
  patientId: string,
  range: { startsAt: Date; endsAt: Date },
  zone: string,
  excludeId?: string,
) {
  const provider = await tx.user.findFirst({
    where: { id: providerId, tenantId, role: "OWNER", active: true },
    select: { id: true },
  });
  if (!provider) notFound("Nie znaleziono prowadzącego.");
  const patient = await tx.patient.findFirst({
    where: { id: patientId, tenantId, archivedAt: null },
    select: { id: true },
  });
  if (!patient) notFound("Nie znaleziono aktywnego pacjenta.");
  const local = DateTime.fromJSDate(range.startsAt, { zone }),
    end = DateTime.fromJSDate(range.endsAt, { zone });
  const hours = await tx.workingHour.findMany({
    where: { tenantId, providerId, weekday: local.weekday },
  });
  if (
    local.toISODate() !== end.toISODate() ||
    !hours.some(
      (h) =>
        local.hour * 60 + local.minute >= h.startMinute &&
        end.hour * 60 + end.minute <= h.endMinute,
    )
  )
    throw new AccessError(
      409,
      "Termin znajduje się poza godzinami pracy prowadzącego.",
    );
  const leave = await tx.leave.findFirst({
    where: {
      tenantId,
      providerId,
      startsAt: { lt: range.endsAt },
      endsAt: { gt: range.startsAt },
    },
  });
  if (leave)
    throw new AccessError(
      409,
      "Prowadzący jest nieobecny w wybranym terminie.",
    );
  const conflict = await tx.appointment.findFirst({
    where: {
      tenantId,
      ...(excludeId ? { id: { not: excludeId } } : {}),
      status: { not: "CANCELLED" },
      OR: [{ providerId }, { patientId }],
      startsAt: { lt: range.endsAt },
      endsAt: { gt: range.startsAt },
    },
  });
  if (conflict)
    throw new AccessError(
      409,
      "Termin koliduje z inną wizytą prowadzącego lub pacjenta.",
    );
}
export async function calendarData(sid: string, from: string, to: string) {
  const { principal: p } = await practiceContext(sid);
  const start = new Date(from),
    end = new Date(to);
  if (
    !Number.isFinite(+start) ||
    !Number.isFinite(+end) ||
    end <= start ||
    +end - +start > 93 * 86400000
  )
    throw new AccessError(409, "Wybierz zakres do 93 dni.");
  return db.$transaction(async (tx) => {
    const appointments = await tx.appointment.findMany({
      where: { tenantId: p.tenantId, startsAt: { gte: start, lt: end } },
      include: {
        patient: { select: { firstName: true, lastName: true } },
        provider: { select: { name: true } },
      },
      orderBy: { startsAt: "asc" },
    });
    await audit(tx, p, "CALENDAR_READ");
    return { appointments };
  });
}
export async function calendarOptions(sid: string) {
  const { principal: p, user } = await practiceContext(sid);
  const [providers, patients, services, hours, leaves] = await db.$transaction([
    db.user.findMany({
      where: { tenantId: p.tenantId, role: "OWNER", active: true },
      select: { id: true, name: true },
    }),
    db.patient.findMany({
      where: { tenantId: p.tenantId, archivedAt: null },
      select: { id: true, firstName: true, lastName: true },
      take: 500,
      orderBy: { lastName: "asc" },
    }),
    db.service.findMany({ where: { tenantId: p.tenantId, active: true } }),
    db.workingHour.findMany({
      where: { tenantId: p.tenantId },
      orderBy: { weekday: "asc" },
    }),
    db.leave.findMany({
      where: { tenantId: p.tenantId, endsAt: { gte: new Date() } },
      orderBy: { startsAt: "asc" },
    }),
  ]);
  await db.auditLog.create({
    data: {
      tenantId: p.tenantId,
      actorId: p.userId,
      action: "CALENDAR_OPTIONS_READ",
    },
  });
  return {
    providers,
    patients,
    services,
    hours,
    leaves,
    timezone: user.tenant.timezone,
    practiceName: user.tenant.name,
    address: user.tenant.address ?? "",
    taxId: user.tenant.taxId ?? "",
    onboardingStep: user.tenant.onboardingStep,
  };
}
export async function saveAppointment(
  sid: string,
  input: unknown,
  id?: string,
  version?: number,
) {
  const { principal: p, user } = await practiceContext(sid, true);
  const data = appointmentInput.parse(input);
  let ranges;
  try {
    ranges = recurrence(
      data.localStart,
      user.tenant.timezone,
      data.durationMinutes,
      id ? 1 : data.repeatCount,
      data.repeatWeeks,
    );
  } catch (e) {
    throw new AccessError(
      409,
      e instanceof Error ? e.message : "Niepoprawny termin.",
    );
  }
  return locked(p.tenantId, async (tx) => {
    if (id) {
      const old = await tx.appointment.findFirst({
        where: { id, tenantId: p.tenantId, version, status: "SCHEDULED" },
      });
      if (!old || !version)
        throw new AccessError(
          409,
          "Wizyta została zmieniona lub nie jest zaplanowana.",
        );
    }
    let serviceId = data.serviceId || null;
    let price = data.priceGrosze;
    if (serviceId) {
      const service = await tx.service.findFirst({
        where: { id: serviceId, tenantId: p.tenantId, active: true },
      });
      if (!service) notFound("Nie znaleziono usługi.");
      price = service.priceGrosze;
    }
    const seriesId = ranges.length > 1 ? randomUUID() : null,
      ids: string[] = [];
    for (const range of ranges) {
      await assertSlot(
        tx,
        p.tenantId,
        data.providerId,
        data.patientId,
        range,
        user.tenant.timezone,
        id,
      );
      const recordData = {
        patientId: data.patientId,
        providerId: data.providerId,
        serviceId,
        type: data.type,
        onlineUrl: data.onlineUrl || null,
        priceGrosze: price,
        ...range,
      };
      const record = id
        ? await tx.appointment.update({
            where: { tenantId_id: { tenantId: p.tenantId, id } },
            data: {
              ...recordData,
              confirmedAt: null,
              version: { increment: 1 },
            },
          })
        : await tx.appointment.create({
            data: { ...recordData, tenantId: p.tenantId, seriesId },
          });
      ids.push(record.id);
      await audit(
        tx,
        p,
        id ? "APPOINTMENT_UPDATE" : "APPOINTMENT_CREATE",
        record.id,
      );
    }
    return { ids };
  });
}
export async function setAppointmentStatus(
  sid: string,
  id: string,
  status: unknown,
  version: number,
) {
  const { principal: p } = await practiceContext(sid, true);
  const next = z.enum(["COMPLETED", "CANCELLED", "NO_SHOW"]).parse(status);
  return locked(p.tenantId, async (tx) => {
    const row = await tx.appointment.findFirst({
      where: { id, tenantId: p.tenantId, version, status: "SCHEDULED" },
    });
    if (!row)
      throw new AccessError(
        409,
        "Wizyta została już zmieniona. Odśwież kalendarz.",
      );
    if (next !== "CANCELLED" && row.startsAt > new Date())
      throw new AccessError(
        409,
        "Przyszła wizyta nie może być oznaczona jako odbyta lub nieobecność.",
      );
    await tx.appointment.update({
      where: { id },
      data: { status: next, version: { increment: 1 } },
    });
    await audit(tx, p, `APPOINTMENT_${next}`, id);
  });
}
export async function saveHours(sid: string, input: unknown) {
  const { principal: p } = await practiceContext(sid, true);
  ownerOnly(p.role);
  const data = hoursInput.parse(input);
  for (const a of data.hours)
    for (const b of data.hours)
      if (
        a !== b &&
        a.weekday === b.weekday &&
        a.startMinute < b.endMinute &&
        a.endMinute > b.startMinute
      )
        throw new AccessError(409, "Przedziały godzin pracy nakładają się.");
  return locked(p.tenantId, async (tx) => {
    if (
      !(await tx.user.findFirst({
        where: {
          id: data.providerId,
          tenantId: p.tenantId,
          role: "OWNER",
          active: true,
        },
      }))
    )
      notFound();
    await tx.workingHour.deleteMany({
      where: { tenantId: p.tenantId, providerId: data.providerId },
    });
    await tx.workingHour.createMany({
      data: data.hours.map((h) => ({
        ...h,
        tenantId: p.tenantId,
        providerId: data.providerId,
      })),
    });
    await tx.tenant.update({
      where: { id: p.tenantId },
      data: { onboardingStep: 2 },
    });
    await audit(tx, p, "WORKING_HOURS_UPDATE");
  });
}
export async function saveLeave(sid: string, input: unknown) {
  const { principal: p } = await practiceContext(sid, true);
  ownerOnly(p.role);
  const data = z
    .object({
      providerId: z.string(),
      startsAt: z.string().datetime(),
      endsAt: z.string().datetime(),
      label: z.string().trim().min(1).max(120),
    })
    .strict()
    .parse(input);
  const startsAt = new Date(data.startsAt),
    endsAt = new Date(data.endsAt);
  if (endsAt <= startsAt)
    throw new AccessError(409, "Koniec urlopu musi być po początku.");
  return locked(p.tenantId, async (tx) => {
    if (
      !(await tx.user.findFirst({
        where: { id: data.providerId, tenantId: p.tenantId, role: "OWNER" },
      }))
    )
      notFound();
    if (
      await tx.appointment.count({
        where: {
          tenantId: p.tenantId,
          providerId: data.providerId,
          status: "SCHEDULED",
          startsAt: { lt: endsAt },
          endsAt: { gt: startsAt },
        },
      })
    )
      throw new AccessError(
        409,
        "Najpierw przełóż lub odwołaj wizyty przypadające w czasie urlopu.",
      );
    const leave = await tx.leave.create({
      data: { ...data, tenantId: p.tenantId, startsAt, endsAt },
    });
    await audit(tx, p, "LEAVE_CREATE", leave.id);
    return leave;
  });
}
export async function removeLeave(sid: string, id: string) {
  const { principal: p } = await practiceContext(sid, true);
  ownerOnly(p.role);
  return locked(p.tenantId, async (tx) => {
    const deleted = await tx.leave.deleteMany({
      where: { id, tenantId: p.tenantId },
    });
    if (!deleted.count) notFound();
    await audit(tx, p, "LEAVE_DELETE", id);
  });
}
export async function savePracticeSettings(sid: string, input: unknown) {
  const { principal: p } = await practiceContext(sid, true);
  ownerOnly(p.role);
  const data = z
    .object({
      name: z.string().trim().min(2).max(120),
      address: z.string().max(300),
      taxId: z.string().max(20),
      timezone: z.string().refine((s) => DateTime.now().setZone(s).isValid),
    })
    .strict()
    .parse(input);
  return locked(p.tenantId, async (tx) => {
    await tx.tenant.update({
      where: { id: p.tenantId },
      data: { ...data, onboardingStep: 1 },
    });
    await audit(tx, p, "PRACTICE_SETTINGS_UPDATE");
  });
}
export async function rotateFeed(sid: string) {
  const { principal: p } = await practiceContext(sid, true);
  const token = randomBytes(32).toString("base64url");
  await db.$transaction([
    db.user.update({
      where: { tenantId_id: { tenantId: p.tenantId, id: p.userId } },
      data: {
        calendarTokenHash: createHash("sha256").update(token).digest("hex"),
      },
    }),
    db.auditLog.create({
      data: {
        tenantId: p.tenantId,
        actorId: p.userId,
        action: "CALENDAR_FEED_ROTATE",
      },
    }),
  ]);
  return { token };
}
export async function calendarFeed(sid?: string, token?: string) {
  let tenantId: string, providerId: string | undefined;
  if (sid) {
    const { principal: p } = await practiceContext(sid);
    tenantId = p.tenantId;
  } else {
    if (!token || token.length < 40) notFound();
    const user = await db.user.findFirst({
      where: {
        calendarTokenHash: createHash("sha256").update(token).digest("hex"),
        active: true,
        tenant: { kind: "PRACTICE", status: { not: "SUSPENDED" } },
      },
    });
    if (!user) notFound();
    tenantId = user.tenantId;
    providerId = user.role === "OWNER" ? user.id : undefined;
  }
  const events = await db.appointment.findMany({
    where: {
      tenantId,
      ...(providerId ? { providerId } : {}),
      startsAt: {
        gte: new Date(Date.now() - 31 * 86400000),
        lte: new Date(Date.now() + 366 * 86400000),
      },
    },
    select: {
      id: true,
      startsAt: true,
      endsAt: true,
      status: true,
      updatedAt: true,
    },
    take: 10000,
  });
  return ical(events);
}

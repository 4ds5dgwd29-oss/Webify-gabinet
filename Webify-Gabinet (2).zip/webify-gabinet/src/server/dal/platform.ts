import "server-only";
import { db } from "../db";
import { resolveSession } from "../auth/session-store";
import { requirePlatform } from "../security/policy";
export async function listPractices(sessionId: string) {
  const { principal } = await resolveSession(sessionId);
  requirePlatform(principal);
  return db.$transaction(async (tx) => {
    await tx.auditLog.create({
      data: {
        tenantId: principal.tenantId,
        actorId: principal.userId,
        action: "PLATFORM_TENANTS_READ",
      },
    });
    // Wyłącznie metadane kont. Brak relacji patients i danych klinicznych.
    return tx.tenant.findMany({
      where: { kind: "PRACTICE" },
      select: {
        id: true,
        name: true,
        status: true,
        createdAt: true,
        trialEndsAt: true,
      },
      orderBy: { createdAt: "desc" },
      take: 100,
    });
  });
}

import { capacity } from "./commerce";
import "server-only";
import { z } from "zod";
import { db } from "../db";
import { resolveSession } from "../auth/session-store";
import { requirePlatform } from "../security/policy";
import { practiceContext, locked, audit, notFound } from "./shared";
import { AccessError } from "../security/errors";
import { stripe } from "../stripe";
import { issueReset } from "./accounts";
async function admin(sid: string) {
  const c = await resolveSession(sid);
  requirePlatform(c.principal);
  return c.principal;
}
export async function feedback(sid: string, input?: unknown) {
  const { principal: p } = await practiceContext(sid);
  if (input) {
    const d = z
      .object({
        subject: z.string().trim().min(3).max(150),
        message: z.string().trim().min(5).max(5000),
      })
      .strict()
      .parse(input);
    await db.feedback.create({ data: { ...d, tenantId: p.tenantId } });
  }
  return db.feedback.findMany({
    where: { tenantId: p.tenantId },
    orderBy: { createdAt: "desc" },
    take: 100,
  });
}
export async function adminData(sid: string) {
  const p = await admin(sid);
  return db.$transaction(async (tx) => {
    const tenants = await tx.tenant.findMany({
      where: { kind: "PRACTICE" },
      select: {
        id: true,
        name: true,
        status: true,
        planCode: true,
        createdAt: true,
        trialEndsAt: true,
        subscription: {
          select: {
            status: true,
            currentPeriodEnd: true,
            cancelAtPeriodEnd: true,
            priceId: true,
            updatedAt: true,
          },
        },
        users: {
          select: {
            sessions: {
              select: { lastSeenAt: true },
              orderBy: { lastSeenAt: "desc" },
              take: 1,
            },
          },
          orderBy: { createdAt: "asc" },
        },
      },
      take: 1000,
      orderBy: { createdAt: "desc" },
    });
    const plans = await tx.plan.findMany({
      where: { tenantId: p.tenantId },
      orderBy: { monthlyGrosze: "asc" },
    });
    const active = tenants.filter((t) => t.status === "ACTIVE"),
      paid = tenants.filter((t) => t.subscription?.status === "active");
    const mrr = paid.reduce((sum, t) => {
      const plan = plans.find((p) => p.code === t.planCode);
      return (
        sum +
        (plan
          ? t.subscription?.priceId === plan.stripeYearlyId
            ? Math.round(plan.yearlyGrosze / 12)
            : plan.monthlyGrosze
          : 0)
      );
    }, 0);
    const since = new Date(Date.now() - 30 * 86400000),
      cancelled = tenants.filter(
        (t) =>
          t.subscription?.status === "canceled" &&
          t.subscription.updatedAt >= since,
      ).length;
    await audit(tx, p, "PLATFORM_OVERVIEW_READ");
    return {
      tenants: tenants.map(({ users, ...t }) => ({
        ...t,
        lastActivity:
          users
            .flatMap((u) => u.sessions.map((s) => s.lastSeenAt))
            .sort((a, b) => +b - +a)[0] ?? null,
      })),
      plans,
      metrics: {
        active: active.length,
        mrr,
        cancelled30: cancelled,
        churn30:
          paid.length + cancelled ? cancelled / (paid.length + cancelled) : 0,
        registrations30: tenants.filter((t) => t.createdAt >= since).length,
      },
      feedback: await tx.feedback.findMany({
        select: {
          id: true,
          tenantId: true,
          subject: true,
          message: true,
          status: true,
          createdAt: true,
        },
        take: 200,
        orderBy: { createdAt: "desc" },
      }),
      logs: await tx.auditLog.findMany({
        where: { tenantId: p.tenantId },
        take: 200,
        orderBy: { createdAt: "desc" },
      }),
      systemLogs: await tx.systemLog.findMany({
        where: { tenantId: p.tenantId },
        orderBy: { createdAt: "desc" },
        take: 100,
      }),
      registrations: Array.from({ length: 12 }, (_, i) => {
        const date = new Date();
        date.setUTCDate(1);
        date.setUTCMonth(date.getUTCMonth() - 11 + i);
        const month = date.toISOString().slice(0, 7);
        return {
          month,
          count: tenants.filter((t) =>
            t.createdAt.toISOString().startsWith(month),
          ).length,
        };
      }),
      coupons: await tx.coupon.findMany({ where: { tenantId: p.tenantId } }),
    };
  });
}
export async function adminAction(sid: string, action: string, input: unknown) {
  const p = await admin(sid);
  switch (action) {
    case "tenant": {
      const d = z
        .object({
          id: z.string(),
          status: z.enum(["ACTIVE", "TRIAL", "READ_ONLY", "SUSPENDED"]),
          trialDays: z.number().int().min(0).max(365).default(0),
        })
        .strict()
        .parse(input);
      await locked(d.id, async (tx) => {
        const t = await tx.tenant.findFirst({
          where: { id: d.id, kind: "PRACTICE" },
        });
        if (!t) notFound();
        await tx.tenant.update({
          where: { id: d.id },
          data: {
            status: d.status,
            ...(d.trialDays
              ? { trialEndsAt: new Date(Date.now() + d.trialDays * 86400000) }
              : {}),
          },
        });
        await audit(tx, p, `PLATFORM_TENANT_${d.status}`, d.id);
      });
      return { ok: true };
    }
    case "plan": {
      const d = z
        .object({
          code: z.string().regex(/^[A-Z_]{2,20}$/),
          name: z.string().min(1).max(60),
          monthlyGrosze: z.number().int().min(0),
          yearlyGrosze: z.number().int().min(0),
          patientLimit: z.number().int().min(1).max(100000),
          userLimit: z.number().int().min(1).max(1000),
          trialDays: z.number().int().min(0).max(365),
          stripeMonthlyId: z.string().max(100),
          stripeYearlyId: z.string().max(100),
          active: z.boolean(),
        })
        .strict()
        .parse(input);
      await db.$transaction(async (tx) => {
        await tx.plan.upsert({
          where: { code: d.code },
          create: { ...d, tenantId: p.tenantId },
          update: d,
        });
        await audit(tx, p, "PLATFORM_PLAN_SAVE", d.code);
      });
      return { ok: true };
    }
    case "feedback": {
      const d = z
        .object({
          id: z.string(),
          status: z.enum(["NEW", "IN_PROGRESS", "DONE"]),
        })
        .strict()
        .parse(input);
      await db.$transaction(async (tx) => {
        await tx.feedback.update({
          where: { id: d.id },
          data: { status: d.status },
        });
        await audit(tx, p, "PLATFORM_FEEDBACK_STATUS", d.id);
      });
      return { ok: true };
    }
    case "coupon": {
      const d = z
        .object({
          code: z.string().regex(/^[A-Z0-9_-]{3,30}$/),
          percentOff: z.number().int().min(1).max(100),
        })
        .strict()
        .parse(input);
      const coupon = await stripe().coupons.create(
        { percent_off: d.percentOff, duration: "once", name: d.code },
        { idempotencyKey: `coupon:${d.code}` },
      );
      const promo = await stripe().promotionCodes.create(
        { promotion: { type: "coupon", coupon: coupon.id }, code: d.code },
        { idempotencyKey: `promo:${d.code}` },
      );
      await db.$transaction(async (tx) => {
        await tx.coupon.upsert({
          where: { code: d.code },
          create: { id: promo.id, tenantId: p.tenantId, ...d },
          update: {},
        });
        await audit(tx, p, "PLATFORM_COUPON_CREATE", d.code);
      });
      return { ok: true };
    }
    case "support.start": {
      const d = z
        .object({ id: z.string(), reason: z.string().trim().min(10).max(500) })
        .strict()
        .parse(input);
      if (
        !(await db.tenant.findFirst({ where: { id: d.id, kind: "PRACTICE" } }))
      )
        notFound();
      return db.$transaction(async (tx) => {
        const session = await tx.supportSession.create({
          data: {
            tenantId: p.tenantId,
            adminId: p.userId,
            targetTenantId: d.id,
            reason: d.reason,
            expiresAt: new Date(Date.now() + 15 * 60000),
          },
        });
        await audit(tx, p, "SUPPORT_IMPERSONATION_START", d.id);
        return { id: session.id };
      });
    }
    case "support.end": {
      const id = z.string().parse(input);
      await db.$transaction(async (tx) => {
        await tx.supportSession.updateMany({
          where: { id, tenantId: p.tenantId, adminId: p.userId },
          data: { endedAt: new Date() },
        });
        await audit(tx, p, "SUPPORT_IMPERSONATION_END", id);
      });
      return { ok: true };
    }
    case "user": {
      const d = z
        .object({
          tenantId: z.string(),
          userId: z.string(),
          active: z.boolean(),
        })
        .strict()
        .parse(input);
      await locked(d.tenantId, async (tx) => {
        const u = await tx.user.findFirst({
          where: { id: d.userId, tenantId: d.tenantId, tenantKind: "PRACTICE" },
        });
        if (!u) notFound();
        if (!u.active && d.active) await capacity(tx, d.tenantId, "user");
        await tx.user.update({
          where: { id: u.id },
          data: { active: d.active, sessionVersion: { increment: 1 } },
        });
        await audit(tx, p, "PLATFORM_USER_ACCESS_UPDATE", u.id);
      });
      return { ok: true };
    }
    case "reset": {
      const d = z
        .object({ tenantId: z.string(), userId: z.string() })
        .strict()
        .parse(input);
      if (
        !(await db.user.findFirst({
          where: { id: d.userId, tenantId: d.tenantId, tenantKind: "PRACTICE" },
        }))
      )
        notFound();
      await issueReset(d.userId, d.tenantId);
      await db.auditLog.create({
        data: {
          tenantId: p.tenantId,
          actorId: p.userId,
          action: "PLATFORM_PASSWORD_RESET",
          resourceId: d.userId,
        },
      });
      return { ok: true };
    }
    default:
      throw new AccessError(404, "Nieznana operacja.");
  }
}
export async function supportView(sid: string, id: string) {
  const p = await admin(sid);
  return db.$transaction(async (tx) => {
    const support = await tx.supportSession.findFirst({
      where: {
        id,
        tenantId: p.tenantId,
        adminId: p.userId,
        endedAt: null,
        expiresAt: { gt: new Date() },
      },
    });
    if (!support) notFound();
    const t = await tx.tenant.findUnique({
      where: { id: support.targetTenantId },
      select: {
        id: true,
        name: true,
        slug: true,
        status: true,
        planCode: true,
        timezone: true,
        onboardingStep: true,
        emailReminders: true,
        smsReminders: true,
        bookingEnabled: true,
        users: {
          select: {
            id: true,
            name: true,
            email: true,
            role: true,
            active: true,
          },
        },
      },
    });
    await audit(tx, p, "SUPPORT_CONFIGURATION_READ", support.targetTenantId);
    return t;
  });
}

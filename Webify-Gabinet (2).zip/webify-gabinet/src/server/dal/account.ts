import "server-only";
import { db } from "../db";
import { resolveSession } from "../auth/session-store";
import { verifyPassword } from "../auth/password";
import { rateLimit } from "../auth/rate-limit";
import { newTotp, totpStep } from "../auth/totp";
import { wrapSecret, unwrapSecret } from "../security/crypto";
import { AccessError } from "../security/errors";
import { securitySchema } from "@/lib/validation";
export async function accountSummary(sessionId: string) {
  const { user } = await resolveSession(sessionId);
  return {
    name: user.name,
    email: user.email,
    role: user.role,
    totpEnabled: !!user.totpSecretEncrypted,
  };
}
export async function changeTotp(sessionId: string, input: unknown) {
  const data = securitySchema.parse(input);
  const { user } = await resolveSession(sessionId);
  await rateLimit("totp-management", user.id);
  if (!(await verifyPassword(user.passwordHash, data.password)))
    throw new AccessError(403, "Nieprawidłowe dane uwierzytelniające.");
  const purpose = `totp:${user.tenantId}:${user.id}`;
  const where = { id: user.id, tenantId: user.tenantId };
  if (data.action === "setup") {
    if (user.totpSecretEncrypted)
      throw new AccessError(
        409,
        "Uwierzytelnianie dwuetapowe jest już włączone.",
      );
    const { secret, uri } = newTotp(user.email);
    await db.$transaction([
      db.user.update({
        where,
        data: {
          totpPendingEncrypted: wrapSecret(secret, purpose),
          totpPendingExpiresAt: new Date(Date.now() + 10 * 60_000),
        },
      }),
      db.auditLog.create({
        data: {
          tenantId: user.tenantId,
          actorId: user.id,
          action: "TOTP_SETUP_STARTED",
        },
      }),
    ]);
    return { secret, uri };
  }
  const encrypted =
    data.action === "enable"
      ? user.totpPendingEncrypted
      : user.totpSecretEncrypted;
  if (
    !encrypted ||
    !data.otp ||
    (data.action === "enable" &&
      (!user.totpPendingExpiresAt || user.totpPendingExpiresAt < new Date()))
  )
    throw new AccessError(
      403,
      "Rozpocznij konfigurację ponownie lub sprawdź kod.",
    );
  const step = totpStep(unwrapSecret(encrypted, purpose), data.otp);
  if (
    step === null ||
    (data.action === "disable" &&
      user.lastTotpStep !== null &&
      step <= user.lastTotpStep)
  )
    throw new AccessError(403, "Kod jest nieprawidłowy lub został już użyty.");
  await db.$transaction(async (tx) => {
    const updated = await tx.user.updateMany({
      where: {
        ...where,
        sessionVersion: user.sessionVersion,
        totpPendingEncrypted: user.totpPendingEncrypted,
        lastTotpStep: user.lastTotpStep,
      },
      data: {
        totpSecretEncrypted: data.action === "enable" ? encrypted : null,
        totpPendingEncrypted: null,
        totpPendingExpiresAt: null,
        lastTotpStep: data.action === "enable" ? step : null,
        sessionVersion: { increment: 1 },
      },
    });
    if (updated.count !== 1)
      throw new AccessError(
        409,
        "Konfiguracja uległa zmianie. Spróbuj ponownie.",
      );
    await tx.authSession.updateMany({
      where: { tenantId: user.tenantId, userId: user.id, revokedAt: null },
      data: { revokedAt: new Date() },
    });
    await tx.auditLog.create({
      data: {
        tenantId: user.tenantId,
        actorId: user.id,
        action: data.action === "enable" ? "TOTP_ENABLED" : "TOTP_DISABLED",
      },
    });
  });
  return { reauthenticate: true };
}

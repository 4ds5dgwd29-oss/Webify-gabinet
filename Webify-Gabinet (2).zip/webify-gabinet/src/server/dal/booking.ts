import "server-only";
import { DateTime } from "luxon";
import { z } from "zod";
import { db } from "../db";
import { locked, notFound } from "./shared";
import { assertSlot } from "./calendar";
import { capacity, registerOrder } from "./commerce";
import { AccessError } from "../security/errors";
async function practice(slug: string) {
  const t = await db.tenant.findFirst({
    where: {
      slug,
      kind: "PRACTICE",
      bookingEnabled: true,
      status: { in: ["ACTIVE", "TRIAL"] },
    },
  });
  if (
    !t ||
    (t.status === "TRIAL" && t.trialEndsAt && t.trialEndsAt < new Date())
  )
    notFound("Rezerwacja jest niedostępna.");
  return t;
}
export async function publicSlots(
  slug: string,
  serviceId?: string,
  day?: string,
) {
  const t = await practice(slug);
  const services = await db.service.findMany({
    where: { tenantId: t.id, active: true },
  });
  const providers = await db.user.findMany({
    where: { tenantId: t.id, active: true, role: "OWNER" },
    select: { id: true, name: true },
  });
  const start = DateTime.fromISO(
    day || DateTime.now().setZone(t.timezone).plus({ days: 1 }).toISODate()!,
    { zone: t.timezone },
  ).startOf("day");
  if (
    !start.isValid ||
    start < DateTime.now().setZone(t.timezone).startOf("day") ||
    start > DateTime.now().plus({ days: 90 })
  )
    throw new AccessError(409, "Wybierz termin w ciągu najbliższych 90 dni.");
  const end = start.plus({ days: 1 }),
    service = services.find((s) => s.id === serviceId) || services[0],
    slots: Array<{ providerId: string; startsAt: string }> = [];
  if (service) {
    const [hours, leaves, visits] = await db.$transaction([
      db.workingHour.findMany({
        where: { tenantId: t.id, weekday: start.weekday },
      }),
      db.leave.findMany({
        where: {
          tenantId: t.id,
          startsAt: { lt: end.toJSDate() },
          endsAt: { gt: start.toJSDate() },
        },
      }),
      db.appointment.findMany({
        where: {
          tenantId: t.id,
          status: { not: "CANCELLED" },
          startsAt: { lt: end.toJSDate() },
          endsAt: { gt: start.toJSDate() },
        },
        select: { startsAt: true, endsAt: true, providerId: true },
      }),
    ]);
    for (const p of providers)
      for (const h of hours.filter((h) => h.providerId === p.id))
        for (
          let minute = h.startMinute;
          minute + service.durationMinutes <= h.endMinute;
          minute += 30
        ) {
          const a = start.plus({ minutes: minute }),
            b = a.plus({ minutes: service.durationMinutes });
          if (a < DateTime.now().plus({ hours: 2 })) continue;
          if (
            [...leaves, ...visits].some(
              (v) =>
                v.providerId === p.id && +v.startsAt < +b && +v.endsAt > +a,
            )
          )
            continue;
          slots.push({ providerId: p.id, startsAt: a.toUTC().toISO()! });
        }
  }
  return {
    name: t.name,
    slug: t.slug,
    timezone: t.timezone,
    mode: t.bookingMode,
    privacy: t.bookingPrivacy,
    terms: t.bookingTerms,
    services,
    providers,
    slots,
  };
}
export async function book(input: unknown) {
  const d = z
    .object({
      slug: z.string(),
      serviceId: z.string(),
      providerId: z.string(),
      startsAt: z.string().datetime(),
      firstName: z.string().trim().min(1).max(100),
      lastName: z.string().trim().min(1).max(100),
      email: z
        .string()
        .email()
        .max(254)
        .transform((s) => s.toLowerCase()),
      phone: z.string().max(30),
      consent: z.literal(true),
    })
    .strict()
    .parse(input);
  const t = await practice(d.slug);
  const result = await locked(t.id, async (tx) => {
    const fresh = await tx.tenant.findUniqueOrThrow({ where: { id: t.id } });
    if (!fresh.bookingEnabled || !["ACTIVE", "TRIAL"].includes(fresh.status))
      throw new AccessError(409, "Rezerwacja jest niedostępna.");
    const service = await tx.service.findFirst({
      where: { tenantId: t.id, id: d.serviceId, active: true },
    });
    if (!service) notFound();
    const startsAt = new Date(d.startsAt),
      endsAt = new Date(+startsAt + service.durationMinutes * 60000);
    if (
      +startsAt < Date.now() + 2 * 3600000 ||
      +startsAt > Date.now() + 90 * 86400000
    )
      throw new AccessError(409, "Termin poza zakresem rezerwacji.");
    await capacity(tx, t.id, "patient");
    const patient = await tx.patient.create({
      data: {
        tenantId: t.id,
        firstName: d.firstName,
        lastName: d.lastName,
        email: d.email,
        phone: d.phone,
        consentData: true,
        consentContact: true,
        consentUpdatedAt: new Date(),
        tags: ["Rezerwacja online"],
      },
    });
    await assertSlot(
      tx,
      t.id,
      d.providerId,
      patient.id,
      { startsAt, endsAt },
      t.timezone,
    );
    const amount =
      fresh.bookingMode === "FULL"
        ? service.priceGrosze
        : fresh.bookingMode === "DEPOSIT"
          ? service.depositGrosze
          : 0;
    if (fresh.bookingMode !== "NONE" && (amount <= 0 || !fresh.p24Encrypted))
      throw new AccessError(
        409,
        "Gabinet nie skonfigurował płatności za tę usługę.",
      );
    const appointment = await tx.appointment.create({
      data: {
        tenantId: t.id,
        patientId: patient.id,
        providerId: d.providerId,
        serviceId: service.id,
        startsAt,
        endsAt,
        priceGrosze: service.priceGrosze,
        holdUntil: amount ? new Date(Date.now() + 15 * 60000) : null,
      },
    });
    await tx.auditLog.create({
      data: {
        tenantId: t.id,
        action: "PUBLIC_BOOKING",
        resourceId: appointment.id,
      },
    });
    if (!amount) return null;
    return tx.paymentOrder.create({
      data: {
        tenantId: t.id,
        appointmentId: appointment.id,
        amountGrosze: amount,
        credentialsEncrypted: fresh.p24Encrypted!,
      },
    });
  });
  if (result) {
    try {
      return await registerOrder(result.id);
    } catch {
      return {
        retryId: result.id,
        message:
          "Termin oczekuje na płatność. Ponów połączenie z operatorem przed upływem 15 minut.",
      };
    }
  }
  return { ok: true };
}

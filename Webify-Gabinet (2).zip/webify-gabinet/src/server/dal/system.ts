import "server-only";
import { db } from "../db";
export async function recordSystemError(code: string) {
  try {
    const r = await db.systemLog.create({
      data: {
        tenantId: "webify-platform",
        code: /^[A-Za-z0-9_]{1,80}$/.test(code) ? code : "UNKNOWN_ERROR",
      },
    });
    return r.id;
  } catch {
    return undefined;
  }
}

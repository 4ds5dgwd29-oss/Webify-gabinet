import "server-only";
import { randomUUID, createHash } from "node:crypto";
import { z } from "zod";
import { db } from "../db";
import { practiceContext, audit, notFound } from "./shared";
import {
  encryptClinical,
  decryptClinical,
  tenantKey,
} from "../security/clinical";
import { putObject, getObject, deleteObject } from "../storage";
import { generatePdf } from "../pdf";
import { AccessError } from "../security/errors";
export function detectFile(bytes: Buffer, mime: string) {
  if (bytes.length === 0 || bytes.length > 10 * 1024 * 1024)
    throw new AccessError(409, "Plik musi mieć od 1 bajta do 10 MB.");
  const valid =
    (mime === "application/pdf" &&
      bytes.subarray(0, 5).toString() === "%PDF-") ||
    (mime === "image/png" &&
      bytes
        .subarray(0, 8)
        .equals(Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]))) ||
    (mime === "image/jpeg" &&
      bytes[0] === 255 &&
      bytes[1] === 216 &&
      bytes[2] === 255) ||
    (mime === "text/plain" && !bytes.includes(0));
  if (!valid)
    throw new AccessError(
      409,
      "Obsługiwane pliki: PDF, PNG, JPEG i TXT. Typ pliku musi odpowiadać zawartości.",
    );
}
export async function uploadDocument(sid: string, input: unknown) {
  const { principal: p, user } = await practiceContext(sid, true, true);
  const data = z
    .object({
      patientId: z.string(),
      name: z.string().min(1).max(180),
      mimeType: z.enum([
        "application/pdf",
        "image/png",
        "image/jpeg",
        "text/plain",
      ]),
      base64: z.string().max(14 * 1024 * 1024),
    })
    .strict()
    .parse(input);
  if (
    !(await db.patient.findFirst({
      where: { id: data.patientId, tenantId: p.tenantId },
    }))
  )
    notFound();
  const bytes = Buffer.from(data.base64, "base64");
  detectFile(bytes, data.mimeType);
  const id = randomUUID(),
    key = tenantKey(user.tenant),
    objectKey = `${p.tenantId}/${id}`;
  await putObject(
    objectKey,
    Buffer.from(
      encryptClinical(
        bytes.toString("base64"),
        key,
        p.tenantId,
        `document:${id}`,
      ),
    ),
  );
  try {
    await db.$transaction(async (tx) => {
      await tx.document.create({
        data: {
          id,
          tenantId: p.tenantId,
          patientId: data.patientId,
          objectKey,
          filenameEncrypted: encryptClinical(
            data.name.replace(/[\/\\\r\n]/g, "_"),
            key,
            p.tenantId,
            `filename:${id}`,
          ),
          mimeType: data.mimeType,
          sizeBytes: bytes.length,
          sha256: createHash("sha256").update(bytes).digest("hex"),
        },
      });
      await audit(tx, p, "DOCUMENT_UPLOAD", id);
    });
  } catch (e) {
    await deleteObject(objectKey);
    throw e;
  }
  return { id };
}
export async function downloadDocument(sid: string, id: string) {
  const { principal: p, user } = await practiceContext(sid, false, true);
  const record = await db.document.findFirst({
    where: { id, tenantId: p.tenantId, archivedAt: null },
  });
  if (!record) notFound();
  const key = tenantKey(user.tenant);
  const bytes = Buffer.from(
    decryptClinical(
      (await getObject(record.objectKey)).toString(),
      key,
      p.tenantId,
      `document:${id}`,
    ),
    "base64",
  );
  if (createHash("sha256").update(bytes).digest("hex") !== record.sha256)
    throw new Error("Niezgodna suma pliku.");
  await db.auditLog.create({
    data: {
      tenantId: p.tenantId,
      actorId: p.userId,
      action: "DOCUMENT_DOWNLOAD",
      resourceId: id,
    },
  });
  return {
    bytes,
    mime: record.mimeType,
    name: decryptClinical(
      record.filenameEncrypted,
      key,
      p.tenantId,
      `filename:${id}`,
    ),
  };
}
export async function patientPdf(
  sid: string,
  patientId: string,
  kind: string,
  appointmentId?: string,
) {
  const { principal: p, user } = await practiceContext(sid, false, true);
  const patient = await db.patient.findFirst({
    where: { id: patientId, tenantId: p.tenantId },
  });
  if (!patient) notFound();
  const base = [
    user.tenant.name,
    user.tenant.address || "",
    `Pacjent: ${patient.firstName} ${patient.lastName}`,
    `Data sporządzenia: ${new Date().toLocaleDateString("pl-PL", { timeZone: user.tenant.timezone })}`,
  ];
  let title: string, lines: string[];
  if (kind === "consent") {
    title = "Formularz zgód — wzór";
    lines = [
      ...base,
      "Dokument wymaga dostosowania i zatwierdzenia przez administratora danych oraz prawnika przed użyciem.",
      "Administrator danych i kontakt: ______________________________",
      "Cel, podstawa prawna, zakres przetwarzania i okres przechowywania: ______________________________",
      "Potwierdzam otrzymanie informacji o przetwarzaniu moich danych i sposobie wykonywania przysługujących mi praw.",
      "[ ] Wyrażam zgodę na kontakt organizacyjny i przypomnienia o wizytach.",
      "[ ] Wyrażam odrębną zgodę na nagrywanie spotkania w uzgodnionym celu i zakresie: ______________________________",
      "Zgody są dobrowolne. Sposób ich wycofania: ______________________________",
      "Data i podpis pacjenta: ______________________________",
    ];
  } else if (kind === "attendance") {
    const a = await db.appointment.findFirst({
      where: {
        id: appointmentId,
        tenantId: p.tenantId,
        patientId,
        status: "COMPLETED",
      },
    });
    if (!a)
      throw new AccessError(
        409,
        "Zaświadczenie można wystawić tylko dla odbytej wizyty.",
      );
    title = "Zaświadczenie o wizycie";
    lines = [
      ...base,
      `Potwierdzam odbycie wizyty w dniu ${a.startsAt.toLocaleString("pl-PL", { timeZone: user.tenant.timezone })}.`,
      "Dokument nie zawiera rozpoznania ani opisu procesu terapeutycznego.",
      "Podpis osoby wystawiającej: ______________________________",
    ];
  } else notFound();
  await db.auditLog.create({
    data: {
      tenantId: p.tenantId,
      actorId: p.userId,
      action: "PATIENT_PDF_GENERATE",
      resourceId: patientId,
    },
  });
  return generatePdf(title, lines);
}

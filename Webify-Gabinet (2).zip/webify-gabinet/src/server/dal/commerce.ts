import "server-only";
import { z } from "zod";
import type Stripe from "stripe";
import type { Prisma } from "@prisma/client";
import { db } from "../db";
import { stripe } from "../stripe";
import { practiceContext, ownerOnly, locked, audit, notFound } from "./shared";
import { AccessError } from "../security/errors";
import { wrapSecret, unwrapSecret } from "../security/crypto";
import {
  credentialsSchema,
  p24Base,
  p24Request,
  sign,
  validSignature,
} from "../p24";
import { recordPayment } from "./billing";
import { verifyPassword } from "../auth/password";
import { rateLimit } from "../auth/rate-limit";
export async function capacity(
  tx: Prisma.TransactionClient,
  tenantId: string,
  kind: "patient" | "user",
  extra = 1,
) {
  const t = await tx.tenant.findUniqueOrThrow({ where: { id: tenantId } });
  const count =
    kind === "patient"
      ? await tx.patient.count({ where: { tenantId, archivedAt: null } })
      : await tx.user.count({ where: { tenantId, active: true } });
  if (count + extra > (kind === "patient" ? t.patientLimit : t.userLimit))
    throw new AccessError(
      409,
      "Osiągnięto limit planu. Zmień plan lub zarchiwizuj nieaktywne rekordy.",
    );
}
export async function commerceSettings(sid: string, input?: unknown) {
  const { principal: p, user } = await practiceContext(sid);
  ownerOnly(p.role);
  if (input !== undefined) {
    await practiceContext(sid, true);
    const d = z
      .object({
        bookingEnabled: z.boolean(),
        bookingMode: z.enum(["NONE", "DEPOSIT", "FULL"]),
        bookingPrivacy: z.string().max(20000),
        bookingTerms: z.string().max(20000),
        credentials: credentialsSchema.optional(),
      })
      .strict()
      .parse(input);
    if (d.bookingEnabled && (!d.bookingPrivacy || !d.bookingTerms))
      throw new AccessError(
        409,
        "Uzupełnij politykę prywatności i warunki rezerwacji.",
      );
    if (
      d.bookingEnabled &&
      d.bookingMode !== "NONE" &&
      !d.credentials &&
      !user.tenant.p24Encrypted
    )
      throw new AccessError(409, "Najpierw skonfiguruj Przelewy24.");
    await locked(p.tenantId, async (tx) => {
      const { credentials, ...data } = d;
      await tx.tenant.update({
        where: { id: p.tenantId },
        data: {
          ...data,
          ...(credentials
            ? {
                p24Encrypted: wrapSecret(
                  JSON.stringify(credentials),
                  `p24:${p.tenantId}`,
                ),
              }
            : {}),
        },
      });
      await audit(tx, p, "COMMERCE_SETTINGS");
    });
  }
  const tenant = await db.tenant.findUniqueOrThrow({
    where: { id: p.tenantId },
    select: {
      slug: true,
      status: true,
      trialEndsAt: true,
      planCode: true,
      patientLimit: true,
      userLimit: true,
      bookingEnabled: true,
      bookingMode: true,
      bookingPrivacy: true,
      bookingTerms: true,
      p24Encrypted: true,
      subscription: true,
    },
  });
  return {
    ...tenant,
    p24Encrypted: undefined,
    p24Configured: !!tenant.p24Encrypted,
    plans: await db.plan.findMany({
      where: { tenantId: "webify-platform", active: true },
      orderBy: { monthlyGrosze: "asc" },
    }),
    stripeConfigured: !!process.env.STRIPE_SECRET_KEY,
  };
}
export async function checkout(sid: string, input: unknown) {
  const { principal: p, user } = await practiceContext(sid);
  ownerOnly(p.role);
  const d = z
    .object({ code: z.string(), yearly: z.boolean() })
    .strict()
    .parse(input);
  const plan = await db.plan.findFirst({
    where: { tenantId: "webify-platform", code: d.code, active: true },
  });
  if (!plan) notFound();
  const price = d.yearly ? plan.stripeYearlyId : plan.stripeMonthlyId;
  if (!price)
    throw new AccessError(409, "Plan oczekuje na konfigurację ceny Stripe.");
  return locked(p.tenantId, async (tx) => {
    const t = await tx.tenant.findUniqueOrThrow({
      where: { id: p.tenantId },
      include: { subscription: true },
    });
    if (
      t.subscription &&
      !["canceled", "incomplete_expired"].includes(t.subscription.status)
    )
      throw new AccessError(409, "Zmień istniejący plan w portalu płatności.");
    let customer = t.stripeCustomerId;
    if (!customer) {
      const c = await stripe().customers.create(
        { email: user.email, name: t.name, metadata: { tenantId: t.id } },
        { idempotencyKey: `customer:${t.id}` },
      );
      customer = c.id;
      await tx.tenant.update({
        where: { id: t.id },
        data: { stripeCustomerId: customer },
      });
    }
    const trialEnd =
      t.trialEndsAt && +t.trialEndsAt > Date.now() + 48 * 3600000
        ? Math.floor(+t.trialEndsAt / 1000)
        : undefined;
    const result = await stripe().checkout.sessions.create(
      {
        mode: "subscription",
        customer,
        line_items: [{ price, quantity: 1 }],
        allow_promotion_codes: true,
        metadata: { tenantId: t.id },
        subscription_data: {
          metadata: { tenantId: t.id },
          ...(trialEnd ? { trial_end: trialEnd } : {}),
        },
        success_url: `${process.env.NEXTAUTH_URL}/gabinet/subskrypcja?wynik=powrot`,
        cancel_url: `${process.env.NEXTAUTH_URL}/gabinet/subskrypcja`,
      },
      {
        idempotencyKey: `checkout:${t.id}:${price}:${Math.floor(Date.now() / 300000)}`,
      },
    );
    await audit(tx, p, "STRIPE_CHECKOUT");
    return { url: result.url };
  });
}
export async function portal(sid: string) {
  const { principal: p, user } = await practiceContext(sid);
  ownerOnly(p.role);
  if (!user.tenant.stripeCustomerId)
    throw new AccessError(409, "Brak konta rozliczeniowego.");
  const result = await stripe().billingPortal.sessions.create({
    customer: user.tenant.stripeCustomerId,
    return_url: `${process.env.NEXTAUTH_URL}/gabinet/subskrypcja`,
  });
  return { url: result.url };
}
export async function invoices(sid: string) {
  const { principal: p, user } = await practiceContext(sid);
  ownerOnly(p.role);
  if (!user.tenant.stripeCustomerId) return [];
  const result = await stripe().invoices.list({
    customer: user.tenant.stripeCustomerId,
    limit: 50,
  });
  return result.data.map((i) => ({
    id: i.id,
    number: i.number,
    amount: i.amount_paid,
    status: i.status,
    url: i.hosted_invoice_url,
    pdf: i.invoice_pdf,
  }));
}
export async function applySubscription(
  event: { id: string; type: string; created: number },
  sub: Stripe.Subscription,
) {
  const customer =
    typeof sub.customer === "string" ? sub.customer : sub.customer.id;
  const t = await db.tenant.findUnique({
    where: { stripeCustomerId: customer },
  });
  if (!t || sub.metadata.tenantId !== t.id)
    throw new AccessError(409, "Nieznane przypisanie subskrypcji.");
  return locked(t.id, async (tx) => {
    if (await tx.webhookEvent.findUnique({ where: { id: event.id } })) return;
    const previous = await tx.subscription.findUnique({
      where: { tenantId: t.id },
    });
    if (previous && previous.lastEventAt > event.created) {
      await tx.webhookEvent.create({
        data: { id: event.id, tenantId: "webify-platform", type: event.type },
      });
      return;
    }
    const item = sub.items.data[0],
      price = item?.price.id;
    const plan = await tx.plan.findFirst({
      where: {
        tenantId: "webify-platform",
        OR: [{ stripeMonthlyId: price ?? "" }, { stripeYearlyId: price ?? "" }],
      },
    });
    if (!plan) throw new AccessError(409, "Nieznana cena subskrypcji.");
    const grace =
      sub.status === "past_due"
        ? (previous?.graceUntil ?? new Date(Date.now() + 7 * 86400000))
        : null;
    const status =
      ["active", "trialing"].includes(sub.status) ||
      (grace && grace > new Date())
        ? "ACTIVE"
        : "READ_ONLY";
    await tx.subscription.upsert({
      where: { tenantId: t.id },
      create: { id: sub.id, tenantId: t.id, status: sub.status },
      update: { id: sub.id, status: sub.status },
    });
    await tx.subscription.update({
      where: { tenantId: t.id },
      data: {
        priceId: price,
        currentPeriodEnd: item?.current_period_end
          ? new Date(item.current_period_end * 1000)
          : null,
        graceUntil: grace,
        cancelAtPeriodEnd: sub.cancel_at_period_end,
        lastEventAt: event.created,
      },
    });
    await tx.tenant.update({
      where: { id: t.id },
      data: {
        ...((await tx.tenant.findUniqueOrThrow({ where: { id: t.id } }))
          .status === "SUSPENDED"
          ? {}
          : { status }),
        planCode: plan.code,
        patientLimit: plan.patientLimit,
        userLimit: plan.userLimit,
      },
    });
    await tx.webhookEvent.create({
      data: { id: event.id, tenantId: "webify-platform", type: event.type },
    });
  });
}
export async function stripeEvent(event: Stripe.Event) {
  let subId: string | undefined;
  const o = event.data.object as unknown as Record<string, unknown>;
  if (event.type.startsWith("customer.subscription.")) subId = o.id as string;
  else if (event.type === "checkout.session.completed")
    subId = typeof o.subscription === "string" ? o.subscription : undefined;
  else if (["invoice.paid", "invoice.payment_failed"].includes(event.type)) {
    const invoice = event.data.object as Stripe.Invoice;
    const sub = invoice.parent?.subscription_details?.subscription;
    subId = typeof sub === "string" ? sub : sub?.id;
  }
  if (subId)
    await applySubscription(
      event,
      await stripe().subscriptions.retrieve(subId),
    );
}
export async function paymentLink(sid: string, appointmentId: string) {
  const { principal: p } = await practiceContext(sid, true);
  const order = await locked(p.tenantId, async (tx) => {
    const t = await tx.tenant.findUniqueOrThrow({ where: { id: p.tenantId } });
    if (!t.p24Encrypted)
      throw new AccessError(409, "Przelewy24 nie są skonfigurowane.");
    const a = await tx.appointment.findFirst({
      where: { id: appointmentId, tenantId: p.tenantId },
      include: { payments: { where: { voidedAt: null } } },
    });
    if (!a) notFound();
    const amount =
      a.priceGrosze - a.payments.reduce((sum, v) => sum + v.amountGrosze, 0);
    if (amount <= 0) throw new AccessError(409, "Wizyta jest opłacona.");
    const pending = await tx.paymentOrder.findFirst({
      where: {
        tenantId: p.tenantId,
        appointmentId,
        status: "PENDING",
        amountGrosze: amount,
      },
    });
    return (
      pending ??
      tx.paymentOrder.create({
        data: {
          tenantId: p.tenantId,
          appointmentId,
          amountGrosze: amount,
          credentialsEncrypted: t.p24Encrypted,
        },
      })
    );
  });
  return registerOrder(order.id);
}
export async function registerOrder(id: string) {
  const order = await db.paymentOrder.findUniqueOrThrow({
    where: { id },
    include: { appointment: { include: { patient: true } } },
  });
  if (
    order.status !== "PENDING" ||
    order.appointment.status === "CANCELLED" ||
    (order.appointment.holdUntil && order.appointment.holdUntil < new Date())
  )
    throw new AccessError(
      409,
      "Rezerwacja wygasła lub została już rozliczona.",
    );
  const c = credentialsSchema.parse(
    JSON.parse(
      unwrapSecret(order.credentialsEncrypted, `p24:${order.tenantId}`),
    ),
  );
  if (order.token) return { url: `${p24Base(c)}/trnRequest/${order.token}` };
  if (!order.appointment.patient.email)
    throw new AccessError(409, "Płatność wymaga adresu e-mail pacjenta.");
  const result = await p24Request(c, "transaction/register", {
    merchantId: c.merchantId,
    posId: c.posId,
    sessionId: id,
    amount: order.amountGrosze,
    currency: "PLN",
    description: "Rezerwacja wizyty",
    email: order.appointment.patient.email,
    country: "PL",
    language: "pl",
    urlReturn: `${process.env.NEXTAUTH_URL}/platnosc`,
    urlStatus: `${process.env.NEXTAUTH_URL}/api/webhooks/p24`,
    timeLimit: 15,
    sign: sign({
      sessionId: id,
      merchantId: c.merchantId,
      amount: order.amountGrosze,
      currency: "PLN",
      crc: c.crc,
    }),
  });
  const token = z
    .string()
    .regex(/^[a-zA-Z0-9_-]+$/)
    .parse(result.data?.token);
  await db.paymentOrder.update({ where: { id }, data: { token } });
  return { url: `${p24Base(c)}/trnRequest/${token}` };
}
const notification = z.object({
  merchantId: z.number().int(),
  posId: z.number().int(),
  sessionId: z.string().uuid(),
  amount: z.number().int(),
  originAmount: z.number().int(),
  currency: z.literal("PLN"),
  orderId: z.number().int().positive(),
  methodId: z.number().int(),
  statement: z.string(),
  sign: z.string(),
});
export async function p24Notification(input: unknown) {
  const n = notification.parse(input);
  const order = await db.paymentOrder.findUnique({
    where: { id: n.sessionId },
  });
  if (!order) notFound();
  const c = credentialsSchema.parse(
    JSON.parse(
      unwrapSecret(order.credentialsEncrypted, `p24:${order.tenantId}`),
    ),
  );
  const expected = sign({
    merchantId: n.merchantId,
    posId: n.posId,
    sessionId: n.sessionId,
    amount: n.amount,
    originAmount: n.originAmount,
    currency: n.currency,
    orderId: n.orderId,
    methodId: n.methodId,
    statement: n.statement,
    crc: c.crc,
  });
  if (
    n.merchantId !== c.merchantId ||
    n.posId !== c.posId ||
    n.amount !== order.amountGrosze ||
    n.originAmount !== order.amountGrosze ||
    !validSignature(n.sign, expected)
  )
    throw new AccessError(409, "Niepoprawny podpis lub kwota.");
  if (order.status !== "PENDING") return;
  if (
    (
      await p24Request(
        c,
        "transaction/verify",
        {
          merchantId: c.merchantId,
          posId: c.posId,
          sessionId: order.id,
          amount: order.amountGrosze,
          currency: "PLN",
          orderId: n.orderId,
          sign: sign({
            sessionId: order.id,
            orderId: n.orderId,
            amount: order.amountGrosze,
            currency: "PLN",
            crc: c.crc,
          }),
        },
        "PUT",
      )
    ).data?.status !== "success"
  )
    throw new AccessError(409, "Operator nie zweryfikował transakcji.");
  await locked(order.tenantId, async (tx) => {
    const current = await tx.paymentOrder.findUniqueOrThrow({
      where: { id: order.id },
      include: { appointment: true },
    });
    if (current.status !== "PENDING") return;
    const a = current.appointment;
    const paid = await tx.payment.aggregate({
      where: { tenantId: order.tenantId, appointmentId: a.id, voidedAt: null },
      _sum: { amountGrosze: true },
    });
    const review =
      a.status === "CANCELLED" ||
      !!(a.holdUntil && a.holdUntil < new Date()) ||
      (paid._sum.amountGrosze ?? 0) + order.amountGrosze > a.priceGrosze;
    if (!review) {
      await recordPayment(tx, order.tenantId, {
        appointmentId: a.id,
        amountGrosze: order.amountGrosze,
        method: "ONLINE",
        requestId: order.id,
        providerOrderId: String(n.orderId),
      });
      await tx.appointment.update({
        where: { id: a.id },
        data: { holdUntil: null, confirmedAt: new Date() },
      });
    }
    await tx.paymentOrder.update({
      where: { id: order.id },
      data: {
        status: review ? "REVIEW" : "PAID",
        providerOrderId: n.orderId,
        paidAt: new Date(),
      },
    });
    await tx.auditLog.create({
      data: {
        tenantId: order.tenantId,
        action: review ? "P24_REVIEW_REQUIRED" : "P24_PAID",
        resourceId: order.id,
      },
    });
  });
}
export async function expireCommerce() {
  const now = new Date();
  const tenants = await db.tenant.findMany({
    where: {
      kind: "PRACTICE",
      OR: [
        {
          appointments: {
            some: { holdUntil: { lt: now }, status: "SCHEDULED" },
          },
        },
        { subscription: { graceUntil: { lt: now }, status: "past_due" } },
      ],
    },
    select: { id: true },
  });
  for (const t of tenants)
    await locked(t.id, async (tx) => {
      await tx.appointment.updateMany({
        where: { tenantId: t.id, holdUntil: { lt: now }, status: "SCHEDULED" },
        data: { status: "CANCELLED", version: { increment: 1 } },
      });
      const sub = await tx.subscription.findUnique({
        where: { tenantId: t.id },
      });
      if (sub?.status === "past_due" && sub.graceUntil && sub.graceUntil < now)
        await tx.tenant.updateMany({
          where: { id: t.id, status: { not: "SUSPENDED" } },
          data: { status: "READ_ONLY" },
        });
    });
}

export async function reconcileSubscriptions() {
  if (!process.env.STRIPE_SECRET_KEY) return { checked: 0 };
  const rows = await db.subscription.findMany({
    where: { updatedAt: { lt: new Date(Date.now() - 3600000) } },
    orderBy: { updatedAt: "asc" },
    take: 2,
  });
  let checked = 0;
  for (const s of rows) {
    try {
      const current = await stripe().subscriptions.retrieve(s.id);
      const now = Math.floor(Date.now() / 1000);
      await applySubscription(
        {
          id: `reconcile:${s.id}:${now}`,
          type: "subscription.reconcile",
          created: now,
        },
        current,
      );
      checked++;
    } catch {
      console.error("SUBSCRIPTION_RECONCILE_FAILED");
    }
  }
  return { checked };
}
export async function onlineOrders(sid: string) {
  const { principal: p } = await practiceContext(sid);
  ownerOnly(p.role);
  return db.paymentOrder.findMany({
    where: { tenantId: p.tenantId },
    select: {
      id: true,
      appointmentId: true,
      status: true,
      amountGrosze: true,
      providerOrderId: true,
      createdAt: true,
      paidAt: true,
    },
    orderBy: { createdAt: "desc" },
    take: 200,
  });
}
export async function resolveOnlineOrder(sid: string, input: unknown) {
  const { principal: p, user } = await practiceContext(sid, true);
  ownerOnly(p.role);
  const d = z
    .object({
      id: z.string(),
      password: z.string().max(128),
      confirmedRefund: z.literal(true),
    })
    .strict()
    .parse(input);
  await rateLimit("reconcile-refund", p.userId, 5);
  if (!(await verifyPassword(user.passwordHash, d.password)))
    throw new AccessError(403, "Niepoprawne hasło.");
  await locked(p.tenantId, async (tx) => {
    if (
      !(
        await tx.paymentOrder.updateMany({
          where: { id: d.id, tenantId: p.tenantId, status: "REVIEW" },
          data: { status: "REFUNDED_EXTERNALLY" },
        })
      ).count
    )
      throw new AccessError(409, "Płatność nie oczekuje na uzgodnienie.");
    await audit(tx, p, "P24_EXTERNAL_REFUND_CONFIRMED", d.id);
  });
}

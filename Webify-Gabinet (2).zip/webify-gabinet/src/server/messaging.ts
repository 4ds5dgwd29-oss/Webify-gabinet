import "server-only";
export type MessagePayload = { to: string; subject: string; text: string };
export async function sendMessage(
  channel: string,
  payload: MessagePayload,
  id: string,
) {
  if (channel === "EMAIL") {
    if (!process.env.RESEND_API_KEY || !process.env.EMAIL_FROM)
      throw new Error("EMAIL_NOT_CONFIGURED");
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${process.env.RESEND_API_KEY}`,
        "Content-Type": "application/json",
        "Idempotency-Key": id,
      },
      body: JSON.stringify({
        from: process.env.EMAIL_FROM,
        to: [payload.to],
        subject: payload.subject,
        text: payload.text,
      }),
      signal: AbortSignal.timeout(15000),
    });
    if (!response.ok) throw new Error(`EMAIL_PROVIDER_${response.status}`);
    const result = await response.json();
    return String(result.id);
  }
  if (!process.env.SMSAPI_TOKEN) throw new Error("SMS_NOT_CONFIGURED");
  const response = await fetch("https://api.smsapi.pl/sms.do", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${process.env.SMSAPI_TOKEN}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: new URLSearchParams({
      to: payload.to,
      message: payload.text,
      format: "json",
      encoding: "utf8",
      idx: id,
      check_idx: "1",
      ...(process.env.SMS_FROM ? { from: process.env.SMS_FROM } : {}),
    }),
    signal: AbortSignal.timeout(15000),
  });
  const result = await response.json();
  if (result.error === 53) return id;
  if (!response.ok || result.error)
    throw new Error(`SMS_PROVIDER_${response.status}`);
  return String(result.list?.[0]?.id ?? id);
}

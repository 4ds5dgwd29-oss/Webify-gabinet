import "server-only";
import { z } from "zod";
const schema = z.object({
  DATABASE_URL: z.string().min(1),
  NEXTAUTH_URL: z.string().url(),
  NEXTAUTH_SECRET: z.string().min(32),
  MASTER_ENCRYPTION_KEY: z
    .string()
    .refine(
      (v) => Buffer.from(v, "base64").length === 32,
      "Klucz musi zawierać 32 bajty base64.",
    ),
  ALLOW_REGISTRATION: z.enum(["true", "false"]).default("false"),
  TRUST_PROXY: z.enum(["true", "false"]).default("false"),
});
export function env() {
  return schema.parse(process.env);
}
export const PLATFORM_TENANT_ID = "webify-platform";
export const IDLE_TIMEOUT_MS = 15 * 60 * 1000;
export const SESSION_MAX_AGE = 8 * 60 * 60;

import { recordSystemError } from "../dal/system";
import "server-only";
import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { env } from "../config";
import { AccessError } from "./errors";
export function json(data: unknown, status = 200) {
  return NextResponse.json(data, {
    status,
    headers: { "Cache-Control": "no-store" },
  });
}
export async function readMutation(request: Request, maxBytes = 16_384) {
  if (request.headers.get("origin") !== new URL(env().NEXTAUTH_URL).origin)
    throw new AccessError(403, "Niedozwolone źródło żądania.");
  if (!request.headers.get("content-type")?.startsWith("application/json"))
    throw new AccessError(403, "Wymagany format JSON.");
  const raw = await readRawBody(request, maxBytes);
  try {
    return JSON.parse(raw.toString("utf8"));
  } catch {
    throw new AccessError(403, "Niepoprawny JSON.");
  }
}
export async function readRawBody(request: Request, maxBytes = 16384) {
  const reader = request.body?.getReader();
  if (!reader) throw new AccessError(403, "Brak danych.");
  const chunks: Uint8Array[] = [];
  let size = 0;
  while (true) {
    const { value, done } = await reader.read();
    if (done) break;
    size += value.byteLength;
    if (size > maxBytes) {
      await reader.cancel();
      throw new AccessError(403, "Żądanie jest za duże.");
    }
    chunks.push(value);
  }
  return Buffer.concat(chunks);
}
export async function handleError(error: unknown) {
  if (error instanceof AccessError)
    return json({ error: error.message }, error.status);
  if (error instanceof ZodError)
    return json({ error: "Sprawdź poprawność wprowadzonych danych." }, 400);
  // Nie logujemy żądania, danych pacjentów, sekretów ani treści błędów bazy.
  console.error(
    "REQUEST_FAILED",
    error instanceof Error ? error.name : "UnknownError",
  );
  const reference = await recordSystemError(
    error instanceof Error ? error.name : "UnknownError",
  );
  return json(
    {
      error: "Nie udało się wykonać operacji. Spróbuj ponownie później.",
      reference,
    },
    500,
  );
}

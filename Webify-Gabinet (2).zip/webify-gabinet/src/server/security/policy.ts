import type { Role, TenantKind, TenantStatus } from "@prisma/client";
import { AccessError } from "./errors";
export type Principal = Readonly<{
  userId: string;
  tenantId: string;
  role: Role;
  kind: TenantKind;
  status: TenantStatus;
}>;
export function requirePractice(p: Principal) {
  if (
    p.kind !== "PRACTICE" ||
    p.role === "SUPER_ADMIN" ||
    p.status === "SUSPENDED"
  )
    throw new AccessError(403, "Brak dostępu do danych gabinetu.");
}
export function requireWrite(p: Principal) {
  requirePractice(p);
  if (p.status === "READ_ONLY")
    throw new AccessError(403, "Gabinet działa w trybie tylko do odczytu.");
}
export function requireClinical(p: Principal) {
  requirePractice(p);
  if (p.role !== "OWNER")
    throw new AccessError(403, "Brak dostępu do dokumentacji klinicznej.");
}
export function requirePlatform(p: Principal) {
  if (
    p.kind !== "PLATFORM" ||
    p.role !== "SUPER_ADMIN" ||
    p.status === "SUSPENDED"
  )
    throw new AccessError(403, "Brak dostępu do panelu platformy.");
}

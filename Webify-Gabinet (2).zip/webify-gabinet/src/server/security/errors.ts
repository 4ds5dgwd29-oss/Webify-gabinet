export class AccessError extends Error {
  constructor(
    public status: 401 | 403 | 404 | 409 | 429,
    message: string,
  ) {
    super(message);
    this.name = "AccessError";
  }
}

import "server-only";
import { createCipheriv, createDecipheriv, randomBytes } from "node:crypto";
import { env } from "../config";
export function seal(value: string, key: Buffer, aad: string): string {
  if (key.length !== 32) throw new Error("Niepoprawny klucz szyfrowania.");
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  cipher.setAAD(Buffer.from(aad));
  const ciphertext = Buffer.concat([
    cipher.update(value, "utf8"),
    cipher.final(),
  ]);
  return [
    "v1",
    iv.toString("base64url"),
    cipher.getAuthTag().toString("base64url"),
    ciphertext.toString("base64url"),
  ].join(".");
}
export function unseal(value: string, key: Buffer, aad: string): string {
  const parts = value.split(".");
  if (parts.length !== 4 || parts[0] !== "v1")
    throw new Error("Niepoprawny format szyfrogramu.");
  const [, iv, tag, ciphertext] = parts;
  const ivBytes = Buffer.from(iv, "base64url"),
    tagBytes = Buffer.from(tag, "base64url");
  if (ivBytes.length !== 12 || tagBytes.length !== 16)
    throw new Error("Niepoprawny szyfrogram.");
  const cipher = createDecipheriv("aes-256-gcm", key, ivBytes);
  cipher.setAAD(Buffer.from(aad));
  cipher.setAuthTag(tagBytes);
  return Buffer.concat([
    cipher.update(Buffer.from(ciphertext, "base64url")),
    cipher.final(),
  ]).toString("utf8");
}
export function wrapSecret(value: string, purpose: string) {
  return seal(
    value,
    Buffer.from(env().MASTER_ENCRYPTION_KEY, "base64"),
    purpose,
  );
}
export function unwrapSecret(value: string, purpose: string) {
  return unseal(
    value,
    Buffer.from(env().MASTER_ENCRYPTION_KEY, "base64"),
    purpose,
  );
}
export function createTenantKey(tenantId: string) {
  return wrapSecret(
    randomBytes(32).toString("base64"),
    `tenant-key:${tenantId}`,
  );
}

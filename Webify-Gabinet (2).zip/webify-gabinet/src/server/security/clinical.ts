import "server-only";
import sanitizeHtml from "sanitize-html";
import { unwrapSecret, seal, unseal } from "./crypto";
export function cleanNote(html: string) {
  return sanitizeHtml(html, {
    allowedTags: [
      "p",
      "br",
      "strong",
      "b",
      "em",
      "i",
      "u",
      "ul",
      "ol",
      "li",
      "h2",
      "h3",
      "blockquote",
    ],
    allowedAttributes: {},
    disallowedTagsMode: "discard",
  });
}
export function tenantKey(tenant: {
  id: string;
  encryptedDataKey: string | null;
}) {
  if (!tenant.encryptedDataKey)
    throw new Error("Brak klucza szyfrowania gabinetu.");
  return Buffer.from(
    unwrapSecret(tenant.encryptedDataKey, `tenant-key:${tenant.id}`),
    "base64",
  );
}
export function encryptClinical(
  text: string,
  key: Buffer,
  tenantId: string,
  purpose: string,
) {
  return seal(text, key, `${tenantId}:${purpose}`);
}
export function decryptClinical(
  text: string,
  key: Buffer,
  tenantId: string,
  purpose: string,
) {
  return unseal(text, key, `${tenantId}:${purpose}`);
}

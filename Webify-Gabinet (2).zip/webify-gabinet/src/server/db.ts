import "server-only";
import { PrismaClient } from "@prisma/client";
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };
// Import dozwolony wyłącznie w server/{auth,dal} i narzędziach offline.
export const db = globalForPrisma.prisma ?? new PrismaClient({ log: [] });
globalForPrisma.prisma = db;

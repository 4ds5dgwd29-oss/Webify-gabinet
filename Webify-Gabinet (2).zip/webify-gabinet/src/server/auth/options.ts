import "server-only";
import type { NextAuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import { authenticate } from "./credentials";
import { resolveSession } from "./session-store";
import { db } from "../db";
import { SESSION_MAX_AGE } from "../config";
export const authOptions: NextAuthOptions = {
  providers: [
    CredentialsProvider({
      name: "E-mail i hasło",
      credentials: {
        email: { label: "Adres e-mail", type: "email" },
        password: { label: "Hasło", type: "password" },
        otp: { label: "Kod uwierzytelniający", type: "text" },
      },
      async authorize(credentials, req) {
        try {
          return await authenticate(
            credentials && {
              email: credentials.email,
              password: credentials.password,
              otp: credentials.otp ?? "",
            },
            req.headers ?? {},
          );
        } catch {
          return null;
        }
      },
    }),
  ],
  session: { strategy: "jwt", maxAge: SESSION_MAX_AGE },
  pages: { signIn: "/logowanie", error: "/logowanie" },
  callbacks: {
    async jwt({ token, user }) {
      if (user) token.sessionId = user.sessionId;
      // Dane z callbacku update pochodzą od klienta i są celowo ignorowane.
      if (token.sessionId) {
        try {
          await resolveSession(token.sessionId);
        } catch {
          delete token.sessionId;
        }
      }
      return token;
    },
    async session({ session, token }) {
      session.sessionId = token.sessionId;
      session.user = undefined;
      if (token.sessionId) {
        try {
          const { user } = await resolveSession(token.sessionId);
          session.user = {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role,
          };
        } catch {
          session.sessionId = undefined;
        }
      }
      return session;
    },
    async redirect({ url, baseUrl }) {
      if (url.startsWith("/") && !url.startsWith("//"))
        return `${baseUrl}${url}`;
      try {
        if (new URL(url).origin === new URL(baseUrl).origin) return url;
      } catch {
        /* odrzucamy obcy adres */
      }
      return `${baseUrl}/gabinet`;
    },
  },
  events: {
    async signOut({ token }) {
      if (!token?.sessionId) return;
      const session = await db.authSession.findUnique({
        where: { id: token.sessionId },
      });
      if (session)
        await db.$transaction([
          db.authSession.updateMany({
            where: {
              id: session.id,
              tenantId: session.tenantId,
              revokedAt: null,
            },
            data: { revokedAt: new Date() },
          }),
          db.auditLog.create({
            data: {
              tenantId: session.tenantId,
              actorId: session.userId,
              action: "AUTH_LOGOUT",
              resourceId: session.id,
            },
          }),
        ]);
    },
  },
};

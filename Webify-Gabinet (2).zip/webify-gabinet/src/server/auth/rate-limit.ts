import "server-only";
import { createHmac } from "node:crypto";
import { db } from "../db";
import { env, PLATFORM_TENANT_ID } from "../config";
import { AccessError } from "../security/errors";
export async function rateLimit(
  namespace: string,
  identity: string,
  limit = 8,
  windowMs = 15 * 60_000,
) {
  const key = createHmac("sha256", env().NEXTAUTH_SECRET)
    .update(`${namespace}:${identity}`)
    .digest("hex");
  const resetAt = new Date(Date.now() + windowMs);
  const rows = await db.$queryRaw<Array<{ attempts: number }>>`
    INSERT INTO "LoginBucket" ("tenantId", "key", "attempts", "resetAt")
    VALUES (${PLATFORM_TENANT_ID}, ${key}, 1, ${resetAt})
    ON CONFLICT ("tenantId", "key") DO UPDATE SET
      "attempts" = CASE WHEN "LoginBucket"."resetAt" <= NOW() THEN 1 ELSE "LoginBucket"."attempts" + 1 END,
      "resetAt" = CASE WHEN "LoginBucket"."resetAt" <= NOW() THEN EXCLUDED."resetAt" ELSE "LoginBucket"."resetAt" END
    RETURNING "attempts"`;
  if (rows[0].attempts > limit)
    throw new AccessError(
      429,
      "Zbyt wiele prób. Spróbuj ponownie za 15 minut.",
    );
}
export function requestIdentity(headers: Record<string, unknown>) {
  if (env().TRUST_PROXY !== "true") return "shared-untrusted-network";
  const forwarded = headers["x-forwarded-for"];
  return typeof forwarded === "string"
    ? forwarded.split(",")[0].trim().slice(0, 64)
    : "unknown";
}

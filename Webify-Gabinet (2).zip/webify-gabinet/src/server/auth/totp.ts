import "server-only";
import { authenticator } from "otplib";
export function totpStep(secret: string, token: string): number | null {
  const instance = authenticator.clone();
  instance.options = { window: 1 };
  const delta = instance.checkDelta(token, secret);
  return delta === null ? null : Math.floor(Date.now() / 30_000) + delta;
}
export function newTotp(email: string) {
  const secret = authenticator.generateSecret();
  return { secret, uri: authenticator.keyuri(email, "Webify Gabinet", secret) };
}

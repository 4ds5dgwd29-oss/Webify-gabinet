import "server-only";
import { getServerSession } from "next-auth";
import { authOptions } from "./options";
import { resolveSession } from "./session-store";
export async function currentContext(touch = true) {
  const session = await getServerSession(authOptions);
  return resolveSession(session?.sessionId, touch);
}

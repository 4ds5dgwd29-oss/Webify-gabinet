import "server-only";
import { randomUUID } from "node:crypto";
import { Prisma } from "@prisma/client";
import { db } from "../db";
import { env } from "../config";
import { registerSchema } from "@/lib/validation";
import { hashPassword } from "./password";
import { createTenantKey } from "../security/crypto";
import { AccessError } from "../security/errors";
export async function registerPractice(input: unknown) {
  if (env().ALLOW_REGISTRATION !== "true")
    throw new AccessError(403, "Rejestracja jest obecnie zamknięta.");
  const data = registerSchema.parse(input);
  const tenantId = randomUUID(),
    userId = randomUUID();
  const passwordHash = await hashPassword(data.password);
  try {
    await db.$transaction(async (tx) => {
      const plan = await tx.plan.findUnique({ where: { code: "START" } });
      await tx.tenant.create({
        data: {
          id: tenantId,
          name: data.practiceName,
          slug: `gabinet-${tenantId}`,
          encryptedDataKey: createTenantKey(tenantId),
          trialEndsAt: new Date(
            Date.now() + (plan?.trialDays ?? 30) * 86400000,
          ),
          patientLimit: plan?.patientLimit ?? 100,
          userLimit: plan?.userLimit ?? 1,
        },
      });
      await tx.user.create({
        data: {
          id: userId,
          tenantId,
          email: data.email,
          name: data.name,
          role: "OWNER",
          passwordHash,
        },
      });
      await tx.auditLog.create({
        data: {
          tenantId,
          actorId: userId,
          action: "PRACTICE_REGISTERED",
          resourceId: tenantId,
        },
      });
    });
  } catch (error) {
    // Taki sam komunikat dla istniejącego adresu; brak enumeracji kont.
    if (
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.code === "P2002"
    )
      return;
    throw error;
  }
}

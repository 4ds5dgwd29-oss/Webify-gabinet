import "server-only";
import { db } from "../db";
import { IDLE_TIMEOUT_MS } from "../config";
import { AccessError } from "../security/errors";
export async function resolveSession(id: string | undefined, touch = false) {
  if (!id) throw new AccessError(401, "Zaloguj się ponownie.");
  const now = new Date();
  const session = await db.authSession.findUnique({
    where: { id },
    include: {
      user: { include: { tenant: { include: { subscription: true } } } },
    },
  });
  if (
    !session ||
    session.revokedAt ||
    session.expiresAt <= now ||
    session.lastSeenAt.getTime() <= now.getTime() - IDLE_TIMEOUT_MS ||
    !session.user.active ||
    session.version !== session.user.sessionVersion ||
    session.user.tenant.status === "SUSPENDED"
  )
    throw new AccessError(401, "Sesja wygasła. Zaloguj się ponownie.");
  const tenant = session.user.tenant;
  const status =
    (tenant.status === "TRIAL" &&
      tenant.trialEndsAt &&
      tenant.trialEndsAt <= now) ||
    (tenant.subscription?.status === "past_due" &&
      tenant.subscription.graceUntil &&
      tenant.subscription.graceUntil <= now)
      ? ("READ_ONLY" as const)
      : tenant.status;
  if (touch) {
    const updated = await db.authSession.updateMany({
      where: {
        id,
        tenantId: session.tenantId,
        revokedAt: null,
        lastSeenAt: { gt: new Date(now.getTime() - IDLE_TIMEOUT_MS) },
        expiresAt: { gt: now },
      },
      data: { lastSeenAt: now },
    });
    if (!updated.count) throw new AccessError(401, "Sesja wygasła.");
  }
  return {
    session,
    user: session.user,
    principal: Object.freeze({
      userId: session.userId,
      tenantId: session.tenantId,
      role: session.user.role,
      kind: tenant.kind,
      status,
    }),
  };
}

import "server-only";
import { db } from "../db";
import { loginSchema } from "@/lib/validation";
import { SESSION_MAX_AGE } from "../config";
import { rateLimit, requestIdentity } from "./rate-limit";
import { getDummyHash, verifyPassword } from "./password";
import { unwrapSecret } from "../security/crypto";
import { totpStep } from "./totp";
export async function authenticate(
  input: unknown,
  headers: Record<string, unknown> = {},
) {
  const parsed = loginSchema.safeParse(input);
  if (!parsed.success) return null;
  const { email, password, otp } = parsed.data;
  // Licznik zwiększany PRZED hashowaniem; próby równoległe nie omijają limitu.
  await rateLimit("login-email", email);
  await rateLimit("login-ip", requestIdentity(headers), 100);
  const user = await db.user.findUnique({
    where: { email },
    include: { tenant: true },
  });
  const valid = await verifyPassword(
    user?.passwordHash ?? (await getDummyHash()),
    password,
  );
  if (!valid || !user || !user.active || user.tenant.status === "SUSPENDED")
    return null;
  let step: number | null = null;
  if (user.totpSecretEncrypted) {
    if (!otp) return null;
    step = totpStep(
      unwrapSecret(
        user.totpSecretEncrypted,
        `totp:${user.tenantId}:${user.id}`,
      ),
      otp,
    );
    if (
      step === null ||
      (user.lastTotpStep !== null && step <= user.lastTotpStep)
    )
      return null;
  }
  return db.$transaction(async (tx) => {
    if (step !== null) {
      const consumed = await tx.user.updateMany({
        where: {
          id: user.id,
          tenantId: user.tenantId,
          OR: [{ lastTotpStep: null }, { lastTotpStep: { lt: step } }],
        },
        data: { lastTotpStep: step },
      });
      if (consumed.count !== 1) return null;
    }
    const session = await tx.authSession.create({
      data: {
        tenantId: user.tenantId,
        userId: user.id,
        version: user.sessionVersion,
        expiresAt: new Date(Date.now() + SESSION_MAX_AGE * 1000),
      },
    });
    await tx.auditLog.create({
      data: {
        tenantId: user.tenantId,
        actorId: user.id,
        action: "AUTH_LOGIN",
        resourceId: session.id,
      },
    });
    return {
      id: user.id,
      email: user.email,
      name: user.name,
      sessionId: session.id,
    };
  });
}

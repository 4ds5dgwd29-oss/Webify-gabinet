import "server-only";
import {
  S3Client,
  PutObjectCommand,
  GetObjectCommand,
  DeleteObjectCommand,
} from "@aws-sdk/client-s3";
import { mkdir, readFile, writeFile, unlink } from "node:fs/promises";
import path from "node:path";
function objectPath(key: string) {
  if (!/^[a-zA-Z0-9_-]+\/[a-zA-Z0-9_-]+$/.test(key))
    throw new Error("Niepoprawny klucz pliku.");
  return path.join(
    process.env.LOCAL_STORAGE_PATH || path.join(process.cwd(), "storage"),
    key,
  );
}
function client() {
  if (!process.env.S3_BUCKET || !process.env.S3_REGION)
    throw new Error("Skonfiguruj S3_BUCKET i S3_REGION w UE.");
  return new S3Client({
    region: process.env.S3_REGION,
    endpoint: process.env.S3_ENDPOINT || undefined,
    forcePathStyle: process.env.S3_FORCE_PATH_STYLE === "true",
    credentials: process.env.S3_ACCESS_KEY_ID
      ? {
          accessKeyId: process.env.S3_ACCESS_KEY_ID,
          secretAccessKey: process.env.S3_SECRET_ACCESS_KEY!,
        }
      : undefined,
  });
}
export async function putObject(key: string, bytes: Buffer) {
  if (process.env.STORAGE_DRIVER === "s3") {
    await client().send(
      new PutObjectCommand({
        Bucket: process.env.S3_BUCKET,
        Key: key,
        Body: bytes,
        ContentType: "application/octet-stream",
        ServerSideEncryption: "AES256",
      }),
    );
  } else {
    const target = objectPath(key);
    await mkdir(path.dirname(target), { recursive: true, mode: 0o700 });
    await writeFile(target, bytes, { mode: 0o600, flag: "wx" });
  }
}
export async function getObject(key: string) {
  if (process.env.STORAGE_DRIVER === "s3") {
    const result = await client().send(
      new GetObjectCommand({ Bucket: process.env.S3_BUCKET, Key: key }),
    );
    if (!result.Body) throw new Error("Brak pliku.");
    return Buffer.from(await result.Body.transformToByteArray());
  }
  return readFile(objectPath(key));
}
export async function deleteObject(key: string) {
  if (process.env.STORAGE_DRIVER === "s3")
    await client().send(
      new DeleteObjectCommand({ Bucket: process.env.S3_BUCKET, Key: key }),
    );
  else
    await unlink(objectPath(key)).catch((e) => {
      if (e.code !== "ENOENT") throw e;
    });
}

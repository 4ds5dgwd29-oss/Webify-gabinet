import "server-only";
import { createHash, timingSafeEqual } from "node:crypto";
import { z } from "zod";
export const credentialsSchema = z
  .object({
    merchantId: z.number().int().positive(),
    posId: z.number().int().positive(),
    apiKey: z.string().min(8).max(200),
    crc: z.string().min(8).max(200),
    sandbox: z.boolean(),
  })
  .strict();
export type Credentials = z.infer<typeof credentialsSchema>;
export function sign(data: Record<string, unknown>) {
  return createHash("sha384").update(JSON.stringify(data)).digest("hex");
}
export function validSignature(actual: string, expected: string) {
  return (
    /^[a-f0-9]{96}$/i.test(actual) &&
    timingSafeEqual(Buffer.from(actual.toLowerCase()), Buffer.from(expected))
  );
}
export const p24Base = (c: Credentials) =>
  c.sandbox ? "https://sandbox.przelewy24.pl" : "https://secure.przelewy24.pl";
export async function p24Request(
  c: Credentials,
  path: string,
  data: unknown,
  method = "POST",
) {
  const r = await fetch(`${p24Base(c)}/api/v1/${path}`, {
    method,
    headers: {
      Authorization: `Basic ${Buffer.from(`${c.posId}:${c.apiKey}`).toString("base64")}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(data),
    signal: AbortSignal.timeout(15000),
  });
  if (!r.ok)
    throw new Error("Operator nie potwierdził operacji. Spróbuj ponownie.");
  return r.json();
}

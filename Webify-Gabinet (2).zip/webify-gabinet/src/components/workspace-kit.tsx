"use client";
import { useCallback, useEffect, useRef, useState } from "react";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import { X, LoaderCircle } from "lucide-react";
export async function mutate<T = Record<string, unknown>>(
  action: string,
  data?: unknown,
  id?: string,
  version?: number,
): Promise<T> {
  const response = await fetch("/api/praktyka", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ action, data, id, version }),
  });
  const body = await response.json();
  if (!response.ok)
    throw new Error(body.error || "Nie udało się wykonać operacji.");
  return body;
}
export function useResource<T>(
  resource: string,
  params: Record<string, string> = {},
) {
  const query = new URLSearchParams({ resource, ...params }).toString();
  const [data, setData] = useState<T | null>(null),
    [error, setError] = useState(""),
    [loading, setLoading] = useState(true);
  const counter = useRef(0);
  const reload = useCallback(async () => {
    const current = ++counter.current;
    setLoading(true);
    try {
      const response = await fetch(`/api/praktyka?${query}`, {
        cache: "no-store",
      });
      const body = await response.json();
      if (!response.ok) throw new Error(body.error);
      if (current === counter.current) {
        setData(body);
        setError("");
      }
    } catch (e) {
      if (current === counter.current)
        setError(e instanceof Error ? e.message : "Błąd połączenia.");
    } finally {
      if (current === counter.current) setLoading(false);
    }
  }, [query]);
  useEffect(() => {
    void reload();
    return () => {
      counter.current++;
    };
  }, [reload]);
  return { data, error, loading, reload };
}
export function PageTitle({
  eyebrow = "Twój gabinet",
  title,
  description,
  children,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  children?: React.ReactNode;
}) {
  return (
    <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="text-xs font-semibold uppercase tracking-[.15em] text-muted-foreground">
          {eyebrow}
        </p>
        <h1 className="display mt-3 text-4xl">{title}</h1>
        {description && (
          <p className="mt-3 max-w-2xl text-sm text-muted-foreground">
            {description}
          </p>
        )}
      </div>
      {children}
    </div>
  );
}
export function Field({
  label,
  ...props
}: React.ComponentProps<typeof Input> & { label: string }) {
  return (
    <label className="block text-sm font-medium">
      {label}
      <Input className="mt-2" {...props} />
    </label>
  );
}
export function Select({
  label,
  children,
  ...props
}: React.SelectHTMLAttributes<HTMLSelectElement> & { label: string }) {
  return (
    <label className="block text-sm font-medium">
      {label}
      <select
        aria-label={label}
        className="mt-2 h-12 w-full rounded-lg border bg-background px-3"
        {...props}
      >
        {children}
      </select>
    </label>
  );
}
export function Textarea({
  label,
  ...props
}: React.TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string }) {
  return (
    <label className="block text-sm font-medium">
      {label}
      <textarea
        className="mt-2 min-h-28 w-full rounded-lg border bg-background p-3 font-normal focus-visible:outline-primary"
        {...props}
      />
    </label>
  );
}
export function ErrorMessage({ message }: { message?: string }) {
  return message ? (
    <p
      role="alert"
      className="my-4 rounded-xl border border-red-300 bg-red-50 p-4 text-sm text-red-800"
    >
      {message}
    </p>
  ) : null;
}
export function Loading() {
  return (
    <p
      role="status"
      className="flex items-center gap-2 py-10 text-sm text-muted-foreground"
    >
      <LoaderCircle size={18} className="animate-spin" />
      Wczytywanie…
    </p>
  );
}
export function Modal({
  title,
  onClose,
  children,
}: {
  title: string;
  onClose: () => void;
  children: React.ReactNode;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    ref.current?.showModal();
  }, []);
  return (
    <dialog
      ref={ref}
      onCancel={onClose}
      className="max-h-[90vh] w-[calc(100%-2rem)] max-w-2xl overflow-y-auto rounded-2xl border bg-card p-6 text-foreground shadow-xl backdrop:bg-black/40"
      aria-label={title}
    >
      <div className="mb-6 flex items-center justify-between gap-4">
        <h2 className="text-xl font-semibold">{title}</h2>
        <Button
          type="button"
          size="icon"
          variant="ghost"
          aria-label="Zamknij"
          onClick={onClose}
        >
          <X size={18} />
        </Button>
      </div>
      {children}
    </dialog>
  );
}
export function ActionForm({
  onSubmit,
  children,
  submit = "Zapisz",
  onSuccess,
}: {
  onSubmit: (form: FormData) => Promise<unknown>;
  children: React.ReactNode;
  submit?: string;
  onSuccess?: () => void;
}) {
  const [error, setError] = useState(""),
    [busy, setBusy] = useState(false),
    [success, setSuccess] = useState(false);
  return (
    <form
      className="space-y-5"
      onSubmit={async (event) => {
        event.preventDefault();
        const form = new FormData(event.currentTarget);
        setBusy(true);
        setError("");
        setSuccess(false);
        try {
          await onSubmit(form);
          setSuccess(true);
          onSuccess?.();
        } catch (e) {
          setError(e instanceof Error ? e.message : "Nie udało się zapisać.");
        } finally {
          setBusy(false);
        }
      }}
    >
      {children}
      <ErrorMessage message={error} />
      {success && (
        <p role="status" className="text-sm text-primary">
          Zapisano zmiany.
        </p>
      )}
      <Button disabled={busy} type="submit">
        {busy ? "Zapisywanie…" : submit}
      </Button>
    </form>
  );
}
export function value(form: FormData, key: string) {
  return String(form.get(key) ?? "");
}
export type Patient = {
  id: string;
  firstName: string;
  lastName: string;
  email: string | null;
  phone: string | null;
  birthDate: string | null;
  emergencyName: string | null;
  emergencyPhone: string | null;
  status: "ACTIVE" | "COMPLETED" | "WAITLIST";
  consentData: boolean;
  consentContact: boolean;
  consentRecording: boolean;
  tags: string[];
  archivedAt: string | null;
  version: number;
};
export type Appointment = {
  id: string;
  patientId: string;
  providerId: string;
  serviceId: string | null;
  startsAt: string;
  endsAt: string;
  type: "CONSULTATION" | "INDIVIDUAL" | "COUPLE" | "ONLINE";
  status: "SCHEDULED" | "COMPLETED" | "CANCELLED" | "NO_SHOW";
  onlineUrl: string | null;
  priceGrosze: number;
  version: number;
  patient: { firstName: string; lastName: string };
  provider: { name: string };
};
export type Options = {
  providers: Array<{ id: string; name: string }>;
  patients: Array<{ id: string; firstName: string; lastName: string }>;
  services: Array<{
    id: string;
    name: string;
    durationMinutes: number;
    priceGrosze: number;
    depositGrosze: number;
  }>;
  hours: Array<{
    providerId: string;
    weekday: number;
    startMinute: number;
    endMinute: number;
  }>;
  leaves: Array<{
    id: string;
    providerId: string;
    startsAt: string;
    endsAt: string;
    label: string;
  }>;
  timezone: string;
  practiceName: string;
  address: string;
  taxId: string;
  onboardingStep: number;
};

"use client";
import { useState } from "react";
import { Button } from "./ui/button";
export function VisitResponse({ token }: { token: string }) {
  const [message, setMessage] = useState(""),
    [busy, setBusy] = useState(false),
    [done, setDone] = useState(false);
  async function submit(action: string) {
    setBusy(true);
    try {
      const r = await fetch("/api/wizyta", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, action }),
      });
      const body = await r.json();
      if (!r.ok) throw new Error(body.error);
      setMessage(body.message);
      setDone(true);
    } catch (e) {
      setMessage((e as Error).message);
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      {!done && (
        <div className="mt-7 flex flex-wrap gap-3">
          <Button disabled={busy} onClick={() => void submit("confirm")}>
            Potwierdzam wizytę
          </Button>
          <Button
            disabled={busy}
            variant="outline"
            onClick={() => void submit("cancel")}
          >
            Odwołuję wizytę
          </Button>
        </div>
      )}
      {message && (
        <p role="status" className="mt-6 text-sm">
          {message}
        </p>
      )}
    </>
  );
}

import "next-auth";
import "next-auth/jwt";
import type { Role } from "@prisma/client";
declare module "next-auth" {
  interface User {
    sessionId: string;
  }
  interface Session {
    sessionId?: string;
    user?: { id: string; name: string; email: string; role: Role };
  }
}
declare module "next-auth/jwt" {
  interface JWT {
    sessionId?: string;
  }
}

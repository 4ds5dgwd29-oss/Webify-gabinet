import { appointmentTokenInfo } from "@/server/dal/reminders";
import { VisitResponse } from "@/components/visit-response";
import { Brand } from "@/components/brand";
export const metadata = {
  title: "Potwierdzenie wizyty",
  robots: { index: false, follow: false },
};
export default async function Page({
  params,
}: {
  params: Promise<{ token: string }>;
}) {
  const { token } = await params;
  let info;
  try {
    info = await appointmentTokenInfo(token);
  } catch {
    return (
      <main id="tresc" className="mx-auto max-w-lg px-6 py-20">
        <Brand />
        <h1 className="display mt-10 text-3xl">Link jest już niedostępny</h1>
        <p className="mt-5 text-sm text-muted-foreground">
          Link wygasł, został użyty lub termin się zmienił. Skontaktuj się z
          gabinetem.
        </p>
      </main>
    );
  }
  return (
    <main id="tresc" className="mx-auto max-w-lg px-6 py-20">
      <Brand />
      <h1 className="display mt-10 text-4xl">Twoja wizyta</h1>
      <p className="mt-5">
        {info.startsAt.toLocaleString("pl-PL", { timeZone: info.timezone })}
      </p>
      <VisitResponse token={token} />
      <p className="mt-7 text-xs text-muted-foreground">
        Link jest jednorazowy. Samo otwarcie strony nie zmienia wizyty.
      </p>
    </main>
  );
}

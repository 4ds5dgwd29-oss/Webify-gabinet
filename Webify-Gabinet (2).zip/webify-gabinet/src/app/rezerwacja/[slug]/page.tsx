import { BookingView } from "@/components/commerce-view";
export default async function Page({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  return <BookingView slug={(await params).slug} />;
}

import { AuthShell } from "@/components/auth-shell";
import { AuthForm } from "@/components/auth-form";
export const metadata = { title: "Utwórz gabinet" };
export default function RegisterPage() {
  return (
    <AuthShell register>
      {process.env.ALLOW_REGISTRATION === "true" ? (
        <AuthForm register />
      ) : (
        <p role="status">
          Rejestracja jest obecnie zamknięta. Skontaktuj się z administratorem
          Webify.
        </p>
      )}
    </AuthShell>
  );
}

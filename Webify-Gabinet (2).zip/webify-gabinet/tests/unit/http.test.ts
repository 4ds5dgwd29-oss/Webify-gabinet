import { it, expect } from "vitest";
import { readMutation } from "@/server/security/http";
function request(body: string, origin = "http://localhost:3000") {
  return new Request("http://localhost:3000/api/test", {
    method: "POST",
    headers: { origin, "content-type": "application/json" },
    body,
  });
}
it("odrzuca żądanie mutacji z obcego origin", async () =>
  expect(readMutation(request("{}", "https://obca.test"))).rejects.toThrow());
it("odrzuca brak origin", async () =>
  expect(
    readMutation(
      new Request("http://localhost:3000", { method: "POST", body: "{}" }),
    ),
  ).rejects.toThrow());
it("akceptuje JSON tylko z własnego origin", async () =>
  expect(readMutation(request('{"x":1}'))).resolves.toEqual({ x: 1 }));
it("ogranicza rzeczywistą wielkość żądania", async () =>
  expect(
    readMutation(request(JSON.stringify({ x: "a".repeat(17000) }))),
  ).rejects.toThrow("za duże"));
it("odrzuca uszkodzony JSON", async () =>
  expect(readMutation(request("{"))).rejects.toThrow("JSON"));

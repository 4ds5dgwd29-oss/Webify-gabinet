import { describe, expect, it } from "vitest";
import {
  requirePractice,
  requireClinical,
  requireWrite,
  requirePlatform,
  type Principal,
} from "@/server/security/policy";
const owner: Principal = {
  userId: "u",
  tenantId: "a",
  role: "OWNER",
  kind: "PRACTICE",
  status: "ACTIVE",
};
describe("RBAC", () => {
  it("właściciel czyta i zapisuje dane gabinetu oraz ma uprawnienia kliniczne", () => {
    expect(() => {
      requirePractice(owner);
      requireWrite(owner);
      requireClinical(owner);
    }).not.toThrow();
  });
  it("recepcja nie uzyskuje uprawnień klinicznych", () =>
    expect(() => requireClinical({ ...owner, role: "STAFF" })).toThrow());
  it("administrator platformy nie czyta pacjentów ani notatek", () => {
    const admin = {
      ...owner,
      role: "SUPER_ADMIN" as const,
      kind: "PLATFORM" as const,
    };
    expect(() => requirePractice(admin)).toThrow();
    expect(() => requireClinical(admin)).toThrow();
    expect(() => requirePlatform(admin)).not.toThrow();
  });
  it("samą zmianą roli nie można ominąć rodzaju tenantu", () => {
    expect(() => requirePlatform({ ...owner, role: "SUPER_ADMIN" })).toThrow();
    expect(() => requirePractice({ ...owner, kind: "PLATFORM" })).toThrow();
  });
  it("właściciel i recepcja nie mają dostępu do panelu platformy", () => {
    expect(() => requirePlatform(owner)).toThrow();
    expect(() => requirePlatform({ ...owner, role: "STAFF" })).toThrow();
  });
  it("konto tylko do odczytu nie zapisuje danych", () => {
    expect(() =>
      requirePractice({ ...owner, status: "READ_ONLY" }),
    ).not.toThrow();
    expect(() => requireWrite({ ...owner, status: "READ_ONLY" })).toThrow();
  });
  it("zawieszony gabinet nie czyta danych", () =>
    expect(() => requirePractice({ ...owner, status: "SUSPENDED" })).toThrow());
});

import { it, expect } from "vitest";
import { registerSchema, loginSchema, patientSchema } from "@/lib/validation";
const valid = {
  name: "Anna Nowak",
  practiceName: "Gabinet",
  email: " ANNA@example.test ",
  password: "dlugie-unikalne-haslo",
};
it("normalizuje e-mail", () =>
  expect(registerSchema.parse(valid).email).toBe("anna@example.test"));
it("odrzuca przekazanie roli i tenantu przez klienta", () => {
  expect(
    registerSchema.safeParse({ ...valid, role: "SUPER_ADMIN" }).success,
  ).toBe(false);
  expect(
    patientSchema.safeParse({
      firstName: "A",
      lastName: "B",
      tenantId: "other",
    }).success,
  ).toBe(false);
});
it("odrzuca krótkie i nadmiernie długie hasła", () => {
  expect(registerSchema.safeParse({ ...valid, password: "123" }).success).toBe(
    false,
  );
  expect(
    loginSchema.safeParse({ email: valid.email, password: "x".repeat(129) })
      .success,
  ).toBe(false);
});
it("odrzuca niepoprawny kod 2FA", () =>
  expect(
    loginSchema.safeParse({ email: valid.email, password: "pass", otp: "<x>" })
      .success,
  ).toBe(false));

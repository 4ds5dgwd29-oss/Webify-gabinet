import { it, expect } from "vitest";
import { localDate, recurrence, ical, overlap } from "@/lib/calendar";
import { parsePatientsCsv } from "@/server/dal/patients";
it("odrzuca nieistniejącą i dwuznaczną godzinę zmiany czasu", () => {
  expect(() => localDate("2026-03-29T02:30", "Europe/Warsaw")).toThrow();
  expect(() => localDate("2026-10-25T02:30", "Europe/Warsaw")).toThrow();
});
it("cykl zachowuje czas lokalny przez zmianę czasu", () => {
  const r = recurrence("2026-10-18T10:00", "Europe/Warsaw", 50, 2, 1);
  expect(r[0].startsAt.toISOString()).toContain("08:00");
  expect(r[1].startsAt.toISOString()).toContain("09:00");
});
it("sąsiadujące terminy nie kolidują", () => {
  const a = { startsAt: new Date(0), endsAt: new Date(100) },
    b = { startsAt: new Date(100), endsAt: new Date(200) };
  expect(overlap(a, b)).toBe(false);
  expect(overlap(a, { ...b, startsAt: new Date(99) })).toBe(true);
});
it("iCal nie zawiera danych pacjenta", () => {
  const text = ical([
    {
      id: "x",
      startsAt: new Date(0),
      endsAt: new Date(5000),
      status: "CANCELLED",
      updatedAt: new Date(0),
    },
  ]);
  expect(text).toContain("STATUS:CANCELLED");
  expect(text).toContain("CLASS:PRIVATE");
  expect(text).toContain("\r\n");
});
it("CSV parsuje cudzysłowy i nie przyjmuje domniemanych zgód", () => {
  const rows = parsePatientsCsv(
    'imie,nazwisko,email,telefon,data_urodzenia\nAnna,"Nowak, Kowalska",a@example.test,,1990-01-02',
  );
  expect(rows[0].lastName).toBe("Nowak, Kowalska");
  expect(rows[0].consentContact).toBe(false);
});
it("CSV odrzuca niepoprawne wiersze", () =>
  expect(() => parsePatientsCsv("foo,bar\nA,B")).toThrow());

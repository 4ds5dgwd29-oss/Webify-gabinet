import { describe, it, expect } from "vitest";
import { randomBytes } from "node:crypto";
import {
  seal,
  unseal,
  createTenantKey,
  unwrapSecret,
} from "@/server/security/crypto";
describe("AES-256-GCM", () => {
  const key = randomBytes(32);
  it("szyfruje i odszyfrowuje polski tekst", () => {
    const value = seal("Poufna treść: ąęł", key, "tenant:a");
    expect(value).not.toContain("Poufna");
    expect(unseal(value, key, "tenant:a")).toBe("Poufna treść: ąęł");
  });
  it("każde szyfrowanie ma inny nonce", () =>
    expect(seal("tekst", key, "a")).not.toBe(seal("tekst", key, "a")));
  it("odrzuca inny tenant w AAD", () =>
    expect(() => unseal(seal("x", key, "a"), key, "b")).toThrow());
  it("odrzuca inny klucz", () =>
    expect(() => unseal(seal("x", key, "a"), randomBytes(32), "a")).toThrow());
  it("odrzuca modyfikację szyfrogramu", () => {
    const parts = seal("abc", key, "a").split(".");
    const bytes = Buffer.from(parts[3], "base64url");
    bytes[0] ^= 1;
    parts[3] = bytes.toString("base64url");
    expect(() => unseal(parts.join("."), key, "a")).toThrow();
  });
  it("odrzuca wadliwy format i długość klucza", () => {
    expect(() => unseal("bad", key, "a")).toThrow();
    expect(() => seal("x", Buffer.alloc(8), "a")).toThrow();
  });
  it("tworzy losowe klucze tenantów i wiąże je z ich ID", () => {
    const a = createTenantKey("a"),
      b = createTenantKey("b");
    expect(a).not.toBe(b);
    expect(Buffer.from(unwrapSecret(a, "tenant-key:a"), "base64")).toHaveLength(
      32,
    );
    expect(() => unwrapSecret(a, "tenant-key:b")).toThrow();
  });
});

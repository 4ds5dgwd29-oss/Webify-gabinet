import { it, expect } from "vitest";
import { hashPassword, verifyPassword } from "@/server/auth/password";
it("hashuje hasło Argon2id z solą i weryfikuje je", async () => {
  const a = await hashPassword("To-jest-dlugie-haslo"),
    b = await hashPassword("To-jest-dlugie-haslo");
  expect(a).toMatch(/^\$argon2id\$/);
  expect(a).not.toBe(b);
  expect(await verifyPassword(a, "To-jest-dlugie-haslo")).toBe(true);
  expect(await verifyPassword(a, "Niepoprawne")).toBe(false);
  expect(await verifyPassword("bad", "x")).toBe(false);
});

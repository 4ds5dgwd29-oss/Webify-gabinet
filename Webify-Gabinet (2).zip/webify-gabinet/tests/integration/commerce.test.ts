import { beforeEach, afterAll, describe, it, expect, vi } from "vitest";
import { fixtures } from "../fixtures";
import { db } from "@/server/db";
import {
  capacity,
  applySubscription,
  p24Notification,
} from "@/server/dal/commerce";
import { book, publicSlots } from "@/server/dal/booking";
import { wrapSecret } from "@/server/security/crypto";
import { sign } from "@/server/p24";
import { DateTime } from "luxon";
vi.mock("@/server/p24", async (original) => ({
  ...(await original<object>()),
  p24Request: vi.fn(async () => ({ data: { status: "success" } })),
}));
beforeEach(fixtures);
afterAll(() => db.$disconnect());
describe("Płatności i rezerwacje", () => {
  it("limity dotyczą wyłącznie bieżącego gabinetu", async () => {
    await db.tenant.update({ where: { id: "a" }, data: { patientLimit: 1 } });
    await expect(capacity(db, "a", "patient")).rejects.toThrow("limit");
    await expect(capacity(db, "b", "patient")).resolves.toBeUndefined();
  });
  it("rezerwuje dostępny termin i nie ujawnia pacjentów", async () => {
    await db.tenant.update({
      where: { id: "a" },
      data: { bookingEnabled: true },
    });
    await db.service.create({
      data: {
        id: "svc",
        tenantId: "a",
        name: "Konsultacja",
        durationMinutes: 50,
      },
    });
    const day = DateTime.now()
      .setZone("Europe/Warsaw")
      .plus({ days: 2 })
      .toISODate()!;
    const result = await publicSlots("a", "svc", day);
    expect(JSON.stringify(result)).not.toContain("Przykładowa");
    const slot = result.slots[0];
    const data = {
      slug: "a",
      serviceId: "svc",
      ...slot,
      firstName: "Nowa",
      lastName: "Osoba",
      email: "new@example.test",
      phone: "",
      consent: true,
    };
    expect(await book(data)).toEqual({ ok: true });
    await expect(book(data)).rejects.toThrow("koliduje");
    expect(await db.patient.count({ where: { tenantId: "a" } })).toBe(2);
  });
  it("weryfikuje P24 przed księgowaniem i nie duplikuje wpłaty", async () => {
    const c = {
      merchantId: 123,
      posId: 123,
      apiKey: "testtest",
      crc: "crcsecret",
      sandbox: true,
    };
    await db.appointment.create({
      data: {
        id: "visit",
        tenantId: "a",
        patientId: "pa",
        providerId: "oa",
        startsAt: new Date(Date.now() + 86400000),
        endsAt: new Date(Date.now() + 90000000),
        priceGrosze: 20000,
      },
    });
    const o = await db.paymentOrder.create({
      data: {
        tenantId: "a",
        appointmentId: "visit",
        amountGrosze: 20000,
        credentialsEncrypted: wrapSecret(JSON.stringify(c), "p24:a"),
      },
    });
    const n = {
      merchantId: 123,
      posId: 123,
      sessionId: o.id,
      amount: 20000,
      originAmount: 20000,
      currency: "PLN",
      orderId: 234,
      methodId: 1,
      statement: "Test",
    };
    await expect(
      p24Notification({ ...n, sign: "0".repeat(96) }),
    ).rejects.toThrow("podpis");
    const signed = { ...n, sign: sign({ ...n, crc: c.crc }) };
    await p24Notification(signed);
    await p24Notification(signed);
    expect(await db.payment.count({ where: { tenantId: "a" } })).toBe(1);
  });
  it("Stripe jest idempotentny i odrzuca starsze zdarzenie", async () => {
    await db.tenant.update({
      where: { id: "a" },
      data: { stripeCustomerId: "cus_a" },
    });
    await db.plan.create({
      data: {
        tenantId: "webify-platform",
        code: "PRO",
        name: "Pro",
        monthlyGrosze: 9900,
        yearlyGrosze: 99000,
        userLimit: 5,
        patientLimit: 500,
        stripeMonthlyId: "price_pro",
      },
    });
    const sub = {
      id: "sub_a",
      customer: "cus_a",
      metadata: { tenantId: "a" },
      status: "active",
      cancel_at_period_end: false,
      items: {
        data: [{ price: { id: "price_pro" }, current_period_end: 2000000000 }],
      },
    };
    await applySubscription(
      { id: "evt1", type: "customer.subscription.updated", created: 10 },
      sub as never,
    );
    await applySubscription(
      { id: "evt1", type: "customer.subscription.updated", created: 10 },
      sub as never,
    );
    await applySubscription(
      { id: "evt0", type: "customer.subscription.deleted", created: 5 },
      { ...sub, status: "canceled" } as never,
    );
    expect(
      (await db.tenant.findUniqueOrThrow({ where: { id: "a" } })).status,
    ).toBe("ACTIVE");
    expect(await db.webhookEvent.count()).toBe(2);
  });
});

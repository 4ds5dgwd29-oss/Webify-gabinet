import { beforeEach, afterAll, it, expect } from "vitest";
import { fixtures } from "../fixtures";
import { db } from "@/server/db";
import {
  exportPatient,
  setRetention,
  erasePatient,
  cleanObjects,
  legalPdf,
} from "@/server/dal/privacy";
import { saveNote } from "@/server/dal/clinical";
import { uploadDocument } from "@/server/dal/documents";
import { getObject } from "@/server/storage";
beforeEach(fixtures);
afterAll(() => db.$disconnect());
it("eksport respektuje tenant, rolę i prywatność autora", async () => {
  await saveNote("soa2", {
    patientId: "pa",
    html: "Prywatna treść",
    private: true,
    version: 0,
  });
  const data = await exportPatient("soa", "pa");
  expect(data.omittedPrivate).toBe(1);
  expect(JSON.stringify(data)).not.toContain("Prywatna treść");
  await expect(exportPatient("sob", "pa")).rejects.toThrow();
  await expect(exportPatient("sstaff", "pa")).rejects.toThrow();
  await expect(exportPatient("sadmin", "pa")).rejects.toThrow();
});
it("usuwanie wymaga retencji, hasła i archiwizacji; pliki usuwa kolejka", async () => {
  const d = {
    patientId: "pa",
    confirmation: "USUŃ TRWALE",
    password: "Testowe-haslo-12345",
    reviewed: true,
  };
  await expect(erasePatient("soa", d)).rejects.toThrow("archiwizacja");
  const file = await uploadDocument("soa", {
    patientId: "pa",
    name: "Zgoda.txt",
    mimeType: "text/plain",
    base64: Buffer.from("Zgoda").toString("base64"),
  });
  const doc = await db.document.findUniqueOrThrow({ where: { id: file.id } });
  await setRetention("soa", {
    patientId: "pa",
    retentionUntil: new Date(Date.now() - 86400000).toISOString(),
    legalHold: false,
    reviewed: true,
  });
  await db.patient.update({
    where: { id: "pa" },
    data: { archivedAt: new Date() },
  });
  await expect(erasePatient("soa", { ...d, password: "złe" })).rejects.toThrow(
    "hasło",
  );
  await erasePatient("soa", d);
  expect(await db.patient.findUnique({ where: { id: "pa" } })).toBeNull();
  expect(await db.patient.findUnique({ where: { id: "pb" } })).not.toBeNull();
  await cleanObjects();
  await expect(getObject(doc.objectKey)).rejects.toThrow();
  expect(
    await db.auditLog.count({
      where: { tenantId: "a", action: "PATIENT_ERASED" },
    }),
  ).toBe(1);
});
it("szablony prawne są PDF i wymagają uprawnień właściciela", async () => {
  expect(
    Buffer.from(await legalPdf("soa", "privacy"))
      .subarray(0, 5)
      .toString(),
  ).toBe("%PDF-");
  await expect(legalPdf("sstaff", "privacy")).rejects.toThrow();
});
it("eksport obejmuje również wizyty przekraczające limit widoku historii", async () => {
  const start = Date.now() - 400 * 86400000;
  await db.appointment.createMany({
    data: Array.from({ length: 301 }, (_, i) => ({
      tenantId: "a",
      patientId: "pa",
      providerId: "oa",
      startsAt: new Date(start + i * 86400000),
      endsAt: new Date(start + i * 86400000 + 3000000),
      status: "COMPLETED" as const,
    })),
  });
  expect((await exportPatient("soa", "pa")).appointments).toHaveLength(301);
});

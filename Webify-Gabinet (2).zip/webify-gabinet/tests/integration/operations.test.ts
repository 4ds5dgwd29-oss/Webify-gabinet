import { beforeEach, afterAll, it, expect, vi } from "vitest";
vi.mock("@/server/messaging", () => ({
  sendMessage: vi.fn(async () => "mock-message"),
}));
import { db } from "@/server/db";
import { fixtures } from "../fixtures";
import { addPayment, billingData, voidPayment } from "@/server/dal/billing";
import {
  enqueueReminders,
  deliverOutbox,
  useAppointmentToken,
} from "@/server/dal/reminders";
import { unwrapSecret } from "@/server/security/crypto";
import { sendMessage } from "@/server/messaging";
import { randomUUID } from "node:crypto";
beforeEach(async () => {
  await fixtures();
  vi.clearAllMocks();
  await db.appointment.create({
    data: {
      id: "visit",
      tenantId: "a",
      patientId: "pa",
      providerId: "oa",
      startsAt: new Date(Date.now() + 12 * 3600000),
      endsAt: new Date(Date.now() + 13 * 3600000),
      priceGrosze: 20000,
    },
  });
});
afterAll(() => db.$disconnect());
it("wpłata jest idempotentna i nie przekracza należności", async () => {
  const data = {
    appointmentId: "visit",
    amountGrosze: 10000,
    method: "CASH",
    requestId: randomUUID(),
  };
  const a = await addPayment("soa", data);
  expect(await addPayment("soa", data)).toEqual(a);
  expect(await db.payment.count()).toBe(1);
  await expect(
    addPayment("soa", {
      ...data,
      requestId: randomUUID(),
      amountGrosze: 15000,
    }),
  ).rejects.toMatchObject({ status: 409 });
  await expect(
    addPayment("sob", { ...data, requestId: randomUUID() }),
  ).rejects.toMatchObject({ status: 404 });
});
it("anulowana wpłata nie jest w przychodzie", async () => {
  const p = await addPayment("soa", {
    appointmentId: "visit",
    amountGrosze: 20000,
    method: "CASH",
    requestId: randomUUID(),
  });
  const month = new Date().toISOString().slice(0, 7);
  expect((await billingData("soa", month)).totalGrosze).toBe(20000);
  await voidPayment("soa", p.id);
  expect((await billingData("soa", month)).totalGrosze).toBe(0);
});
it("przypomnienie jest deduplikowane i nie ujawnia odbiorcy w bazie", async () => {
  expect((await enqueueReminders()).queued).toBe(1);
  expect((await enqueueReminders()).queued).toBe(0);
  const m = await db.outboxMessage.findFirstOrThrow();
  expect(m.payloadEncrypted).not.toContain("pacjent@example");
  expect(await deliverOutbox()).toEqual({ sent: 1, failed: 0 });
  expect(await deliverOutbox()).toEqual({ sent: 0, failed: 0 });
  expect(sendMessage).toHaveBeenCalledTimes(1);
});
it("wycofanie zgody przed wysyłką anuluje wiadomość", async () => {
  await enqueueReminders();
  await db.patient.update({
    where: { id: "pa" },
    data: { consentContact: false },
  });
  await deliverOutbox();
  expect(sendMessage).not.toHaveBeenCalled();
  expect((await db.outboxMessage.findFirstOrThrow()).status).toBe("CANCELLED");
});
it("link odwołuje wizytę tylko raz", async () => {
  await enqueueReminders();
  const m = await db.outboxMessage.findFirstOrThrow();
  const payload = JSON.parse(
    unwrapSecret(m.payloadEncrypted, `message:${m.id}`),
  );
  const token = payload.text.split("/wizyta/")[1];
  await useAppointmentToken(token, "cancel");
  expect(
    (await db.appointment.findUniqueOrThrow({ where: { id: "visit" } })).status,
  ).toBe("CANCELLED");
  await expect(useAppointmentToken(token, "confirm")).rejects.toThrow();
});

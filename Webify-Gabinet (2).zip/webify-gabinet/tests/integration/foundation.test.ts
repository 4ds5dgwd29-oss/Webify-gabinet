import { beforeAll, beforeEach, afterAll, describe, it, expect } from "vitest";
import { db } from "@/server/db";
import { practiceRepository } from "@/server/dal/practice";
import { listPractices } from "@/server/dal/platform";
import { hashPassword } from "@/server/auth/password";
import { authenticate } from "@/server/auth/credentials";
import { registerPractice } from "@/server/auth/register";
import { resolveSession } from "@/server/auth/session-store";
import { rateLimit } from "@/server/auth/rate-limit";
import { changeTotp } from "@/server/dal/account";
import { wrapSecret } from "@/server/security/crypto";
import { authenticator } from "otplib";
const password = "Testowe-haslo-12345";
let hash: string;
beforeAll(async () => {
  if (!process.env.TEST_DATABASE_URL)
    throw new Error(
      "Ustaw TEST_DATABASE_URL na osobną bazę PostgreSQL *_test.",
    );
  hash = await hashPassword(password);
});
beforeEach(async () => {
  await db.$disconnect(); // Każdy test dostaje świeże połączenie i czyste dane.
  await db.$executeRawUnsafe('TRUNCATE TABLE "Tenant" CASCADE');
  await db.tenant.createMany({
    data: [
      {
        id: "webify-platform",
        name: "Platforma",
        slug: "platform",
        kind: "PLATFORM",
        status: "ACTIVE",
      },
      { id: "a", name: "Gabinet A", slug: "a", status: "ACTIVE" },
      { id: "b", name: "Gabinet B", slug: "b", status: "ACTIVE" },
    ],
  });
  await db.user.createMany({
    data: [
      {
        id: "owner-a",
        tenantId: "a",
        name: "Właściciel A",
        email: "a@example.test",
        passwordHash: hash,
        role: "OWNER",
      },
      {
        id: "staff-a",
        tenantId: "a",
        name: "Recepcja A",
        email: "staff@example.test",
        passwordHash: hash,
        role: "STAFF",
      },
      {
        id: "owner-b",
        tenantId: "b",
        name: "Właściciel B",
        email: "b@example.test",
        passwordHash: hash,
        role: "OWNER",
      },
      {
        id: "admin",
        tenantId: "webify-platform",
        tenantKind: "PLATFORM",
        name: "Administrator",
        email: "admin@example.test",
        passwordHash: hash,
        role: "SUPER_ADMIN",
      },
    ],
  });
  for (const [id, tenantId, userId] of [
    ["sa", "a", "owner-a"],
    ["ss", "a", "staff-a"],
    ["sb", "b", "owner-b"],
    ["sp", "webify-platform", "admin"],
  ])
    await db.authSession.create({
      data: {
        id,
        tenantId,
        userId,
        version: 0,
        expiresAt: new Date(Date.now() + 3600000),
      },
    });
  await db.patient.createMany({
    data: [
      {
        id: "pa",
        tenantId: "a",
        firstName: "Fikcyjna",
        lastName: "Pacjentka A",
      },
      { id: "pb", tenantId: "b", firstName: "Fikcyjny", lastName: "Pacjent B" },
    ],
  });
});
afterAll(async () => db.$disconnect());
describe("izolacja tenantów przez Prisma i protokół PostgreSQL", () => {
  it("lista zawiera tylko pacjentów własnego gabinetu", async () => {
    const items = await practiceRepository("sa").listPatients();
    expect(items.map((p) => p.id)).toEqual(["pa"]);
  });
  it("znajomość obcego ID nie pozwala odczytać karty", async () => {
    await expect(
      practiceRepository("sa").getPatient("pb"),
    ).rejects.toMatchObject({ status: 404 });
  });
  it("nie można zarchiwizować pacjenta innego gabinetu", async () => {
    await expect(
      practiceRepository("sa").archivePatient("pb"),
    ).rejects.toMatchObject({ status: 404 });
    expect(
      (await db.patient.findUniqueOrThrow({ where: { id: "pb" } })).archivedAt,
    ).toBeNull();
  });
  it("zapis zawsze dostaje tenant z sesji", async () => {
    const p = await practiceRepository("sa").createPatient({
      firstName: "Test",
      lastName: "Przykład",
    });
    expect(p.tenantId).toBe("a");
    await expect(
      practiceRepository("sa").createPatient({
        firstName: "Test",
        lastName: "Przykład",
        tenantId: "b",
      }),
    ).rejects.toThrow();
  });
  it("archiwizacja zachowuje rekord i usuwa go z aktywnej listy", async () => {
    await practiceRepository("sa").archivePatient("pa");
    expect(await practiceRepository("sa").listPatients()).toEqual([]);
    expect(await db.patient.count({ where: { id: "pa" } })).toBe(1);
  });
  it("odczyt karty zostawia audit log bez danych pacjenta", async () => {
    await practiceRepository("sa").getPatient("pa");
    const log = await db.auditLog.findFirstOrThrow({
      where: { action: "PATIENT_READ" },
    });
    expect(log).toMatchObject({
      tenantId: "a",
      actorId: "owner-a",
      resourceId: "pa",
    });
    expect(JSON.stringify(log)).not.toContain("Pacjentka");
  });
  it("recepcja czyta kartę kontaktową, ale nie uzyskuje dostępu klinicznego", async () => {
    expect((await practiceRepository("ss").getPatient("pa")).id).toBe("pa");
    await expect(
      practiceRepository("ss").clinicalAccess(),
    ).rejects.toMatchObject({ status: 403 });
  });
  it("superadmin nie ma dostępu do pacjentów i notatek", async () => {
    await expect(
      practiceRepository("sp").getPatient("pa"),
    ).rejects.toMatchObject({ status: 403 });
    await expect(
      practiceRepository("sp").clinicalAccess(),
    ).rejects.toMatchObject({ status: 403 });
  });
  it("panel platformy zwraca tylko metadane; właściciel jest blokowany", async () => {
    await expect(listPractices("sa")).rejects.toMatchObject({ status: 403 });
    const list = await listPractices("sp");
    expect(list).toHaveLength(2);
    expect(Object.keys(list[0]).sort()).toEqual(
      ["id", "name", "status", "createdAt", "trialEndsAt"].sort(),
    );
  });
  it("przekazanie tenantId zamiast sesji nie uwierzytelnia", async () => {
    await expect(
      practiceRepository("a").getPatient("pa"),
    ).rejects.toMatchObject({ status: 401 });
  });
  it("klucz obcy nie pozwala przypiąć sesji do użytkownika innego tenantu", async () => {
    await expect(
      db.authSession.create({
        data: {
          tenantId: "a",
          userId: "owner-b",
          version: 0,
          expiresAt: new Date(Date.now() + 10000),
        },
      }),
    ).rejects.toThrow();
  });
  it("baza odrzuca SUPER_ADMIN w gabinecie", async () => {
    await expect(
      db.user.update({
        where: { id: "owner-a" },
        data: { role: "SUPER_ADMIN" },
      }),
    ).rejects.toThrow(/User_role_tenant_kind_check/);
  });
  it("baza odrzuca zmianę i usunięcie audit logu", async () => {
    const log = await db.auditLog.create({
      data: { tenantId: "a", actorId: "owner-a", action: "TEST" },
    });
    await expect(
      db.auditLog.update({ where: { id: log.id }, data: { action: "FAKE" } }),
    ).rejects.toThrow(/Audit log is append-only/);
    await db.$disconnect();
    await expect(db.auditLog.delete({ where: { id: log.id } })).rejects.toThrow(
      /Audit log is append-only/,
    );
  });
});
describe("sesje i uwierzytelnianie", () => {
  it("loguje poprawnym hasłem i odrzuca złe", async () => {
    expect(
      await authenticate({ email: "a@example.test", password, otp: "" }),
    ).toMatchObject({ id: "owner-a" });
    expect(
      await authenticate({
        email: "a@example.test",
        password: "błędne",
        otp: "",
      }),
    ).toBeNull();
  });
  it("odrzuca nieznanego użytkownika", async () => {
    expect(
      await authenticate({ email: "unknown@example.test", password, otp: "" }),
    ).toBeNull();
  });
  it("odrzuca sesję cofniętą", async () => {
    await db.authSession.update({
      where: { id: "sa" },
      data: { revokedAt: new Date() },
    });
    await expect(resolveSession("sa")).rejects.toMatchObject({ status: 401 });
  });
  it("wylogowuje po 15 minutach bezczynności także po stronie serwera", async () => {
    await db.authSession.update({
      where: { id: "sa" },
      data: { lastSeenAt: new Date(Date.now() - 16 * 60000) },
    });
    await expect(resolveSession("sa", true)).rejects.toMatchObject({
      status: 401,
    });
  });
  it("samo odpytywanie sesji nie przedłuża czasu aktywności", async () => {
    const time = new Date(Date.now() - 100000);
    await db.authSession.update({
      where: { id: "sa" },
      data: { lastSeenAt: time },
    });
    await resolveSession("sa");
    expect(
      (
        await db.authSession.findUniqueOrThrow({ where: { id: "sa" } })
      ).lastSeenAt.getTime(),
    ).toBe(time.getTime());
  });
  it("wygasła sesja jest odrzucana niezależnie od aktywności", async () => {
    await db.authSession.update({
      where: { id: "sa" },
      data: { expiresAt: new Date(Date.now() - 1) },
    });
    await expect(resolveSession("sa")).rejects.toMatchObject({ status: 401 });
  });
  it("dezaktywacja użytkownika od razu odbiera sesję", async () => {
    await db.user.update({ where: { id: "owner-a" }, data: { active: false } });
    await expect(resolveSession("sa")).rejects.toMatchObject({ status: 401 });
  });
  it("zmiana roli jest widoczna bez ponownego logowania", async () => {
    await db.user.update({ where: { id: "owner-a" }, data: { role: "STAFF" } });
    await expect(
      practiceRepository("sa").clinicalAccess(),
    ).rejects.toMatchObject({ status: 403 });
  });
  it("sesja ze starą wersją jest odrzucana", async () => {
    await db.user.update({
      where: { id: "owner-a" },
      data: { sessionVersion: { increment: 1 } },
    });
    await expect(resolveSession("sa")).rejects.toMatchObject({ status: 401 });
  });
  it("tryb tylko do odczytu blokuje zapis i zachowuje odczyt", async () => {
    await db.tenant.update({
      where: { id: "a" },
      data: { status: "READ_ONLY" },
    });
    await expect(
      practiceRepository("sa").getPatient("pa"),
    ).resolves.toBeDefined();
    await expect(
      practiceRepository("sa").archivePatient("pa"),
    ).rejects.toMatchObject({ status: 403 });
  });
  it("koniec triala automatycznie ogranicza konto do odczytu", async () => {
    await db.tenant.update({
      where: { id: "a" },
      data: { status: "TRIAL", trialEndsAt: new Date(Date.now() - 1000) },
    });
    await expect(
      practiceRepository("sa").createPatient({
        firstName: "Test",
        lastName: "Test",
      }),
    ).rejects.toMatchObject({ status: 403 });
  });
  it("zawieszenie gabinetu blokuje stare sesje i logowanie", async () => {
    await db.tenant.update({
      where: { id: "a" },
      data: { status: "SUSPENDED" },
    });
    await expect(resolveSession("sa")).rejects.toMatchObject({ status: 401 });
    expect(
      await authenticate({ email: "a@example.test", password, otp: "" }),
    ).toBeNull();
  });
  it("równoległe żądania nie omijają limitu prób", async () => {
    const results = await Promise.allSettled(
      Array.from({ length: 12 }, () => rateLimit("test", "identity", 5)),
    );
    expect(results.filter((r) => r.status === "fulfilled")).toHaveLength(5);
    expect(results.filter((r) => r.status === "rejected")).toHaveLength(7);
  });
  it("rejestracja tworzy tenant i OWNER atomowo; duplikat nie tworzy sieroty", async () => {
    const input = {
      name: "Nowa Osoba",
      practiceName: "Nowy Gabinet",
      email: "new@example.test",
      password,
    };
    await registerPractice(input);
    const user = await db.user.findUniqueOrThrow({
      where: { email: input.email },
      include: { tenant: true },
    });
    expect(user.role).toBe("OWNER");
    expect(user.tenant.encryptedDataKey).toBeTruthy();
    await registerPractice(input);
    expect(await db.tenant.count({ where: { name: input.practiceName } })).toBe(
      1,
    );
  });
  it("zabrania wstrzyknięcia roli podczas rejestracji", async () => {
    await expect(
      registerPractice({
        name: "Test",
        practiceName: "Test",
        email: "h@example.test",
        password,
        role: "SUPER_ADMIN",
      }),
    ).rejects.toThrow();
  });
  it("2FA wymaga kodu, odrzuca powtórzenie i szyfruje sekret", async () => {
    const secret = authenticator.generateSecret();
    const encrypted = wrapSecret(secret, "totp:a:owner-a");
    await db.user.update({
      where: { id: "owner-a" },
      data: { totpSecretEncrypted: encrypted },
    });
    expect(encrypted).not.toContain(secret);
    expect(
      await authenticate({ email: "a@example.test", password, otp: "" }),
    ).toBeNull();
    const code = authenticator.generate(secret);
    expect(
      await authenticate({ email: "a@example.test", password, otp: code }),
    ).toMatchObject({ id: "owner-a" });
    expect(
      await authenticate({ email: "a@example.test", password, otp: code }),
    ).toBeNull();
  });
  it("włączenie 2FA unieważnia istniejące sesje", async () => {
    const setup = await changeTotp("sa", { action: "setup", password });
    if (!("secret" in setup) || !setup.secret) throw new Error("Brak sekretu");
    await changeTotp("sa", {
      action: "enable",
      password,
      otp: authenticator.generate(setup.secret),
    });
    await expect(resolveSession("sa")).rejects.toMatchObject({ status: 401 });
    expect(
      (await db.user.findUniqueOrThrow({ where: { id: "owner-a" } }))
        .totpSecretEncrypted,
    ).toBeTruthy();
  });
  it("zmiana 2FA wymaga aktualnego hasła", async () => {
    await expect(
      changeTotp("sa", { action: "setup", password: "złe" }),
    ).rejects.toMatchObject({ status: 403 });
  });
});

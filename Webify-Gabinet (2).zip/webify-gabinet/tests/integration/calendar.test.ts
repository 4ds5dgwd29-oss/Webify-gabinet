import { beforeEach, afterAll, it, expect } from "vitest";
import { db } from "@/server/db";
import { fixtures } from "../fixtures";
import {
  saveAppointment,
  saveLeave,
  setAppointmentStatus,
  saveHours,
  calendarData,
} from "@/server/dal/calendar";
import { savePatient, patients, importPatients } from "@/server/dal/patients";
beforeEach(fixtures);
afterAll(() => db.$disconnect());
const visit = {
  patientId: "pa",
  providerId: "oa",
  localStart: "2027-01-11T10:00",
  durationMinutes: 50,
  priceGrosze: 20000,
  repeatCount: 1,
};
it("zapisuje cykl i blokuje kolizję atomowo", async () => {
  const result = await saveAppointment("soa", { ...visit, repeatCount: 3 });
  expect(result.ids).toHaveLength(3);
  await expect(saveAppointment("soa", visit)).rejects.toMatchObject({
    status: 409,
  });
  expect(await db.appointment.count()).toBe(3);
});
it("nie pozwala użyć pacjenta lub prowadzącego z innego tenantu", async () => {
  await expect(
    saveAppointment("soa", { ...visit, patientId: "pb" }),
  ).rejects.toMatchObject({ status: 404 });
  await expect(
    saveAppointment("soa", { ...visit, providerId: "ob" }),
  ).rejects.toMatchObject({ status: 404 });
});
it("blokuje wizyty poza godzinami i w urlopie", async () => {
  await expect(
    saveAppointment("soa", { ...visit, localStart: "2027-01-11T07:00" }),
  ).rejects.toMatchObject({ status: 409 });
  await saveLeave("soa", {
    providerId: "oa",
    label: "Urlop",
    startsAt: "2027-01-11T00:00:00Z",
    endsAt: "2027-01-12T00:00:00Z",
  });
  await expect(saveAppointment("soa", visit)).rejects.toMatchObject({
    status: 409,
  });
});
it("anulowanie zwalnia termin i kontroluje wersję", async () => {
  const { ids } = await saveAppointment("soa", visit);
  await setAppointmentStatus("soa", ids[0], "CANCELLED", 1);
  await expect(
    setAppointmentStatus("soa", ids[0], "CANCELLED", 1),
  ).rejects.toMatchObject({ status: 409 });
  await expect(saveAppointment("soa", visit)).resolves.toBeDefined();
});
it("wersjonuje kartę i filtruje tagi", async () => {
  await savePatient(
    "soa",
    { firstName: "Anna", lastName: "Nowak", tags: ["test"] },
    "pa",
    1,
  );
  await expect(
    savePatient("soa", { firstName: "Stare", lastName: "Dane" }, "pa", 1),
  ).rejects.toMatchObject({ status: 409 });
  expect((await patients("soa", { tag: "test" })).total).toBe(1);
});
it("import nie duplikuje e-mail i jest ograniczony do właściciela", async () => {
  const csv =
    "imie,nazwisko,email\nAnna,Nowa,pacjent@example.test\nJan,Test,nowy@example.test";
  expect(await importPatients("soa", csv)).toEqual({ imported: 1, skipped: 1 });
  await expect(importPatients("sstaff", csv)).rejects.toMatchObject({
    status: 403,
  });
});
it("recepcja nie zmienia dostępności; kalendarz jest izolowany", async () => {
  await expect(
    saveHours("sstaff", { providerId: "oa", hours: [] }),
  ).rejects.toMatchObject({ status: 403 });
  await saveAppointment("soa", visit);
  expect(
    (await calendarData("sob", "2027-01-01", "2027-02-01")).appointments,
  ).toHaveLength(0);
});

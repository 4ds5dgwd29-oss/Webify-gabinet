import { beforeEach, afterAll, it, expect } from "vitest";
import { fixtures } from "../fixtures";
import { db } from "@/server/db";
import {
  saveNote,
  readNote,
  patientHistory,
  savePlan,
  saveGoal,
} from "@/server/dal/clinical";
import {
  uploadDocument,
  downloadDocument,
  patientPdf,
} from "@/server/dal/documents";
import { getObject } from "@/server/storage";
beforeEach(fixtures);
afterAll(() => db.$disconnect());
it("szyfruje notatki, usuwa XSS i zachowuje wersje", async () => {
  const n = await saveNote("soa", {
    patientId: "pa",
    html: "<p>Treść poufna</p><script>alert(1)</script>",
    private: false,
    version: 0,
  });
  const raw = await db.clinicalNote.findUniqueOrThrow({ where: { id: n.id } });
  expect(raw.contentEncrypted).not.toContain("Treść");
  expect((await readNote("soa", n.id)).html).toBe("<p>Treść poufna</p>");
  await saveNote("soa", {
    id: n.id,
    patientId: "pa",
    html: "<p>Nowa wersja</p>",
    private: false,
    version: 1,
  });
  expect((await readNote("soa", n.id, 1)).html).toContain("poufna");
  await expect(
    saveNote("soa", {
      id: n.id,
      patientId: "pa",
      html: "stara",
      private: false,
      version: 1,
    }),
  ).rejects.toMatchObject({ status: 409 });
});
it("prywatna notatka niewidoczna dla innego właściciela, recepcji i admina", async () => {
  const n = await saveNote("soa", {
    patientId: "pa",
    html: "sekret",
    private: true,
    version: 0,
  });
  await expect(readNote("soa2", n.id)).rejects.toMatchObject({ status: 404 });
  await expect(readNote("sstaff", n.id)).rejects.toMatchObject({ status: 403 });
  await expect(readNote("sadmin", n.id)).rejects.toMatchObject({ status: 403 });
  expect((await patientHistory("soa2", "pa")).notes).toHaveLength(0);
  expect((await patientHistory("sstaff", "pa")).clinical).toBe(false);
});
it("notatki i cele nie mogą wskazywać obcego pacjenta", async () => {
  await expect(
    saveNote("soa", { patientId: "pb", html: "x", private: false, version: 0 }),
  ).rejects.toMatchObject({ status: 404 });
  await expect(
    saveGoal("soa", {
      patientId: "pb",
      text: "x",
      status: "ACTIVE",
      version: 0,
    }),
  ).rejects.toMatchObject({ status: 404 });
});
it("plan jest szyfrowany i nie trafia do recepcji", async () => {
  await savePlan("soa", {
    patientId: "pa",
    text: "Poufny plan",
    summary: "Wnioski",
    version: 0,
  });
  expect((await patientHistory("soa", "pa")).plan?.text).toBe("Poufny plan");
  expect((await patientHistory("sstaff", "pa")).plan).toBeNull();
  const raw = await db.treatmentPlan.findFirstOrThrow();
  expect(raw.contentEncrypted).not.toContain("Poufny");
});
it("plik jest zaszyfrowany i pobierany tylko przez uprawnioną osobę", async () => {
  const { id } = await uploadDocument("soa", {
    patientId: "pa",
    name: "test.txt",
    mimeType: "text/plain",
    base64: Buffer.from("Poufny plik").toString("base64"),
  });
  const row = await db.document.findUniqueOrThrow({ where: { id } });
  expect((await getObject(row.objectKey)).toString()).not.toContain("Poufny");
  expect((await downloadDocument("soa", id)).bytes.toString()).toBe(
    "Poufny plik",
  );
  await expect(downloadDocument("sob", id)).rejects.toMatchObject({
    status: 404,
  });
  await expect(downloadDocument("sstaff", id)).rejects.toMatchObject({
    status: 403,
  });
});
it("generuje PDF z polskimi znakami", async () => {
  const bytes = await patientPdf("soa", "pa", "consent");
  expect(bytes.subarray(0, 5).toString()).toBe("%PDF-");
  expect(bytes.length).toBeGreaterThan(1000);
});

import { beforeEach, afterAll, it, expect } from "vitest";
import { fixtures } from "../fixtures";
import { db } from "@/server/db";
import {
  adminData,
  adminAction,
  supportView,
  feedback,
} from "@/server/dal/admin";
import { practiceRepository } from "@/server/dal/practice";
import {
  invite,
  setMember,
  issueReset,
  resetPassword,
} from "@/server/dal/accounts";
import { unwrapSecret } from "@/server/security/crypto";
import { resolveSession } from "@/server/auth/session-store";
beforeEach(fixtures);
afterAll(() => db.$disconnect());
it("admin widzi tylko metadane także w trybie wsparcia", async () => {
  const data = await adminData("sadmin");
  expect(JSON.stringify(data)).not.toContain("Przykładowa");
  await expect(adminData("soa")).rejects.toThrow();
  const support = (await adminAction("sadmin", "support.start", {
    id: "a",
    reason: "Weryfikacja ustawień klienta",
  })) as { id: string };
  expect((await supportView("sadmin", support.id))?.name).toBe("Gabinet A");
  await expect(practiceRepository("sadmin").getPatient("pa")).rejects.toThrow();
  await adminAction("sadmin", "support.end", support.id);
  await expect(supportView("sadmin", support.id)).rejects.toThrow();
});
it("reset jest jednorazowy i unieważnia sesje, zachowując 2FA", async () => {
  await issueReset("oa", "a");
  const message = await db.outboxMessage.findFirstOrThrow({
    where: { tenantId: "a" },
  });
  const payload = JSON.parse(
    unwrapSecret(message.payloadEncrypted, `message:${message.id}`),
  );
  const token = /token=([^\s]+)/.exec(payload.text)![1];
  await resetPassword({ token, password: "Nowe-bezpieczne-haslo123" });
  await expect(resolveSession("soa")).rejects.toThrow();
  await expect(
    resetPassword({ token, password: "Inne-bezpieczne-haslo123" }),
  ).rejects.toThrow();
});
it("zarządzanie zespołem wymaga właściciela i nie pozwala zmienić innego gabinetu", async () => {
  await expect(
    invite("sstaff", { name: "Test", email: "t@example.test", role: "STAFF" }),
  ).rejects.toThrow();
  await expect(
    setMember("soa", { id: "ob", role: "STAFF", active: false }),
  ).rejects.toThrow();
  await setMember("soa", { id: "staff", role: "STAFF", active: false });
  await expect(resolveSession("sstaff")).rejects.toThrow();
  await db.tenant.update({ where: { id: "a" }, data: { userLimit: 1 } });
  await expect(
    adminAction("sadmin", "user", {
      tenantId: "a",
      userId: "staff",
      active: true,
    }),
  ).rejects.toThrow("limit");
});
it("opinie izolowane, administrator może obsłużyć zgłoszenie", async () => {
  await feedback("soa", {
    subject: "Test opinii",
    message: "Proszę poprawić przycisk.",
  });
  expect(await feedback("sob")).toHaveLength(0);
  const data = await adminData("sadmin");
  expect(data.feedback).toHaveLength(1);
  await adminAction("sadmin", "feedback", {
    id: data.feedback[0].id,
    status: "DONE",
  });
  expect((await feedback("soa"))[0].status).toBe("DONE");
});

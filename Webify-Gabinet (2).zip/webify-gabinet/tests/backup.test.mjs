import { test } from "node:test";
import assert from "node:assert/strict";
import { Readable } from "node:stream";
import { mkdtemp, readFile, writeFile, rm, access } from "node:fs/promises";
import { randomBytes } from "node:crypto";
import os from "node:os";
import path from "node:path";
import { encryptStream, decryptFile } from "../scripts/backup-crypto.mjs";
test("kopia odtwarza dane i odrzuca zmodyfikowany szyfrogram bez pozostawienia jawnego pliku", async () => {
  const dir = await mkdtemp(path.join(os.tmpdir(), "backup-test-"));
  try {
    const key = randomBytes(32),
      original = Buffer.from("Fikcyjne dane testowe ąćęłńóśźż".repeat(10000)),
      encrypted = path.join(dir, "a.enc"),
      plain = path.join(dir, "a.bin");
    await encryptStream(Readable.from(original), encrypted, key);
    await decryptFile(encrypted, plain, key);
    assert.deepEqual(await readFile(plain), original);
    const damaged = await readFile(encrypted);
    damaged[50] ^= 1;
    await writeFile(encrypted, damaged);
    await assert.rejects(decryptFile(encrypted, path.join(dir, "bad"), key));
    await assert.rejects(access(path.join(dir, "bad")));
  } finally {
    await rm(dir, { recursive: true, force: true });
  }
});

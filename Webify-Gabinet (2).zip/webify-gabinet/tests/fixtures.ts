import { db } from "@/server/db";
import { hashPassword } from "@/server/auth/password";
import { createTenantKey } from "@/server/security/crypto";
let passwordHash: string;
export async function fixtures() {
  if (!process.env.TEST_DATABASE_URL)
    throw new Error("Ustaw TEST_DATABASE_URL.");
  passwordHash ??= await hashPassword("Testowe-haslo-12345");
  await db.$disconnect();
  await db.$executeRawUnsafe('TRUNCATE TABLE "Tenant" CASCADE');
  await db.tenant.createMany({
    data: [
      {
        id: "webify-platform",
        name: "Platforma",
        slug: "platform",
        kind: "PLATFORM",
        status: "ACTIVE",
      },
      {
        id: "a",
        name: "Gabinet A",
        slug: "a",
        status: "ACTIVE",
        encryptedDataKey: createTenantKey("a"),
      },
      {
        id: "b",
        name: "Gabinet B",
        slug: "b",
        status: "ACTIVE",
        encryptedDataKey: createTenantKey("b"),
      },
    ],
  });
  for (const [id, tenantId, role, kind] of [
    ["oa", "a", "OWNER", "PRACTICE"],
    ["oa2", "a", "OWNER", "PRACTICE"],
    ["staff", "a", "STAFF", "PRACTICE"],
    ["ob", "b", "OWNER", "PRACTICE"],
    ["admin", "webify-platform", "SUPER_ADMIN", "PLATFORM"],
  ] as const) {
    await db.user.create({
      data: {
        id,
        tenantId,
        role,
        tenantKind: kind,
        email: id + "@example.test",
        name: id,
        passwordHash,
      },
    });
    await db.authSession.create({
      data: {
        id: "s" + id,
        userId: id,
        tenantId,
        version: 0,
        expiresAt: new Date(Date.now() + 3600000),
      },
    });
  }
  await db.patient.createMany({
    data: [
      {
        id: "pa",
        tenantId: "a",
        firstName: "Anna",
        lastName: "Przykładowa",
        email: "pacjent@example.test",
        consentData: true,
        consentContact: true,
      },
      { id: "pb", tenantId: "b", firstName: "Jan", lastName: "Przykładowy" },
    ],
  });
  await db.workingHour.createMany({
    data: [1, 2, 3, 4, 5, 6, 7].map((weekday) => ({
      tenantId: "a",
      providerId: "oa",
      weekday,
      startMinute: 480,
      endMinute: 1200,
    })),
  });
}

import { randomBytes } from "node:crypto";
// Nigdy nie uruchamiaj testów na bazie aplikacji. Integracyjne wymagają osobnej bazy *_test.
const url = process.env.TEST_DATABASE_URL;
if (url) {
  const name = new URL(url).pathname.slice(1);
  if (!name.endsWith("_test"))
    throw new Error(
      "TEST_DATABASE_URL musi wskazywać bazę o nazwie zakończonej _test.",
    );
  process.env.DATABASE_URL = url;
} else {
  process.env.DATABASE_URL =
    "postgresql://test:test@127.0.0.1:1/unavailable_test";
}
process.env.NEXTAUTH_URL = "http://localhost:3000";
process.env.NEXTAUTH_SECRET ||= randomBytes(48).toString("base64url");
process.env.MASTER_ENCRYPTION_KEY ||= randomBytes(32).toString("base64");
process.env.ALLOW_REGISTRATION = "true";
process.env.TRUST_PROXY = "false";

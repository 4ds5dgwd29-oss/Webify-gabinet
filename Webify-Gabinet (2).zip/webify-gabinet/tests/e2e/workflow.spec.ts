import { test, expect, type Page } from "@playwright/test";
import AxeBuilder from "@axe-core/playwright";
import { DateTime } from "luxon";
async function login(page: Page, email = "anna@webify.example") {
  await page.goto("/logowanie");
  await page.getByLabel("Adres e-mail").fill(email);
  await page
    .getByLabel("Hasło", { exact: true })
    .fill(process.env.DEMO_PASSWORD!);
  await page.getByRole("button", { name: "Zaloguj się", exact: true }).click();
  await expect(page).toHaveURL(/\/gabinet$/);
}
test("pacjent, wizyta, notatka z autozapisem, wpłata i eksport", async ({
  page,
}) => {
  await login(page);
  await page.goto("/gabinet/pacjenci");
  await page
    .getByRole("button", { name: "Dodaj pacjenta", exact: true })
    .click();
  await page.getByLabel("Imię", { exact: true }).fill("Ewa");
  await page.getByLabel("Nazwisko", { exact: true }).fill("TestowaE2E");
  await page.getByLabel("E-mail", { exact: true }).fill("ewa@example.test");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Dodaj pacjenta", exact: true })
    .click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await page.getByRole("link").filter({ hasText: "Ewa TestowaE2E" }).click();
  await expect(
    page.getByRole("heading", { name: "Ewa TestowaE2E" }),
  ).toBeVisible();
  await expect(page).toHaveURL(/\/gabinet\/pacjenci\/[^/]+$/);
  const patientId = page.url().split("/").pop()!;
  await page.getByRole("button", { name: "Notatki", exact: true }).click();
  await page.getByRole("button", { name: "Nowa notatka" }).click();
  await page
    .getByRole("textbox", { name: "Treść notatki" })
    .fill("Fikcyjny wpis testowy bez danych zdrowotnych.");
  await expect(
    page.getByRole("status").filter({ hasText: /Zapisano · wersja/ }),
  ).toBeVisible();
  await page.getByRole("button", { name: "Zamknij", exact: true }).click();
  await page.getByRole("button", { name: "Otwórz", exact: true }).click();
  await expect(
    page.getByRole("textbox", { name: "Treść notatki" }),
  ).toContainText("Fikcyjny wpis");
  await page.getByRole("button", { name: "Zamknij", exact: true }).click();
  const options = await (
    await page.request.get("/api/praktyka?resource=options")
  ).json();
  const day = DateTime.now()
    .setZone("Europe/Warsaw")
    .plus({ days: 8 })
    .set({ hour: 10, minute: 0, second: 0, millisecond: 0 });
  const hours = Array.from({ length: 7 }, (_, i) => ({
    weekday: i + 1,
    startMinute: 480,
    endMinute: 1200,
  }));
  const headers = { origin: "http://localhost:3000" };
  expect(
    (
      await page.request.post("/api/praktyka", {
        headers,
        data: {
          action: "hours.save",
          data: { providerId: options.providers[0].id, hours },
        },
      })
    ).ok(),
  ).toBeTruthy();
  await page.goto("/gabinet/kalendarz");
  await page.getByRole("button", { name: "Nowa wizyta", exact: true }).click();
  await page
    .getByRole("combobox", { name: "Pacjent", exact: true })
    .selectOption(patientId);
  await page
    .getByLabel("Termin (Europe/Warsaw)", { exact: true })
    .fill(day.toFormat("yyyy-MM-dd'T'HH:mm"));
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Zaplanuj wizytę", exact: true })
    .click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await page.getByLabel("Wybrana data").fill(day.toISODate()!);
  await expect(
    page.getByRole("button").filter({ hasText: "Ewa TestowaE2E" }),
  ).toBeVisible();
  await page.goto("/gabinet/rozliczenia");
  await page
    .getByRole("button", { name: "Zarejestruj wpłatę", exact: true })
    .click();
  const select = page.getByLabel("Wizyta i pozostała należność");
  const option = await select
    .locator("option")
    .filter({ hasText: "Ewa TestowaE2E" })
    .getAttribute("value");
  await select.selectOption(option!);
  await page.getByLabel("Kwota wpłaty (zł)").fill("200");
  await page
    .getByRole("dialog")
    .getByRole("button", { name: "Zapisz", exact: true })
    .click();
  await expect(page.getByRole("dialog")).not.toBeVisible();
  await expect(
    page.getByRole("cell", { name: "Ewa TestowaE2E" }),
  ).toBeVisible();
  const exported = await page.request.get(`/api/eksport?id=${patientId}`);
  expect(exported.ok()).toBeTruthy();
  const body = await exported.json();
  expect(body.notes[0].html).toContain("Fikcyjny wpis");
  expect(body.payments[0].amountGrosze).toBe(20000);
});
test("recepcja nie odczyta notatek ani eksportu, również przez API", async ({
  page,
}) => {
  await login(page, "recepcja@webify.example");
  const patients = await (
    await page.request.get("/api/praktyka?resource=patients")
  ).json();
  const id = patients.items[0].id;
  await page.goto(`/gabinet/pacjenci/${id}`);
  await expect(page.getByRole("button", { name: "Oś czasu" })).toBeVisible();
  await expect(
    page.getByRole("button", { name: "Notatki", exact: true }),
  ).toHaveCount(0);
  expect((await page.request.get(`/api/eksport?id=${id}`)).status()).toBe(403);
});
test("dostępność klawiatury, WCAG oraz widok mobilny", async ({ page }) => {
  await login(page);
  await expect(
    page.getByRole("heading", { name: "Dzień dobry, Anna." }),
  ).toBeVisible();
  const results = await new AxeBuilder({ page })
    .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
    .analyze();
  expect(results.violations).toEqual([]);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/gabinet/pacjenci");
  await expect(
    page.getByRole("heading", { name: "Pacjenci", exact: true }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= innerWidth,
    ),
  ).toBe(true);
});
test("publiczna rezerwacja pokazuje wyłącznie wolne terminy i zapisuje wizytę", async ({
  page,
}) => {
  await login(page);
  const headers = { origin: "http://localhost:3000" };
  expect(
    (
      await page.request.post("/api/praktyka", {
        headers,
        data: {
          action: "commerce.save",
          data: {
            bookingEnabled: true,
            bookingMode: "NONE",
            bookingPrivacy: "Fikcyjna polityka do testu.",
            bookingTerms: "Fikcyjne warunki do testu.",
          },
        },
      })
    ).ok(),
  ).toBeTruthy();
  await page.goto("/rezerwacja/demo-spokoj");
  await expect(
    page.getByRole("heading", { name: "Gabinet Spokój — DEMO" }),
  ).toBeVisible();
  const day = DateTime.now()
    .setZone("Europe/Warsaw")
    .plus({ days: 10 })
    .toISODate()!;
  await page.getByLabel("Dzień", { exact: true }).fill(day);
  const slots = page.getByRole("combobox", { name: /Dostępne terminy/ });
  await expect(slots.locator("option")).not.toHaveCount(1);
  await slots.selectOption({ index: 1 });
  await page.getByLabel("Imię", { exact: true }).fill("Publiczna");
  await page.getByLabel("Nazwisko", { exact: true }).fill("OsobaTestowa");
  await page.getByLabel("Adres e-mail").fill("public@example.test");
  await page.getByRole("checkbox").check();
  await page.getByRole("button", { name: "Zarezerwuj termin" }).click();
  await expect(
    page
      .getByRole("status")
      .filter({ hasText: "Wizyta została zarezerwowana" }),
  ).toBeVisible();
});

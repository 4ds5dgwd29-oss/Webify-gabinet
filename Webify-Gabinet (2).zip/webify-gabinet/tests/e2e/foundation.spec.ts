import { test, expect, type Page } from "@playwright/test";
const password = process.env.DEMO_PASSWORD;
async function login(page: Page, email = "anna@webify.example") {
  if (!password)
    throw new Error("Ustaw DEMO_PASSWORD i uruchom seed przed E2E.");
  await page.goto("/logowanie");
  await page.getByLabel("Adres e-mail").fill(email);
  await page.getByLabel("Hasło", { exact: true }).fill(password);
  await page.getByRole("button", { name: "Zaloguj się", exact: true }).click();
  await expect(page).toHaveURL(
    email.startsWith("admin") ? /\/platforma$/ : /\/gabinet$/,
  );
}
test("logowanie jest wymagane dla gabinetu i API", async ({
  page,
  request,
}) => {
  await page.goto("/gabinet");
  await expect(page).toHaveURL(/\/logowanie/);
  const response = await request.get("/api/gabinet");
  expect(response.status()).toBe(401);
});
test("strona ma polski język i działa na telefonie", async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 });
  await page.goto("/");
  await expect(page.locator("html")).toHaveAttribute("lang", "pl");
  await expect(
    page.getByRole("heading", { name: /Więcej przestrzeni/ }),
  ).toBeVisible();
  expect(
    await page.evaluate(
      () => document.documentElement.scrollWidth <= window.innerWidth,
    ),
  ).toBe(true);
});
test("błędne hasło wyświetla bezpieczny komunikat", async ({ page }) => {
  await page.goto("/logowanie");
  await page.getByLabel("Adres e-mail").fill("unknown@webify.example");
  await page.getByLabel("Hasło", { exact: true }).fill("Niepoprawne-haslo-123");
  await page.getByRole("button", { name: "Zaloguj się", exact: true }).click();
  await expect(
    page.getByRole("alert").filter({ hasText: "Nie udało się zalogować" }),
  ).toBeVisible();
});
test("właściciel widzi swój gabinet i nie widzi panelu platformy", async ({
  page,
}) => {
  await login(page);
  await expect(
    page.getByRole("heading", { name: "Dzień dobry, Anna." }),
  ).toBeVisible();
  const response = await page.request.get("/api/platforma/gabinety");
  expect(response.status()).toBe(403);
  await page.getByRole("link", { name: "Zespół", exact: true }).click();
  await expect(
    page.getByRole("heading", { name: "Zespół gabinetu" }),
  ).toBeVisible();
  await expect(page.getByText("Maria Nowak", { exact: true })).toBeVisible();
  await expect(page.getByText("Piotr Zieliński", { exact: true })).toHaveCount(
    0,
  );
});
test("recepcja loguje się z odrębną rolą", async ({ page }) => {
  await login(page, "recepcja@webify.example");
  await expect(
    page.getByText("Recepcja / asystent", { exact: true }).first(),
  ).toBeVisible();
  expect((await page.request.get("/api/platforma/gabinety")).status()).toBe(
    403,
  );
});
test("superadmin ma tylko metadane gabinetów", async ({ page }) => {
  await login(page, "admin@webify.example");
  await expect(
    page.getByRole("heading", { name: "Gabinety na platformie" }),
  ).toBeVisible();
  expect((await page.request.get("/api/gabinet")).status()).toBe(403);
  const response = await page.request.get("/api/platforma/gabinety");
  expect(response.status()).toBe(200);
  const rows = await response.json();
  expect(rows.length).toBeGreaterThanOrEqual(2);
  expect(rows[0]).not.toHaveProperty("patients");
});
test("Ctrl K otwiera wyszukiwanie, Escape zamyka", async ({ page }) => {
  await login(page);
  await page.keyboard.press("Control+k");
  await expect(page.getByRole("dialog")).toBeVisible();
  await page
    .getByRole("textbox", { name: "Szukaj strony" })
    .fill("Bezpieczeństwo");
  await expect(
    page
      .getByRole("dialog")
      .getByRole("link", { name: "Bezpieczeństwo konta" }),
  ).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.getByRole("dialog")).not.toBeVisible();
});
test("motyw zmienia się i jest zapamiętany", async ({ page }) => {
  await page.goto("/logowanie");
  await page.getByRole("button", { name: "Zmień motyw" }).click();
  await expect(page.locator("html")).toHaveClass(/dark/);
  await page.reload();
  await expect(page.locator("html")).toHaveClass(/dark/);
});
test("wylogowanie zamyka dostęp do API", async ({ page }) => {
  await login(page);
  await page.getByRole("button", { name: "Wyloguj się" }).click();
  await expect(page).toHaveURL(/\/logowanie/);
  expect((await page.request.get("/api/gabinet")).status()).toBe(401);
});
test("mutacje odrzucają obcy origin oraz brak CSRF NextAuth", async ({
  request,
}) => {
  const register = await request.post("/api/rejestracja", {
    headers: { origin: "https://obca.test" },
    data: {},
  });
  expect(register.status()).toBe(403);
  const response = await request.post("/api/auth/callback/credentials", {
    form: {
      email: "anna@webify.example",
      password: password ?? "",
      json: "true",
    },
    maxRedirects: 0,
  });
  const text = await response.text();
  expect(response.status() === 302 || text.includes("csrf")).toBe(true);
});
test("rejestracja tworzy nowy gabinet i pozwala się zalogować", async ({
  page,
}) => {
  const email = `e2e-${Date.now()}@example.test`;
  await page.goto("/rejestracja");
  await page.getByLabel("Imię i nazwisko").fill("Testowa Osoba");
  await page.getByLabel("Nazwa gabinetu").fill("Gabinet testowy E2E");
  await page.getByLabel("Adres e-mail").fill(email);
  await page.getByLabel("Hasło", { exact: true }).fill("Testowe-e2e-haslo-123");
  await page
    .getByRole("button", { name: "Utwórz gabinet", exact: true })
    .click();
  await expect(page.getByRole("status")).toContainText("konto jest gotowe");
  await page.getByRole("link", { name: "Przejdź do logowania" }).click();
  await page.getByLabel("Adres e-mail").fill(email);
  await page.getByLabel("Hasło", { exact: true }).fill("Testowe-e2e-haslo-123");
  await page.getByRole("button", { name: "Zaloguj się", exact: true }).click();
  await expect(page).toHaveURL(/\/gabinet$/);
  await expect(
    page.getByRole("heading", { name: "Dzień dobry, Testowa." }),
  ).toBeVisible();
});
test("CSP, HSTS i ochrona ramek są obecne", async ({ request }) => {
  const response = await request.get("/logowanie");
  expect(response.headers()["content-security-policy"]).toContain(
    "frame-ancestors 'none'",
  );
  expect(response.headers()["content-security-policy"]).toContain("'nonce-");
  expect(response.headers()["x-frame-options"]).toBe("DENY");
  expect(response.headers()["strict-transport-security"]).toContain("max-age=");
});

import test from 'node:test';
import assert from 'node:assert/strict';
import { validateProduction } from '../scripts/validate-production.mjs';
const base = {DATABASE_URL:'postgresql://test:test@db:5432/webify', NEXTAUTH_URL:'https://gabinet.example.pl', NEXTAUTH_SECRET:'n'.repeat(48), CRON_SECRET:'c'.repeat(48), MASTER_ENCRYPTION_KEY:Buffer.alloc(32,1).toString('base64'), STORAGE_DRIVER:'local', LOCAL_STORAGE_PATH:'/app/storage', RAILWAY_VOLUME_MOUNT_PATH:'/app/storage'};
test('Akceptuje konfigurację HTTPS z trwałym wolumenem', () => assert.deepEqual(validateProduction(base), []));
test('Blokuje efemeryczne dane i katalog poza wolumenem', () => { for (const RAILWAY_VOLUME_MOUNT_PATH of ['', '/inne']) assert.ok(validateProduction({...base, RAILWAY_VOLUME_MOUNT_PATH}).length); });
test('Blokuje HTTP, słabe klucze i dane demo', () => { for (const patch of [{NEXTAUTH_URL:'http://example.pl'}, {NEXTAUTH_SECRET:'short'}, {CRON_SECRET:''}, {MASTER_ENCRYPTION_KEY:'bad'}, {DEMO_PASSWORD:'demo'}]) assert.ok(validateProduction({...base,...patch}).length); });
test('S3 wymaga kompletnej konfiguracji i HTTPS', () => { const s3 = {...base, STORAGE_DRIVER:'s3', S3_REGION:'eu-central-1', S3_BUCKET:'webify', S3_ACCESS_KEY_ID:'test', S3_SECRET_ACCESS_KEY:'test'}; assert.deepEqual(validateProduction(s3),[]); assert.ok(validateProduction({...s3,S3_BUCKET:''}).length); assert.ok(validateProduction({...s3,S3_ENDPOINT:'http://example.pl'}).length); });
